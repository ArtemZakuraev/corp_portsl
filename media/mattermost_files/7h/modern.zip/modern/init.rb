# -*- coding: utf-8 -*-

# Redmine Modern Hi-Tech Theme
# Version: 1.0
# Compatible with: Redmine 4.2.11

theme = Redmine::Themes.theme('modern')
theme.description = 'Modern Hi-Tech theme with dark colors, neon accents, and smooth animations'
theme.author = 'Theme Developer'
theme.url = 'https://github.com/youruser/redmine-modern-theme'
theme.version = '1.0'

# Define theme colors
theme.colors = {
  # Main colors
  :primary         => '#00d4ff',   # Cyan
  :secondary       => '#0099cc',   # Darker cyan
  :accent          => '#00ff88',   # Green
  :background      => '#0a0e27',   # Dark blue
  :background_alt  => '#050714',   # Darker blue
  :card            => '#11152b',   # Card background
  :text            => '#e0e0e0',   # Light gray text
  :text_dim        => '#b0b0b0',   # Dimmed text
  :border          => '#1e3a5f',    # Border color
  
  # Status colors
  :success         => '#00ff88',   # Green
  :warning         => '#ffaa00',   # Orange
  :error           => '#ff3366',   # Red
}

# Define custom CSS variables that can be used in the stylesheet
Redmine::Themes.theme('modern').settings = {
  # Add any theme settings here if needed
  # Example:
  # :custom_variable => 'value',
}

# Override default preview image
Redmine::Themes.theme('modern').preview_image = 'preview.png'

