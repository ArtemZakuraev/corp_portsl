require_relative 'lib/onec_request'

Redmine::Plugin.register :'1c_request' do
  name '1C Request'
  author 'a.zakuraev'
  description 'Fetches user-specific workload reports from an external 1C service.'
  version '0.1.0'
  requires_redmine version_or_higher: '4.2.11'

  settings default: {
    'enabled' => false,
    'endpoint_url' => ''
  }, partial: 'settings/onec_request/settings'
end

OnecRequest.setup
