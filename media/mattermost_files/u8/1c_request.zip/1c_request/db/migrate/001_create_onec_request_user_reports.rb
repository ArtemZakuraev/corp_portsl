class CreateOnecRequestUserReports < ActiveRecord::Migration[5.2]
  def change
    create_table :onec_request_user_reports do |t|
      t.integer :user_id, null: false
      t.text :html_content
      t.datetime :fetched_at

      t.timestamps null: false
    end

    add_index :onec_request_user_reports, :user_id, unique: true
  end
end
