module OnecRequest
  class << self
    def setup
      ensure_autoload_paths
      register_patches
    end

    private

    def ensure_autoload_paths
      paths = %w[app/models app/controllers app/helpers app/services app/lib]
      base_path = File.expand_path('..', __dir__)
      paths.each do |rel_path|
        full_path = File.join(base_path, rel_path)
        next unless Dir.exist?(full_path)

        ActiveSupport::Dependencies.autoload_paths << full_path unless ActiveSupport::Dependencies.autoload_paths.include?(full_path)
        ActiveSupport::Dependencies.autoload_once_paths.delete(full_path)
      end
    end

    def register_patches
      ActiveSupport::Reloader.to_prepare do
        require_dependency File.join(File.dirname(__FILE__), 'onec_request/hooks/view_hooks')
        require_dependency File.join(File.dirname(__FILE__), 'onec_request/patches/my_controller_patch')
      end
    end
  end
end
