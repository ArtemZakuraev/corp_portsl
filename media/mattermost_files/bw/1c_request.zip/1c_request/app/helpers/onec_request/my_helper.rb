module OnecRequest
  module MyHelper
    def onec_request_enabled?
      value = plugin_settings['enabled']
      ActiveModel::Type::Boolean.new.cast(value)
    end

    def onec_request_endpoint
      plugin_settings['endpoint_url'].to_s.strip
    end

    def onec_request_button_label(report)
      if report.present?
        l(:button_onec_request_refresh)
      else
        l(:button_onec_request_fetch)
      end
    end

    private

    def plugin_settings
      Setting.plugin_onec_request || {}
    end
  end
end
