require 'net/http'
require 'uri'

module OnecRequest
  class MyWorklogsController < ApplicationController
    before_action :require_login
    helper OnecRequest::MyHelper

    def update
      unless onec_request_enabled?
        flash[:error] = l(:error_onec_request_disabled)
        return redirect_back(fallback_location: my_time_entries_path)
      end

      if onec_request_endpoint.blank?
        flash[:error] = l(:error_onec_request_missing_endpoint)
        return redirect_back(fallback_location: my_time_entries_path)
      end

      response = fetch_report(current_user_payload)

      if response.is_a?(Net::HTTPSuccess)
        persist_report(response.body)
        flash[:notice] = l(:notice_onec_request_updated)
      else
        log_failure(response)
        flash[:error] = l(:error_onec_request_fetch_failed, code: response.code)
      end

      redirect_to my_time_entries_path
    rescue StandardError => e
      Rails.logger.error("OnecRequest: #{e.class}: #{e.message}\n#{e.backtrace.join("\n")}")
      flash[:error] = l(:error_onec_request_unexpected)
      redirect_to my_time_entries_path
    end

    private

    def onec_request_enabled?
      helpers.onec_request_enabled?
    end

    def onec_request_endpoint
      helpers.onec_request_endpoint
    end

    def current_user_payload
      {
        username: User.current.login,
        firstname: User.current.firstname,
        lastname: User.current.lastname,
        mail: User.current.mail
      }
    end

    def fetch_report(payload)
      uri = URI.parse(onec_request_endpoint)
      http = Net::HTTP.new(uri.host, uri.port)
      http.use_ssl = uri.scheme == 'https'
      request = Net::HTTP::Post.new(uri.request_uri, 'Content-Type' => 'application/json')
      request.body = payload.to_json
      http.request(request)
    end

    def persist_report(html)
      report = OnecRequest::UserReport.find_or_initialize_by(user_id: User.current.id)
      report.html_content = html
      report.fetched_at = Time.current
      report.save!
    end

    def log_failure(response)
      Rails.logger.warn(
        "OnecRequest: Unexpected response #{response.code} for user ##{User.current.id}"
      )
    end
  end
end
