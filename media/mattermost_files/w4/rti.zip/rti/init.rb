# -*- coding: utf-8 -*-

# Redmine Modern Hi-Tech Theme
# Version: 1.0
# Compatible with: Redmine 4.2.11

theme = Redmine::Themes.theme('modern')
theme.description = 'Modern Hi-Tech theme with professional dark colors, neon accents, smooth animations, and enhanced UX for optimal readability and user experience'
theme.author = 'Theme Developer'
theme.url = 'https://github.com/youruser/redmine-modern-theme'
theme.version = '1.1'

# Define theme colors
theme.colors = {
  # Main colors
  :primary         => '#00d4ff',   # Cyan primary accent
  :secondary       => '#0099cc',   # Darker cyan
  :accent          => '#00ff88',   # Green for success/positive
  :background      => '#0a0e27',   # Dark blue main background
  :background_alt  => '#050714',   # Darker blue
  :card            => '#151b2e',   # Card background
  :text            => '#e8eef7',   # Light text for readability
  :text_dim        => '#a0b8d0',   # Dimmed text
  :border          => '#1e3a5f',  # Border color
  
  # Status colors
  :success         => '#00ff88',   # Green
  :warning         => '#ffaa00',   # Orange
  :error           => '#ff3366',   # Red
}

# Define custom CSS variables that can be used in the stylesheet
Redmine::Themes.theme('modern').settings = {
  # Add any theme settings here if needed
  # Example:
  # :custom_variable => 'value',
}

# Override default preview image
Redmine::Themes.theme('modern').preview_image = 'preview.png'

