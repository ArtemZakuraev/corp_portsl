#!/usr/bin/env python3
"""
Скрипт для тестирования исправления ошибки async context manager
"""

import asyncio
import sys
import os
from sqlalchemy.ext.asyncio import AsyncSession
from database import get_async_session, engine, async_session_maker
from models import User, Base
from utils import get_password_hash
from sqlalchemy import select
import logging

# Настройка логирования
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


async def test_async_session_context():
    """Тестирование правильного использования async session context"""
    print("🧪 Тестирование async session context...")
    
    # Создаем таблицы если их нет
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    
    try:
        # Тест 1: Правильное использование async_session_maker
        print("   Тест 1: async_session_maker")
        async with async_session_maker() as session:
            result = await session.execute(select(User))
            users = result.scalars().all()
            print(f"   ✅ async_session_maker работает: найдено {len(users)} пользователей")
        
        # Тест 2: Правильное использование get_async_session (как генератор)
        print("   Тест 2: get_async_session как генератор")
        async for session in get_async_session():
            result = await session.execute(select(User))
            users = result.scalars().all()
            print(f"   ✅ get_async_session как генератор работает: найдено {len(users)} пользователей")
            break  # Выходим после первой итерации
        
        # Тест 3: Создание пользователя с async_session_maker
        print("   Тест 3: Создание пользователя")
        async with async_session_maker() as session:
            # Проверяем, есть ли тестовый пользователь
            result = await session.execute(select(User).where(User.username == "testuser"))
            existing_user = result.scalar_one_or_none()
            
            if not existing_user:
                test_user = User(
                    username="testuser",
                    email="test@example.com",
                    password_hash=get_password_hash("test123"),
                    is_admin=False
                )
                session.add(test_user)
                await session.commit()
                print("   ✅ Тестовый пользователь создан")
            else:
                print("   ✅ Тестовый пользователь уже существует")
        
        print("🎉 Все тесты async session context прошли успешно!")
        return True
        
    except Exception as e:
        print(f"❌ Ошибка при тестировании async session context: {e}")
        return False


async def test_concurrent_sessions():
    """Тестирование одновременных сессий"""
    print("\n🧪 Тестирование одновременных сессий...")
    
    async def session_task(task_id: int):
        """Задача с сессией"""
        try:
            async with async_session_maker() as session:
                result = await session.execute(select(User))
                users = result.scalars().all()
                print(f"   Задача {task_id}: ✅ Найдено {len(users)} пользователей")
                return True
        except Exception as e:
            print(f"   Задача {task_id}: ❌ Ошибка - {e}")
            return False
    
    # Создаем несколько одновременных задач
    tasks = []
    for i in range(3):
        task = asyncio.create_task(session_task(i + 1))
        tasks.append(task)
    
    # Ждем завершения всех задач
    results = await asyncio.gather(*tasks, return_exceptions=True)
    
    success_count = sum(1 for r in results if r is True)
    print(f"✅ Успешных задач: {success_count}/3")
    
    if success_count == 3:
        print("🎉 Одновременные сессии работают корректно!")
        return True
    else:
        print("⚠️ Есть проблемы с одновременными сессиями")
        return False


async def test_database_operations():
    """Тестирование операций с базой данных"""
    print("\n🧪 Тестирование операций с базой данных...")
    
    try:
        # Тест создания пользователя
        async with async_session_maker() as session:
            # Проверяем, есть ли пользователь admin
            result = await session.execute(select(User).where(User.username == "admin"))
            admin_user = result.scalar_one_or_none()
            
            if not admin_user:
                print("   Создание администратора...")
                admin = User(
                    username="admin",
                    email="admin@example.com",
                    password_hash=get_password_hash("admin123"),
                    is_admin=True
                )
                session.add(admin)
                await session.commit()
                print("   ✅ Администратор создан")
            else:
                print("   ✅ Администратор уже существует")
        
        # Тест чтения пользователей
        async with async_session_maker() as session:
            result = await session.execute(select(User))
            users = result.scalars().all()
            print(f"   ✅ Найдено пользователей: {len(users)}")
            
            for user in users:
                print(f"     - {user.username} ({'admin' if user.is_admin else 'user'})")
        
        print("🎉 Операции с базой данных работают корректно!")
        return True
        
    except Exception as e:
        print(f"❌ Ошибка при тестировании операций с базой данных: {e}")
        return False


async def main():
    """Главная функция"""
    print("🔧 Тестирование исправления async context manager...")
    print("="*60)
    
    try:
        # Запускаем все тесты
        test1 = await test_async_session_context()
        test2 = await test_concurrent_sessions()
        test3 = await test_database_operations()
        
        print("\n" + "="*60)
        if test1 and test2 and test3:
            print("🎉 Все тесты прошли успешно!")
            print("✅ Ошибка 'async_generator' object does not support the asynchronous context manager protocol исправлена!")
        else:
            print("⚠️ Некоторые тесты не прошли")
        
    except Exception as e:
        print(f"❌ Критическая ошибка при тестировании: {e}")


if __name__ == "__main__":
    asyncio.run(main())

