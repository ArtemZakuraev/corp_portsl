#!/usr/bin/env python3
"""
Скрипт для проверки наличия администратора
"""

import asyncio
import sys
from sqlalchemy import select
from database import async_session_maker
from models import User


async def check_admin():
    """Проверка наличия администратора"""
    print("🔍 Проверка наличия администратора...")
    
    try:
        async with async_session_maker() as session:
            result = await session.execute(select(User).where(User.is_admin == True))
            existing_admins = result.scalars().all()
            
            if existing_admins:
                print(f"✅ Администратор найден: {existing_admins[0].username}")
                print(f"   Email: {existing_admins[0].email}")
                return True
            else:
                print("⚠️ Администратор не найден")
                print("💡 Создайте администратора через: python init_db.py")
                return False
                
    except Exception as e:
        print(f"❌ Ошибка при проверке администратора: {e}")
        return False


async def main():
    """Главная функция"""
    if len(sys.argv) > 1 and sys.argv[1] == "help":
        print("Использование:")
        print("  python check_admin.py           - Проверить наличие администратора")
        print("  python check_admin.py help      - Показать эту справку")
    else:
        await check_admin()


if __name__ == "__main__":
    asyncio.run(main())

