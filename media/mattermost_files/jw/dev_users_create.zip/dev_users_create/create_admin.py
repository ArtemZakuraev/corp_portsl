#!/usr/bin/env python3
"""
Скрипт для создания первого администратора системы
"""

import asyncio
import sys
from sqlalchemy.ext.asyncio import AsyncSession
from database import get_async_session, engine
from models import User, Base
from utils import get_password_hash
from sqlalchemy import select


async def create_admin_user():
    """Создание администратора"""
    print("🔧 Создание администратора системы...")
    
    # Создаем таблицы если их нет
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    
    # Получаем сессию базы данных
    async for session in get_async_session():
        try:
            # Проверяем, есть ли уже администраторы
            result = await session.execute(select(User).where(User.is_admin == True))
            existing_admin = result.scalar_one_or_none()
            
            if existing_admin:
                print(f"✅ Администратор уже существует: {existing_admin.username}")
                print(f"   Email: {existing_admin.email}")
                return
            
            # Запрашиваем данные администратора
            print("\n📝 Введите данные для создания администратора:")
            username = input("Имя пользователя: ").strip()
            email = input("Email: ").strip()
            password = input("Пароль: ").strip()
            
            if not username or not email or not password:
                print("❌ Все поля обязательны для заполнения!")
                return
            
            # Проверяем, не существует ли пользователь с таким именем
            result = await session.execute(select(User).where(User.username == username))
            if result.scalar_one_or_none():
                print(f"❌ Пользователь с именем '{username}' уже существует!")
                return
            
            # Проверяем, не существует ли пользователь с таким email
            result = await session.execute(select(User).where(User.email == email))
            if result.scalar_one_or_none():
                print(f"❌ Пользователь с email '{email}' уже существует!")
                return
            
            # Создаем администратора
            hashed_password = get_password_hash(password)
            admin_user = User(
                username=username,
                email=email,
                password_hash=hashed_password,
                is_admin=True
            )
            
            session.add(admin_user)
            await session.commit()
            await session.refresh(admin_user)
            
            print(f"\n✅ Администратор успешно создан!")
            print(f"   ID: {admin_user.id}")
            print(f"   Имя пользователя: {admin_user.username}")
            print(f"   Email: {admin_user.email}")
            print(f"   Права: Администратор")
            print(f"\n🌐 Теперь вы можете войти в систему по адресу: http://localhost:8000/login")
            
        except Exception as e:
            print(f"❌ Ошибка при создании администратора: {e}")
            await session.rollback()
        finally:
            await session.close()
        break


async def list_users():
    """Список всех пользователей"""
    print("👥 Список пользователей:")
    
    async for session in get_async_session():
        try:
            result = await session.execute(select(User))
            users = result.scalars().all()
            
            if not users:
                print("   Пользователи не найдены")
                return
            
            for user in users:
                role = "Администратор" if user.is_admin else "Пользователь"
                print(f"   {user.id}. {user.username} ({user.email}) - {role}")
                
        except Exception as e:
            print(f"❌ Ошибка при получении списка пользователей: {e}")
        finally:
            await session.close()
        break


async def main():
    """Главная функция"""
    if len(sys.argv) > 1 and sys.argv[1] == "list":
        await list_users()
    else:
        await create_admin_user()


if __name__ == "__main__":
    asyncio.run(main())

