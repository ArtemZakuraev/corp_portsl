from sqlalchemy.ext.asyncio import AsyncSession, create_async_engine, async_sessionmaker
from sqlalchemy.orm import DeclarativeBase
from config import settings
import os

# Определяем URL базы данных
def get_database_url():
    """Получение URL базы данных с учетом окружения"""
    # Если в переменных окружения есть PostgreSQL настройки
    if os.getenv("POSTGRES_HOST") or os.getenv("DATABASE_URL"):
        if os.getenv("DATABASE_URL"):
            return os.getenv("DATABASE_URL")
        else:
            # Собираем URL из переменных окружения
            host = os.getenv("POSTGRES_HOST", settings.postgres_host)
            port = os.getenv("POSTGRES_PORT", settings.postgres_port)
            user = os.getenv("POSTGRES_USER", settings.postgres_user)
            password = os.getenv("POSTGRES_PASSWORD", settings.postgres_password)
            db = os.getenv("POSTGRES_DB", settings.postgres_db)
            return f"postgresql+asyncpg://{user}:{password}@{host}:{port}/{db}"
    else:
        # Используем SQLite по умолчанию
        return settings.database_url

# Создаем асинхронный движок базы данных
database_url = get_database_url()
print(f"🔗 Подключение к базе данных: {database_url.split('@')[-1] if '@' in database_url else database_url}")

engine = create_async_engine(
    database_url,
    echo=settings.debug,
    future=True
)

# Создаем фабрику сессий
async_session_maker = async_sessionmaker(
    engine,
    class_=AsyncSession,
    expire_on_commit=False
)


class Base(DeclarativeBase):
    pass


# Зависимость для получения сессии базы данных
async def get_async_session() -> AsyncSession:
    async with async_session_maker() as session:
        try:
            yield session
        finally:
            await session.close()

