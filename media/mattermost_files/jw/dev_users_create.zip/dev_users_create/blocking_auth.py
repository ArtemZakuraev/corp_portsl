#!/usr/bin/env python3
"""
Блокирующая система аутентификации без конфликтов с event loop
"""

import asyncio
import logging
from typing import Optional
from jose import JWTError, jwt
from fastapi import Request
from models import User
from config import settings
from utils import verify_password

logger = logging.getLogger(__name__)


def get_user_by_username_blocking(username: str) -> Optional[User]:
    """Блокирующее получение пользователя по имени"""
    try:
        # Используем asyncio.run_coroutine_threadsafe для выполнения в отдельном потоке
        import concurrent.futures
        import threading
        
        async def _get_user():
            from database import async_session_maker
            from sqlalchemy import select
            async with async_session_maker() as session:
                result = await session.execute(select(User).where(User.username == username))
                return result.scalar_one_or_none()
        
        # Выполняем в отдельном потоке с новым event loop
        def run_in_thread():
            return asyncio.run(_get_user())
        
        with concurrent.futures.ThreadPoolExecutor() as executor:
            future = executor.submit(run_in_thread)
            user = future.result(timeout=10)
            return user
            
    except Exception as e:
        logger.error(f"Ошибка при получении пользователя {username}: {e}")
        return None


def authenticate_user_blocking(username: str, password: str) -> Optional[User]:
    """Блокирующая аутентификация пользователя"""
    try:
        user = get_user_by_username_blocking(username)
        if not user:
            return None
        
        if not verify_password(password, user.password_hash):
            return None
        
        return user
    except Exception as e:
        logger.error(f"Ошибка при аутентификации пользователя {username}: {e}")
        return None


def get_user_from_cookie_blocking(request: Request) -> Optional[User]:
    """Блокирующее получение пользователя из cookie"""
    try:
        # Проверяем cookie
        token = request.cookies.get("access_token")
        if not token:
            return None
        
        # Убеждаемся, что токен имеет правильный формат
        if not token.startswith("Bearer "):
            token = f"Bearer {token}"
        
        # Извлекаем токен
        token = token.split(" ")[1]
        
        # Декодируем JWT
        payload = jwt.decode(token, settings.secret_key, algorithms=[settings.algorithm])
        username: str = payload.get("sub")
        if username is None:
            return None
        
        # Получаем пользователя блокирующим способом
        user = get_user_by_username_blocking(username)
        return user
    except (JWTError, IndexError) as e:
        logger.debug(f"Ошибка при получении пользователя из cookie: {e}")
        return None
    except Exception as e:
        logger.error(f"Ошибка при получении пользователя из cookie: {e}")
        return None


def test_blocking_auth():
    """Тестирование блокирующей аутентификации"""
    print("🧪 Тестирование блокирующей аутентификации...")
    
    try:
        # Тест получения пользователя
        user = get_user_by_username_blocking("admin")
        if user:
            print(f"✅ Пользователь найден: {user.username}")
        else:
            print("⚠️ Пользователь admin не найден")
        
        # Тест аутентификации
        if user:
            auth_user = authenticate_user_blocking("admin", "admin123")
            if auth_user:
                print("✅ Аутентификация работает")
            else:
                print("❌ Аутентификация не работает")
        
    except Exception as e:
        print(f"❌ Ошибка при тестировании: {e}")


if __name__ == "__main__":
    test_blocking_auth()
