import aiohttp
import gitlab
from redminelib import Redmine
from typing import Optional, Dict, Any, List
import logging
import subprocess
import asyncio
import ssl

logger = logging.getLogger(__name__)


class GitLabAPI:
    def __init__(self, url: str, token: str):
        self.url = url
        self.token = token
        self.gl = None
        
        try:
            # Проверяем, что URL и токен не пустые
            if not url or not token:
                raise ValueError("GitLab URL и токен не могут быть пустыми")
            
            # Создаем SSL контекст с отключенной проверкой сертификатов
            ssl_context = ssl.create_default_context()
            ssl_context.check_hostname = False
            ssl_context.verify_mode = ssl.CERT_NONE
            
            # Создаем GitLab клиент с отключенной проверкой SSL
            self.gl = gitlab.Gitlab(url, private_token=token, ssl_verify=False)
            
            if self.gl is None:
                raise ValueError("Failed to initialize GitLab client")
            
            # Пробуем аутентифицироваться при инициализации
            try:
                self.gl.auth()
                logger.info("GitLab API initialized and authenticated successfully")
            except Exception as auth_error:
                logger.warning(f"GitLab authentication failed during initialization: {auth_error}")
                # Не прерываем инициализацию, просто логируем предупреждение
                
        except Exception as e:
            logger.error(f"Failed to initialize GitLab API: {e}")
            # Не устанавливаем self.gl = None, чтобы можно было попробовать позже
            raise
    
    async def create_user(self, user_data: Dict[str, Any]) -> Optional[int]:
        """Создание пользователя в GitLab"""
        try:
            username = user_data['username']
            email = user_data['email']
            name = f"{user_data['first_name']} {user_data['last_name']}"
            
            # Проверяем, существует ли пользователь
            try:
                existing_user = self.gl.users.list(username=username)
                if existing_user and len(existing_user) > 0:
                    logger.info(f"User {username} already exists in GitLab")
                    return existing_user[0].id
            except:
                pass
            
            # Создаем нового пользователя
            user = self.gl.users.create({
                'email': email,
                'username': username,
                'name': name,
                'password': 'TempPassword123!',  # Временный пароль
                'skip_confirmation': True
            })
            
            if user is None:
                logger.error(f"Failed to create GitLab user {username}: user object is None")
                return None
            
            logger.info(f"Created GitLab user {username} with ID {user.id}")
            return user.id
            
        except Exception as e:
            logger.error(f"Error creating GitLab user: {e}")
            return None
    
    async def find_user_by_username(self, username: str) -> Optional[Dict[str, Any]]:
        """Поиск пользователя в GitLab по username"""
        try:
            users = self.gl.users.list(username=username)
            if users and len(users) > 0:
                user = users[0]
                if user is None:
                    return None
                return {
                    'id': user.id,
                    'username': user.username,
                    'name': user.name,
                    'email': user.email,
                    'state': user.state,
                    'created_at': user.created_at,
                    'last_activity_on': user.last_activity_on
                }
            return None
        except Exception as e:
            logger.error(f"Error finding GitLab user by username {username}: {e}")
            return None
    
    async def find_user_by_email(self, email: str) -> Optional[Dict[str, Any]]:
        """Поиск пользователя в GitLab по email"""
        try:
            users = self.gl.users.list(search=email)
            # Фильтруем по точному совпадению email
            if users:
                for user in users:
                    if user is not None and user.email == email:
                        return {
                            'id': user.id,
                            'username': user.username,
                            'name': user.name,
                            'email': user.email,
                            'state': user.state,
                            'created_at': user.created_at,
                            'last_activity_on': user.last_activity_on
                        }
            return None
        except Exception as e:
            logger.error(f"Error finding GitLab user by email {email}: {e}")
            return None
    
    async def find_existing_user(self, username: str, email: str) -> Optional[Dict[str, Any]]:
        """Поиск существующего пользователя в GitLab по username или email"""
        try:
            # Сначала ищем по username
            user = await self.find_user_by_username(username)
            if user:
                logger.info(f"Found GitLab user by username: {username}")
                return user
            
            # Если не найден по username, ищем по email
            user = await self.find_user_by_email(email)
            if user:
                logger.info(f"Found GitLab user by email: {email}")
                return user
            
            logger.info(f"No existing GitLab user found for username: {username} or email: {email}")
            return None
        except Exception as e:
            logger.error(f"Error finding existing GitLab user: {e}")
            return None
    
    async def add_user_to_project(self, user_id: int, project_id: str, access_level: int = 30) -> bool:
        """Добавление пользователя к проекту в GitLab"""
        try:
            project = self.gl.projects.get(project_id)
            member = project.members.create({
                'user_id': user_id,
                'access_level': access_level  # 30 = Developer
            })
            logger.info(f"Added user {user_id} to project {project_id}")
            return True
        except Exception as e:
            logger.error(f"Error adding user to GitLab project: {e}")
            return False
    
    async def trigger_pipeline(self, project_id: str, user_data: Dict[str, Any], project_names: List[str]) -> Optional[int]:
        """Запуск пайплайна в GitLab с параметрами разработчика"""
        try:
            project = self.gl.projects.get(project_id)
            
            # Подготавливаем переменные для пайплайна
            variables = {
                'LAST_NAME': user_data['last_name'],
                'FIRST_NAME': user_data['first_name'],
                'MIDDLE_NAME': user_data.get('middle_name', ''),
                'EMAIL': user_data['email'],
                'POSITION': user_data.get('position', ''),
                'DEPARTMENT': user_data.get('department', ''),
                'PROJECTS': ','.join(project_names) if project_names else ''
            }
            
            # Запускаем пайплайн
            pipeline = project.pipelines.create({
                'ref': 'main',  # или 'master' в зависимости от ветки по умолчанию
                'variables': [{'key': k, 'value': v} for k, v in variables.items()]
            })
            
            logger.info(f"Triggered pipeline {pipeline.id} in project {project_id} for user {user_data['email']}")
            return pipeline.id
            
        except Exception as e:
            logger.error(f"Error triggering GitLab pipeline: {e}")
            return None
    
    async def test_connection(self) -> Dict[str, Any]:
        """Проверка подключения к GitLab"""
        try:
            # Проверяем, что GitLab клиент инициализирован
            if not hasattr(self, 'gl') or self.gl is None:
                return {
                    'success': False,
                    'message': 'GitLab недоступен: Клиент не инициализирован',
                    'error': 'GitLab client not initialized'
                }
            
            # Пробуем аутентифицироваться
            try:
                self.gl.auth()
            except Exception as auth_error:
                logger.warning(f"GitLab auth failed, trying without auth: {auth_error}")
            
            # Пробуем получить информацию о текущем пользователе
            try:
                user = self.gl.user
                if user is None:
                    # Если user is None, пробуем альтернативный способ
                    try:
                        # Пробуем получить список проектов как тест подключения
                        projects = self.gl.projects.list(per_page=1)
                        return {
                            'success': True,
                            'message': 'GitLab доступен',
                            'user_info': {
                                'id': 'unknown',
                                'username': 'authenticated',
                                'name': 'GitLab User',
                                'email': 'user@gitlab.com'
                            }
                        }
                    except Exception as project_error:
                        return {
                            'success': False,
                            'message': f'GitLab недоступен: Не удалось получить информацию о пользователе - {str(project_error)}',
                            'error': str(project_error)
                        }
                
                return {
                    'success': True,
                    'message': 'GitLab доступен',
                    'user_info': {
                        'id': getattr(user, 'id', 'unknown'),
                        'username': getattr(user, 'username', 'unknown'),
                        'name': getattr(user, 'name', 'unknown'),
                        'email': getattr(user, 'email', 'unknown')
                    }
                }
            except Exception as user_error:
                logger.error(f"GitLab user info failed: {user_error}")
                # Пробуем альтернативный способ - получить список проектов
                try:
                    projects = self.gl.projects.list(per_page=1)
                    return {
                        'success': True,
                        'message': 'GitLab доступен (ограниченный доступ)',
                        'user_info': {
                            'id': 'unknown',
                            'username': 'authenticated',
                            'name': 'GitLab User',
                            'email': 'user@gitlab.com'
                        }
                    }
                except Exception as project_error:
                    return {
                        'success': False,
                        'message': f'GitLab недоступен: {str(user_error)}',
                        'error': str(user_error)
                    }
        except Exception as e:
            logger.error(f"GitLab connection test failed: {e}")
            return {
                'success': False,
                'message': f'GitLab недоступен: {str(e)}',
                'error': str(e)
            }
    
    async def search_users_by_name_or_email(self, search_term: str) -> List[Dict[str, Any]]:
        """Поиск пользователей в GitLab по имени или email"""
        try:
            users = []
            
            # Поиск по username
            try:
                username_results = self.gl.users.list(username=search_term)
                if username_results:
                    for user in username_results:
                        if user is not None and hasattr(user, 'id') and user.id is not None:
                            users.append({
                                'id': user.id,
                                'username': getattr(user, 'username', ''),
                                'name': getattr(user, 'name', ''),
                                'email': getattr(user, 'email', ''),
                                'state': getattr(user, 'state', ''),
                                'created_at': getattr(user, 'created_at', ''),
                                'last_activity_on': getattr(user, 'last_activity_on', ''),
                                'match_type': 'username'
                            })
            except:
                pass
            
            # Поиск по email
            try:
                email_results = self.gl.users.list(search=search_term)
                if email_results:
                    for user in email_results:
                        if (user is not None and hasattr(user, 'id') and user.id is not None and 
                            hasattr(user, 'email') and user.email == search_term):
                            # Проверяем, не добавлен ли уже этот пользователь
                            if not any(u['id'] == user.id for u in users):
                                users.append({
                                    'id': user.id,
                                    'username': getattr(user, 'username', ''),
                                    'name': getattr(user, 'name', ''),
                                    'email': getattr(user, 'email', ''),
                                    'state': getattr(user, 'state', ''),
                                    'created_at': getattr(user, 'created_at', ''),
                                    'last_activity_on': getattr(user, 'last_activity_on', ''),
                                    'match_type': 'email'
                                })
            except:
                pass
            
            # Поиск по имени (частичное совпадение)
            try:
                name_results = self.gl.users.list(search=search_term)
                if name_results:
                    for user in name_results:
                        if (user is not None and hasattr(user, 'id') and user.id is not None and
                            hasattr(user, 'name') and hasattr(user, 'username')):
                            # Проверяем, не добавлен ли уже этот пользователь
                            if not any(u['id'] == user.id for u in users):
                                # Проверяем частичное совпадение имени
                                user_name = getattr(user, 'name', '') or ''
                                user_username = getattr(user, 'username', '') or ''
                                if (search_term.lower() in user_name.lower() or 
                                    search_term.lower() in user_username.lower()):
                                    users.append({
                                        'id': user.id,
                                        'username': getattr(user, 'username', ''),
                                        'name': getattr(user, 'name', ''),
                                        'email': getattr(user, 'email', ''),
                                        'state': getattr(user, 'state', ''),
                                        'created_at': getattr(user, 'created_at', ''),
                                        'last_activity_on': getattr(user, 'last_activity_on', ''),
                                        'match_type': 'name'
                                    })
            except:
                pass
            
            logger.info(f"Found {len(users)} GitLab users for search term: {search_term}")
            return users
            
        except Exception as e:
            logger.error(f"Error searching GitLab users: {e}")
            return []


class RedmineAPI:
    def __init__(self, url: str, token: str):
        self.url = url
        self.token = token
        # Создаем Redmine клиент с отключенной проверкой SSL
        self.redmine = Redmine(url, key=token, requests={'verify': False})
    
    async def create_user(self, user_data: Dict[str, Any]) -> Optional[int]:
        """Создание пользователя в Redmine"""
        try:
            username = user_data['username']
            email = user_data['email']
            first_name = user_data['first_name']
            last_name = user_data['last_name']
            
            # Проверяем, существует ли пользователь
            try:
                existing_user = self.redmine.user.filter(name=username)
                if existing_user:
                    logger.info(f"User {username} already exists in Redmine")
                    return existing_user[0].id
            except:
                pass
            
            # Создаем нового пользователя
            user = self.redmine.user.create(
                login=username,
                firstname=first_name,
                lastname=last_name,
                mail=email,
                password='TempPassword123!',  # Временный пароль
                status=1,  # Active
                mail_notification='only_my_events'
            )
            
            logger.info(f"Created Redmine user {username} with ID {user.id}")
            return user.id
            
        except Exception as e:
            logger.error(f"Error creating Redmine user: {e}")
            return None
    
    async def get_user_sequential_number(self, user_id: int) -> Optional[int]:
        """Получение порядкового номера пользователя в Redmine"""
        try:
            user = self.redmine.user.get(user_id)
            # В Redmine порядковый номер пользователя - это его ID
            # Но можно также получить информацию о том, когда пользователь был создан
            logger.info(f"Redmine user {user_id} sequential number: {user_id}")
            return user_id
        except Exception as e:
            logger.error(f"Error getting Redmine user sequential number: {e}")
            return None
    
    async def get_user_info(self, user_id: int) -> Optional[Dict[str, Any]]:
        """Получение информации о пользователе из Redmine"""
        try:
            user = self.redmine.user.get(user_id)
            return {
                'id': user.id,
                'login': user.login,
                'firstname': user.firstname,
                'lastname': user.lastname,
                'mail': user.mail,
                'status': user.status,
                'created_on': user.created_on,
                'last_login_on': user.last_login_on
            }
        except Exception as e:
            logger.error(f"Error getting Redmine user info: {e}")
            return None
    
    async def find_user_by_username(self, username: str) -> Optional[Dict[str, Any]]:
        """Поиск пользователя в Redmine по username"""
        try:
            users = self.redmine.user.filter(name=username)
            if users:
                user = users[0]
                return {
                    'id': user.id,
                    'login': user.login,
                    'firstname': user.firstname,
                    'lastname': user.lastname,
                    'mail': user.mail,
                    'status': user.status,
                    'created_on': user.created_on,
                    'last_login_on': user.last_login_on
                }
            return None
        except Exception as e:
            logger.error(f"Error finding Redmine user by username {username}: {e}")
            return None
    
    async def find_user_by_email(self, email: str) -> Optional[Dict[str, Any]]:
        """Поиск пользователя в Redmine по email"""
        try:
            users = self.redmine.user.filter(mail=email)
            if users:
                user = users[0]
                return {
                    'id': user.id,
                    'login': user.login,
                    'firstname': user.firstname,
                    'lastname': user.lastname,
                    'mail': user.mail,
                    'status': user.status,
                    'created_on': user.created_on,
                    'last_login_on': user.last_login_on
                }
            return None
        except Exception as e:
            logger.error(f"Error finding Redmine user by email {email}: {e}")
            return None
    
    async def find_existing_user(self, username: str, email: str) -> Optional[Dict[str, Any]]:
        """Поиск существующего пользователя в Redmine по username или email"""
        try:
            # Сначала ищем по username
            user = await self.find_user_by_username(username)
            if user:
                logger.info(f"Found Redmine user by username: {username}")
                return user
            
            # Если не найден по username, ищем по email
            user = await self.find_user_by_email(email)
            if user:
                logger.info(f"Found Redmine user by email: {email}")
                return user
            
            logger.info(f"No existing Redmine user found for username: {username} or email: {email}")
            return None
        except Exception as e:
            logger.error(f"Error finding existing Redmine user: {e}")
            return None
    
    async def add_user_to_project(self, user_id: int, project_id: str, role_id: int = 4) -> bool:
        """Добавление пользователя к проекту в Redmine"""
        try:
            member = self.redmine.project_membership.create(
                project_id=project_id,
                user_id=user_id,
                role_ids=[role_id]  # 4 = Developer role
            )
            logger.info(f"Added user {user_id} to project {project_id}")
            return True
        except Exception as e:
            logger.error(f"Error adding user to Redmine project: {e}")
            return False
    
    async def test_connection(self) -> Dict[str, Any]:
        """Проверка подключения к Redmine"""
        try:
            # Пробуем получить информацию о текущем пользователе
            user = self.redmine.user.get('current')
            return {
                'success': True,
                'message': 'Redmine доступен',
                'user_info': {
                    'id': user.id,
                    'login': user.login,
                    'firstname': user.firstname,
                    'lastname': user.lastname,
                    'mail': user.mail
                }
            }
        except Exception as e:
            logger.error(f"Redmine connection test failed: {e}")
            return {
                'success': False,
                'message': f'Redmine недоступен: {str(e)}',
                'error': str(e)
            }
    
    async def search_users_by_name_or_email(self, search_term: str) -> List[Dict[str, Any]]:
        """Поиск пользователей в Redmine по имени или email"""
        try:
            users = []
            
            # Поиск по login (username)
            try:
                login_results = self.redmine.user.filter(name=search_term)
                for user in login_results:
                    users.append({
                        'id': user.id,
                        'login': user.login,
                        'firstname': user.firstname,
                        'lastname': user.lastname,
                        'mail': user.mail,
                        'status': user.status,
                        'created_on': user.created_on,
                        'last_login_on': user.last_login_on,
                        'match_type': 'login'
                    })
            except:
                pass
            
            # Поиск по email
            try:
                email_results = self.redmine.user.filter(mail=search_term)
                for user in email_results:
                    # Проверяем, не добавлен ли уже этот пользователь
                    if not any(u['id'] == user.id for u in users):
                        users.append({
                            'id': user.id,
                            'login': user.login,
                            'firstname': user.firstname,
                            'lastname': user.lastname,
                            'mail': user.mail,
                            'status': user.status,
                            'created_on': user.created_on,
                            'last_login_on': user.last_login_on,
                            'match_type': 'email'
                        })
            except:
                pass
            
            # Поиск по имени (частичное совпадение)
            try:
                # Получаем всех пользователей и фильтруем по имени
                all_users = self.redmine.user.all()
                for user in all_users:
                    # Проверяем, не добавлен ли уже этот пользователь
                    if not any(u['id'] == user.id for u in users):
                        full_name = f"{user.firstname} {user.lastname}".lower()
                        if (search_term.lower() in full_name or 
                            search_term.lower() in user.login.lower()):
                            users.append({
                                'id': user.id,
                                'login': user.login,
                                'firstname': user.firstname,
                                'lastname': user.lastname,
                                'mail': user.mail,
                                'status': user.status,
                                'created_on': user.created_on,
                                'last_login_on': user.last_login_on,
                                'match_type': 'name'
                            })
            except:
                pass
            
            logger.info(f"Found {len(users)} Redmine users for search term: {search_term}")
            return users
            
        except Exception as e:
            logger.error(f"Error searching Redmine users: {e}")
            return []
    
    async def get_user_projects(self, username: str) -> List[Dict[str, Any]]:
        """
        Получение всех проектов пользователя из Redmine по username.
        
        Args:
            username: Логин пользователя в Redmine
            
        Returns:
            Список проектов пользователя с информацией о каждом проекте
        """
        try:
            projects = []
            
            # Сначала находим пользователя по username
            users = self.redmine.user.filter(name=username)
            if not users:
                logger.warning(f"User {username} not found in Redmine")
                return []
            
            user = users[0]
            user_id = user.id
            
            # Получаем все членства пользователя в проектах
            try:
                # Получаем пользователя с включенными связями
                user_detail = self.redmine.user.get(user_id, include='memberships')
                
                if hasattr(user_detail, 'memberships'):
                    for membership in user_detail.memberships:
                        try:
                            project_info = {
                                'id': membership.project.id,
                                'name': membership.project.name,
                                'roles': [role.name for role in membership.roles] if hasattr(membership, 'roles') else []
                            }
                            
                            # Пытаемся получить дополнительную информацию о проекте
                            try:
                                project_detail = self.redmine.project.get(membership.project.id)
                                project_info['identifier'] = getattr(project_detail, 'identifier', '')
                                project_info['description'] = getattr(project_detail, 'description', '')
                                project_info['status'] = getattr(project_detail, 'status', 1)
                                project_info['created_on'] = getattr(project_detail, 'created_on', None)
                            except:
                                pass
                            
                            projects.append(project_info)
                        except Exception as e:
                            logger.error(f"Error processing membership: {e}")
                            continue
                            
            except Exception as e:
                logger.error(f"Error getting user memberships: {e}")
            
            logger.info(f"Found {len(projects)} projects for user {username}")
            return projects
            
        except Exception as e:
            logger.error(f"Error getting user projects from Redmine: {e}")
            return []


class KubernetesAPI:
    def __init__(self, api_url: str, token: str):
        self.api_url = api_url
        self.token = token
        self.headers = {
            'Authorization': f'Bearer {token}',
            'Content-Type': 'application/json'
        }
        
        # Создаем SSL контекст с отключенной проверкой сертификатов один раз
        self.ssl_context = ssl.create_default_context()
        self.ssl_context.check_hostname = False
        self.ssl_context.verify_mode = ssl.CERT_NONE
        
        # Создаем коннектор с отключенной проверкой SSL
        self.connector = aiohttp.TCPConnector(ssl=self.ssl_context)
    
    async def create_namespace(self, namespace: str) -> bool:
        """Создание namespace в Kubernetes"""
        try:
            async with aiohttp.ClientSession(connector=self.connector) as session:
                url = f"{self.api_url}/api/v1/namespaces"
                data = {
                    "apiVersion": "v1",
                    "kind": "Namespace",
                    "metadata": {
                        "name": namespace
                    }
                }
                
                async with session.post(url, json=data, headers=self.headers) as response:
                    if response.status in [200, 201]:
                        logger.info(f"Created Kubernetes namespace {namespace}")
                        return True
                    else:
                        logger.error(f"Failed to create namespace: {response.status}")
                        return False
                        
        except Exception as e:
            logger.error(f"Error creating Kubernetes namespace: {e}")
            return False
    
    async def create_service_account(self, namespace: str, name: str) -> bool:
        """Создание ServiceAccount в Kubernetes"""
        try:
            async with aiohttp.ClientSession(connector=self.connector) as session:
                url = f"{self.api_url}/api/v1/namespaces/{namespace}/serviceaccounts"
                data = {
                    "apiVersion": "v1",
                    "kind": "ServiceAccount",
                    "metadata": {
                        "name": name,
                        "namespace": namespace
                    }
                }
                
                async with session.post(url, json=data, headers=self.headers) as response:
                    if response.status in [200, 201]:
                        logger.info(f"Created ServiceAccount {name} in namespace {namespace}")
                        return True
                    else:
                        logger.error(f"Failed to create ServiceAccount: {response.status}")
                        return False
                        
        except Exception as e:
            logger.error(f"Error creating Kubernetes ServiceAccount: {e}")
            return False
    
    async def test_connection(self) -> Dict[str, Any]:
        """Проверка подключения к Kubernetes"""
        try:
            logger.info(f"Testing Kubernetes connection to: {self.api_url}")
            logger.info(f"Using SSL context with verify_mode: {self.ssl_context.verify_mode}")
            
            async with aiohttp.ClientSession(connector=self.connector) as session:
                # Пробуем получить информацию о кластере
                url = f"{self.api_url}/api/v1"
                logger.info(f"Making request to: {url}")
                
                async with session.get(url, headers=self.headers) as response:
                    logger.info(f"Response status: {response.status}")
                    logger.info(f"Response headers: {dict(response.headers)}")
                    
                    if response.status == 200:
                        return {
                            'success': True,
                            'message': 'Kubernetes доступен',
                            'cluster_info': {
                                'status': 'connected',
                                'api_version': 'v1'
                            }
                        }
                    else:
                        response_text = await response.text()
                        logger.error(f"Kubernetes API error: {response.status} - {response_text}")
                        return {
                            'success': False,
                            'message': f'Kubernetes недоступен: HTTP {response.status}',
                            'error': f'HTTP {response.status}',
                            'response_text': response_text
                        }
        except Exception as e:
            logger.error(f"Kubernetes connection test failed: {e}")
            return {
                'success': False,
                'message': f'Kubernetes недоступен: {str(e)}',
                'error': str(e)
            }
    
    async def search_service_accounts_by_name(self, search_term: str) -> List[Dict[str, Any]]:
        """Поиск ServiceAccount в Kubernetes по имени"""
        try:
            service_accounts = []
            
            async with aiohttp.ClientSession(connector=self.connector) as session:
                # Получаем список всех namespace
                namespaces_url = f"{self.api_url}/api/v1/namespaces"
                async with session.get(namespaces_url, headers=self.headers) as response:
                    if response.status == 200:
                        namespaces_data = await response.json()
                        
                        for namespace in namespaces_data.get('items', []):
                            namespace_name = namespace['metadata']['name']
                            
                            # Получаем ServiceAccount в каждом namespace
                            sa_url = f"{self.api_url}/api/v1/namespaces/{namespace_name}/serviceaccounts"
                            async with session.get(sa_url, headers=self.headers) as sa_response:
                                if sa_response.status == 200:
                                    sa_data = await sa_response.json()
                                    
                                    for sa in sa_data.get('items', []):
                                        sa_name = sa['metadata']['name']
                                        
                                        # Проверяем совпадение по имени
                                        if search_term.lower() in sa_name.lower():
                                            service_accounts.append({
                                                'name': sa_name,
                                                'namespace': namespace_name,
                                                'creation_timestamp': sa['metadata'].get('creationTimestamp'),
                                                'uid': sa['metadata'].get('uid'),
                                                'match_type': 'name'
                                            })
            
            logger.info(f"Found {len(service_accounts)} Kubernetes ServiceAccounts for search term: {search_term}")
            return service_accounts
            
        except Exception as e:
            logger.error(f"Error searching Kubernetes ServiceAccounts: {e}")
            return []
    
    async def check_user_namespace_with_postgres(self, redmine_id: int) -> Dict[str, Any]:
        """Проверка namespace пользователя и выполнение команды в PostgreSQL"""
        try:
            namespace = f"user-{redmine_id}"
            
            # Выполняем kubectl команду
            cmd = [
                'kubectl', 
                '-n', namespace, 
                'exec', '-t', '-i', 
                'postgres-0', 
                'psql', 
                '\\l'
            ]
            
            logger.info(f"Executing kubectl command: {' '.join(cmd)}")
            
            # Выполняем команду асинхронно
            process = await asyncio.create_subprocess_exec(
                *cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            
            stdout, stderr = await process.communicate()
            
            if process.returncode == 0:
                # Команда выполнена успешно
                output = stdout.decode('utf-8')
                return {
                    'success': True,
                    'namespace': namespace,
                    'redmine_id': redmine_id,
                    'postgres_available': True,
                    'databases': self._parse_postgres_databases(output),
                    'raw_output': output,
                    'message': f'Namespace {namespace} найден, PostgreSQL доступен'
                }
            else:
                # Команда завершилась с ошибкой
                error_output = stderr.decode('utf-8')
                return {
                    'success': False,
                    'namespace': namespace,
                    'redmine_id': redmine_id,
                    'postgres_available': False,
                    'error': error_output,
                    'message': f'Namespace {namespace} не найден или PostgreSQL недоступен'
                }
                
        except Exception as e:
            logger.error(f"Error checking user namespace with PostgreSQL: {e}")
            return {
                'success': False,
                'namespace': f'user-{redmine_id}',
                'redmine_id': redmine_id,
                'postgres_available': False,
                'error': str(e),
                'message': f'Ошибка при проверке namespace user-{redmine_id}: {str(e)}'
            }
    
    def _parse_postgres_databases(self, output: str) -> List[str]:
        """Парсинг вывода psql \\l для извлечения списка баз данных"""
        try:
            databases = []
            lines = output.split('\n')
            
            # Ищем строки с базами данных (обычно начинаются с пробела и содержат |)
            for line in lines:
                line = line.strip()
                if '|' in line and not line.startswith('Name') and not line.startswith('----'):
                    # Извлекаем имя базы данных (первая колонка)
                    db_name = line.split('|')[0].strip()
                    if db_name and db_name not in ['template0', 'template1', 'postgres']:
                        databases.append(db_name)
            
            return databases
            
        except Exception as e:
            logger.error(f"Error parsing PostgreSQL databases: {e}")
            return []
    
    async def find_all_postgres_pods(self) -> List[Dict[str, Any]]:
        """Поиск всех подов postgres-0 в неймспейсах user-$ID"""
        try:
            postgres_pods = []
            
            async with aiohttp.ClientSession(connector=self.connector) as session:
                # Получаем список всех неймспейсов
                namespaces_url = f"{self.api_url}/api/v1/namespaces"
                async with session.get(namespaces_url, headers=self.headers) as response:
                    if response.status == 200:
                        namespaces_data = await response.json()
                        
                        # Фильтруем неймспейсы по паттерну user-$ID
                        user_namespaces = []
                        for namespace in namespaces_data.get('items', []):
                            namespace_name = namespace['metadata']['name']
                            if namespace_name.startswith('user-'):
                                user_namespaces.append(namespace_name)
                        
                        # Ищем поды postgres-0 в каждом user namespace
                        for namespace in user_namespaces:
                            pods_url = f"{self.api_url}/api/v1/namespaces/{namespace}/pods"
                            async with session.get(pods_url, headers=self.headers) as pods_response:
                                if pods_response.status == 200:
                                    pods_data = await pods_response.json()
                                    
                                    for pod in pods_data.get('items', []):
                                        pod_name = pod['metadata']['name']
                                        
                                        # Ищем поды с именем postgres-0
                                        if pod_name == 'postgres-0':
                                            # Извлекаем ID разработчика из namespace
                                            redmine_id = namespace.replace('user-', '')
                                            
                                            # Получаем статус пода
                                            pod_status = pod['status'].get('phase', 'Unknown')
                                            
                                            # Получаем время создания
                                            creation_timestamp = pod['metadata'].get('creationTimestamp')
                                            
                                            # Получаем IP адрес пода
                                            pod_ip = pod['status'].get('podIP', 'Unknown')
                                            
                                            postgres_pods.append({
                                                'name': pod_name,
                                                'namespace': namespace,
                                                'redmine_id': redmine_id,
                                                'status': pod_status,
                                                'pod_ip': pod_ip,
                                                'creation_timestamp': creation_timestamp,
                                                'uid': pod['metadata'].get('uid'),
                                                'node_name': pod['spec'].get('nodeName', 'Unknown')
                                            })
            
            # Сортируем по namespace (user-$ID)
            postgres_pods.sort(key=lambda x: x['namespace'])
            
            logger.info(f"Found {len(postgres_pods)} postgres-0 pods in user namespaces")
            return postgres_pods
            
        except Exception as e:
            logger.error(f"Error finding postgres pods: {e}")
            return []
    
    async def get_namespaces_by_redmine_id(self, redmine_id: int) -> List[Dict[str, Any]]:
        """
        Получение всех namespaces из Kubernetes для пользователя по Redmine ID.
        
        Args:
            redmine_id: ID пользователя в Redmine
            
        Returns:
            Список namespaces с информацией о spec и status
        """
        try:
            matching_namespaces = []
            
            async with aiohttp.ClientSession(connector=self.connector) as session:
                # Получаем список всех namespaces
                url = f"{self.api_url}/api/v1/namespaces"
                logger.info(f"Fetching namespaces from: {url}")
                
                async with session.get(url, headers=self.headers) as response:
                    if response.status == 200:
                        data = await response.json()
                        items = data.get('items', [])
                        
                        logger.info(f"Found {len(items)} namespaces in Kubernetes")
                        
                        # Обрабатываем каждый namespace
                        for item in items:
                            metadata = item.get('metadata', {})
                            name = metadata.get('name', '')
                            
                            # Проверяем, начинается ли имя с "user-"
                            if name.startswith('user-'):
                                # Убираем префикс "user-" и получаем ID
                                namespace_id = name.replace('user-', '', 1)
                                
                                # Сравниваем с redmine_id
                                if namespace_id == str(redmine_id):
                                    # Получаем spec и status
                                    spec = item.get('spec', {})
                                    status = item.get('status', {})
                                    
                                    # Определяем статус активности namespace
                                    phase = status.get('phase', 'Unknown')
                                    
                                    namespace_info = {
                                        'name': name,
                                        'redmine_id': namespace_id,
                                        'metadata': metadata,
                                        'spec': spec,
                                        'status': status,
                                        'phase': phase,
                                        'is_active': phase.lower() == 'active',
                                        'creation_timestamp': metadata.get('creationTimestamp'),
                                        'uid': metadata.get('uid'),
                                        'labels': metadata.get('labels', {}),
                                        'annotations': metadata.get('annotations', {})
                                    }
                                    
                                    matching_namespaces.append(namespace_info)
                                    logger.info(f"Found matching namespace: {name} with phase: {phase}")
                        
                        logger.info(f"Found {len(matching_namespaces)} matching namespaces for Redmine ID {redmine_id}")
                        return matching_namespaces
                    else:
                        logger.error(f"Failed to fetch namespaces: HTTP {response.status}")
                        return []
                        
        except Exception as e:
            logger.error(f"Error getting namespaces by Redmine ID: {e}")
            return []
    
    async def get_postgres_pod_details(self, namespace: str, pod_name: str = 'postgres-0') -> Dict[str, Any]:
        """Получение детальной информации о поде postgres-0"""
        try:
            async with aiohttp.ClientSession(connector=self.connector) as session:
                # Получаем информацию о поде
                pod_url = f"{self.api_url}/api/v1/namespaces/{namespace}/pods/{pod_name}"
                async with session.get(pod_url, headers=self.headers) as response:
                    if response.status == 200:
                        pod_data = await response.json()
                        
                        # Получаем события пода
                        events_url = f"{self.api_url}/api/v1/namespaces/{namespace}/events"
                        events_params = {
                            'fieldSelector': f'involvedObject.name={pod_name}'
                        }
                        
                        events = []
                        async with session.get(events_url, headers=self.headers, params=events_params) as events_response:
                            if events_response.status == 200:
                                events_data = await events_response.json()
                                events = events_data.get('items', [])
                        
                        return {
                            'success': True,
                            'pod': {
                                'name': pod_data['metadata']['name'],
                                'namespace': pod_data['metadata']['namespace'],
                                'status': pod_data['status'].get('phase', 'Unknown'),
                                'pod_ip': pod_data['status'].get('podIP', 'Unknown'),
                                'node_name': pod_data['spec'].get('nodeName', 'Unknown'),
                                'creation_timestamp': pod_data['metadata'].get('creationTimestamp'),
                                'uid': pod_data['metadata'].get('uid'),
                                'labels': pod_data['metadata'].get('labels', {}),
                                'annotations': pod_data['metadata'].get('annotations', {})
                            },
                            'events': events,
                            'containers': [
                                {
                                    'name': container['name'],
                                    'image': container['image'],
                                    'ready': container.get('ready', False),
                                    'restart_count': container.get('restartCount', 0)
                                }
                                for container in pod_data['status'].get('containerStatuses', [])
                            ]
                        }
                    else:
                        return {
                            'success': False,
                            'message': f'Pod {pod_name} not found in namespace {namespace}',
                            'error': f'HTTP {response.status}'
                        }
                        
        except Exception as e:
            logger.error(f"Error getting postgres pod details: {e}")
            return {
                'success': False,
                'message': f'Error getting pod details: {str(e)}',
                'error': str(e)
            }

