#!/usr/bin/env python3
"""
Скрипт для тестирования docker_init.py с проверкой доступности базы данных
"""

import asyncio
import sys
import os
from pathlib import Path

# Добавляем текущую директорию в путь
sys.path.insert(0, str(Path(__file__).parent))

from docker_init import wait_for_database, test_database_connection, docker_init


async def test_database_availability():
    """Тестирование проверки доступности базы данных"""
    print("🧪 Тестирование проверки доступности базы данных...")
    print("="*60)
    
    # Тест 1: Проверка доступности базы данных
    print("\n1️⃣ Тест проверки доступности базы данных:")
    is_available = await wait_for_database(max_retries=3, retry_delay=1)
    if is_available:
        print("✅ База данных доступна")
    else:
        print("❌ База данных недоступна")
    
    # Тест 2: Тестирование подключения
    print("\n2️⃣ Тест подключения к базе данных:")
    connection_ok = await test_database_connection()
    if connection_ok:
        print("✅ Подключение к базе данных работает")
    else:
        print("❌ Подключение к базе данных не работает")
    
    # Тест 3: Полная инициализация (если база доступна)
    if is_available and connection_ok:
        print("\n3️⃣ Тест полной инициализации:")
        try:
            await docker_init()
            print("✅ Полная инициализация завершена")
        except Exception as e:
            print(f"❌ Ошибка при полной инициализации: {e}")
    else:
        print("\n3️⃣ Тест полной инициализации пропущен (база недоступна)")
    
    print("\n" + "="*60)
    print("🎉 Тестирование завершено!")


async def test_with_different_retry_settings():
    """Тестирование с разными настройками повторных попыток"""
    print("\n🔧 Тестирование с разными настройками...")
    
    # Тест с быстрыми повторными попытками
    print("\n📊 Тест с быстрыми повторными попытками (3 попытки, 1 сек):")
    result = await wait_for_database(max_retries=3, retry_delay=1)
    print(f"Результат: {'✅ Успешно' if result else '❌ Неудачно'}")
    
    # Тест с медленными повторными попытками
    print("\n📊 Тест с медленными повторными попытками (2 попытки, 3 сек):")
    result = await wait_for_database(max_retries=2, retry_delay=3)
    print(f"Результат: {'✅ Успешно' if result else '❌ Неудачно'}")


async def main():
    """Главная функция"""
    if len(sys.argv) > 1 and sys.argv[1] == "help":
        print("Использование:")
        print("  python test_docker_init.py           - Полное тестирование")
        print("  python test_docker_init.py quick     - Быстрое тестирование")
        print("  python test_docker_init.py help      - Показать эту справку")
    elif len(sys.argv) > 1 and sys.argv[1] == "quick":
        print("🚀 Быстрое тестирование docker_init.py...")
        await test_database_availability()
    else:
        print("🚀 Полное тестирование docker_init.py...")
        await test_database_availability()
        await test_with_different_retry_settings()


if __name__ == "__main__":
    asyncio.run(main())

