#!/usr/bin/env python3
"""Инициализация базы данных"""

import asyncio
import subprocess
import sys
from database import get_async_session
from models import Project, Developer, DeveloperProject
from sqlalchemy import select

async def init_database():
    print("🚀 Инициализация базы данных...")
    
    try:
        # Запускаем миграции
        print("📦 Запуск миграций...")
        result = subprocess.run([
            sys.executable, "-m", "alembic", "upgrade", "head"
        ], capture_output=True, text=True)
        
        if result.returncode != 0:
            print(f"❌ Ошибка миграций: {result.stderr}")
            return False
        
        print("✅ Миграции выполнены успешно")
        
        # Инициализируем проекты
        print("📁 Инициализация проектов...")
        async for session in get_async_session():
            try:
                # Проверяем, есть ли уже проекты
                result = await session.execute(select(Project))
                existing_projects = result.scalars().all()
                
                if existing_projects:
                    print(f"✅ Проекты уже существуют: {len(existing_projects)}")
                    for project in existing_projects:
                        print(f"   - {project.name} (ID: {project.id})")
                else:
                    # Создаем тестовые проекты
                    test_projects = [
                        Project(name="Веб-приложение", description="Основное веб-приложение компании"),
                        Project(name="Мобильное приложение", description="Мобильное приложение для iOS и Android"),
                        Project(name="API сервис", description="REST API для интеграции с внешними системами"),
                        Project(name="Админ панель", description="Панель администратора для управления системой"),
                        Project(name="Аналитика", description="Система аналитики и отчетности"),
                        Project(name="Интеграции", description="Интеграции с GitLab, Redmine, Kubernetes")
                    ]
                    
                    for project in test_projects:
                        session.add(project)
                    
                    await session.commit()
                    print("✅ Тестовые проекты созданы!")
                    
                    # Проверяем результат
                    result = await session.execute(select(Project))
                    projects = result.scalars().all()
                    print(f"📊 Создано проектов: {len(projects)}")
                    for project in projects:
                        print(f"   - {project.name} (ID: {project.id})")
                
                # Проверяем разработчиков
                result = await session.execute(select(Developer))
                developers = result.scalars().all()
                print(f"👥 Разработчиков в базе: {len(developers)}")
                
                if developers:
                    for dev in developers:
                        print(f"   - {dev.first_name} {dev.last_name} ({dev.email})")
                        if dev.redmine_user_id:
                            print(f"     Redmine ID: {dev.redmine_user_id}")
                        if dev.rm_id:
                            print(f"     RM ID: {dev.rm_id}")
                
            except Exception as e:
                print(f"❌ Ошибка при инициализации: {e}")
            break
        
        print("🎉 Инициализация базы данных завершена!")
        return True
        
    except Exception as e:
        print(f"❌ Критическая ошибка: {e}")
        return False

if __name__ == "__main__":
    success = asyncio.run(init_database())
    if success:
        print("\n✅ База данных готова к работе!")
        print("🌐 Запустите приложение: python main.py")
    else:
        print("\n❌ Ошибка инициализации базы данных")
        sys.exit(1)

