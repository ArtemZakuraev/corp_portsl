#!/usr/bin/env python3
"""
Тестовый скрипт для проверки подключения к базе данных
"""
import asyncio
import sys
import os

async def test_database_connection():
    """Тестирует подключение к базе данных"""
    try:
        # Импортируем engine из database
        from database import engine
        print("✅ Импорт engine успешен")
        
        # Тестируем подключение
        async with engine.begin() as conn:
            result = await conn.execute("SELECT 1 as test")
            test_value = result.scalar()
            print(f"✅ Подключение к базе данных работает: {test_value}")
            return True
            
    except ImportError as e:
        print(f"❌ Ошибка импорта: {e}")
        return False
    except Exception as e:
        print(f"❌ Ошибка подключения к базе данных: {e}")
        return False
    finally:
        try:
            await engine.dispose()
        except:
            pass

if __name__ == "__main__":
    print("🔧 Тестирование подключения к базе данных...")
    success = asyncio.run(test_database_connection())
    if success:
        print("✅ Тест завершен успешно!")
    else:
        print("❌ Тест завершен с ошибками!")
    sys.exit(0 if success else 1)


