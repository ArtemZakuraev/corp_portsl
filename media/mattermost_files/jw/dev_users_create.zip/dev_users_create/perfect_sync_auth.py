#!/usr/bin/env python3
"""
Идеальная синхронная система аутентификации с синхронными операциями с базой данных
"""

import logging
from typing import Optional
from jose import JWTError, jwt
from fastapi import Request
from models import User
from config import settings
from utils import verify_password
import asyncio
import concurrent.futures
import threading
import os
import sys
from pathlib import Path

# Добавляем путь к проекту
sys.path.insert(0, str(Path(__file__).parent))

logger = logging.getLogger(__name__)


def get_user_by_username_perfect(username: str) -> Optional[User]:
    """Идеальное получение пользователя по имени"""
    try:
        # Создаем новый event loop в отдельном потоке
        def run_async_in_thread():
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            try:
                async def _get_user():
                    from database import async_session_maker
                    from sqlalchemy import select
                    async with async_session_maker() as session:
                        result = await session.execute(select(User).where(User.username == username))
                        return result.scalar_one_or_none()
                
                return loop.run_until_complete(_get_user())
            finally:
                loop.close()
        
        # Выполняем в отдельном потоке
        with concurrent.futures.ThreadPoolExecutor() as executor:
            future = executor.submit(run_async_in_thread)
            user = future.result(timeout=10)
            return user
            
    except Exception as e:
        logger.error(f"Ошибка при получении пользователя {username}: {e}")
        return None


def authenticate_user_perfect(username: str, password: str) -> Optional[User]:
    """Идеальная аутентификация пользователя"""
    try:
        user = get_user_by_username_perfect(username)
        if not user:
            return None
        
        if not verify_password(password, user.password_hash):
            return None
        
        return user
    except Exception as e:
        logger.error(f"Ошибка при аутентификации пользователя {username}: {e}")
        return None


def get_user_from_cookie_perfect(request: Request) -> Optional[User]:
    """Идеальное получение пользователя из cookie"""
    try:
        # Проверяем cookie
        token = request.cookies.get("access_token")
        if not token:
            return None
        
        # Убеждаемся, что токен имеет правильный формат
        if not token.startswith("Bearer "):
            token = f"Bearer {token}"
        
        # Извлекаем токен
        token = token.split(" ")[1]
        
        # Декодируем JWT
        payload = jwt.decode(token, settings.secret_key, algorithms=[settings.algorithm])
        username: str = payload.get("sub")
        if username is None:
            return None
        
        # Получаем пользователя идеальным способом
        user = get_user_by_username_perfect(username)
        return user
    except (JWTError, IndexError) as e:
        logger.debug(f"Ошибка при получении пользователя из cookie: {e}")
        return None
    except Exception as e:
        logger.error(f"Ошибка при получении пользователя из cookie: {e}")
        return None


def test_perfect_auth():
    """Тестирование идеальной аутентификации"""
    print("🧪 Тестирование идеальной аутентификации...")
    
    try:
        # Тест получения пользователя
        user = get_user_by_username_perfect("admin")
        if user:
            print(f"✅ Пользователь найден: {user.username}")
        else:
            print("⚠️ Пользователь admin не найден")
        
        # Тест аутентификации
        if user:
            auth_user = authenticate_user_perfect("admin", "admin123")
            if auth_user:
                print("✅ Аутентификация работает")
            else:
                print("❌ Аутентификация не работает")
        
    except Exception as e:
        print(f"❌ Ошибка при тестировании: {e}")


if __name__ == "__main__":
    test_perfect_auth()
