#!/usr/bin/env python3
"""
Скрипт для запуска приложения с автоматической инициализацией базы данных
"""

import asyncio
import uvicorn
import sys
from config import settings

async def init_database_if_needed():
    """Инициализация базы данных если нужно"""
    try:
        from init_db import init_database
        print("🔧 Проверка и инициализация базы данных...")
        await init_database()
        print("✅ База данных готова")
        
        # Проверяем наличие администратора
        from check_admin import check_admin
        await check_admin()
        
    except Exception as e:
        print(f"⚠️ Ошибка при инициализации базы данных: {e}")
        print("Приложение будет запущено, но могут возникнуть проблемы с аутентификацией")

if __name__ == "__main__":
    print("🚀 Запуск Developer Management System...")
    print(f"📊 Версия: {settings.app_version}")
    print(f"🔧 Режим отладки: {'Включен' if settings.debug else 'Выключен'}")
    print(f"🌐 URL: http://localhost:8000")
    print(f"📚 API документация: http://localhost:8000/docs")
    print("\n" + "="*50)
    
    # Инициализируем базу данных
    asyncio.run(init_database_if_needed())
    
    print("\n🚀 Запуск веб-сервера...")
    uvicorn.run(
        "main:app",
        host="0.0.0.0",
        port=8000,
        reload=settings.debug,
        log_level="info"
    )
