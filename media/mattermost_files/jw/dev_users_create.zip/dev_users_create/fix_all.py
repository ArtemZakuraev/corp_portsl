#!/usr/bin/env python3
"""
Скрипт для полного исправления всех проблем системы
"""

import asyncio
import sys
import os
import subprocess

async def fix_all_issues():
    """Исправление всех проблем системы"""
    print("🔧 Полное исправление системы Developer Management System...")
    print("="*60)
    
    # Шаг 1: Обновление зависимостей
    print("\n1️⃣ Обновление зависимостей...")
    try:
        result = subprocess.run([
            sys.executable, "-m", "pip", "install", "-r", "requirements.txt", "--upgrade"
        ], capture_output=True, text=True)
        
        if result.returncode == 0:
            print("✅ Зависимости обновлены успешно")
        else:
            print(f"⚠️ Предупреждение при обновлении зависимостей: {result.stderr}")
    except Exception as e:
        print(f"⚠️ Ошибка при обновлении зависимостей: {e}")
    
    # Шаг 2: Исправление паролей
    print("\n2️⃣ Исправление системы паролей...")
    try:
        from fix_passwords import fix_user_passwords, test_password_system
        
        # Тестируем систему паролей
        await test_password_system()
        
        # Исправляем пароли пользователей
        await fix_user_passwords()
        
        print("✅ Система паролей исправлена")
    except Exception as e:
        print(f"❌ Ошибка при исправлении паролей: {e}")
    
    # Шаг 3: Инициализация базы данных
    print("\n3️⃣ Инициализация базы данных...")
    try:
        from init_db import init_database
        await init_database()
        print("✅ База данных инициализирована")
    except Exception as e:
        print(f"❌ Ошибка при инициализации базы данных: {e}")
    
    # Шаг 4: Создание тестового администратора
    print("\n4️⃣ Создание тестового администратора...")
    try:
        from fix_passwords import create_test_admin
        await create_test_admin()
        print("✅ Тестовый администратор создан")
    except Exception as e:
        print(f"⚠️ Ошибка при создании тестового администратора: {e}")
    
    # Шаг 5: Финальная проверка
    print("\n5️⃣ Финальная проверка...")
    try:
        from init_db import list_users
        await list_users()
        print("✅ Проверка завершена")
    except Exception as e:
        print(f"⚠️ Ошибка при финальной проверке: {e}")
    
    print("\n" + "="*60)
    print("🎉 Исправление завершено!")
    print("\n📋 Следующие шаги:")
    print("1. Запустите приложение: python run_app.py")
    print("2. Откройте браузер: http://localhost:8000")
    print("3. Войдите в систему:")
    print("   - Логин: admin")
    print("   - Пароль: admin123")
    print("   - Или используйте тестового администратора:")
    print("     - Логин: testadmin")
    print("     - Пароль: test123")
    
    print("\n📚 Дополнительные команды:")
    print("  python fix_passwords.py test      - Тестировать пароли")
    print("  python init_db.py list           - Показать пользователей")
    print("  python init_db.py interactive    - Создать нового администратора")


if __name__ == "__main__":
    asyncio.run(fix_all_issues())

