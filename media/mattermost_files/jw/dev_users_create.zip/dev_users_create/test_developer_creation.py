#!/usr/bin/env python3
"""Тест создания разработчика"""

import asyncio
from database import get_async_session
from models import Developer, Project, DeveloperProject
from sqlalchemy import select

async def test_developer_creation():
    print("Тестирование создания разработчика...")
    
    async for session in get_async_session():
        try:
            # Проверяем проекты
            result = await session.execute(select(Project))
            projects = result.scalars().all()
            print(f"Проектов в базе: {len(projects)}")
            
            if not projects:
                print("Проекты не найдены, создаем тестовые...")
                test_projects = [
                    Project(name="Веб-приложение", description="Основное веб-приложение компании"),
                    Project(name="Мобильное приложение", description="Мобильное приложение для iOS и Android"),
                    Project(name="API сервис", description="REST API для интеграции с внешними системами"),
                ]
                
                for project in test_projects:
                    session.add(project)
                
                await session.commit()
                
                # Получаем проекты снова
                result = await session.execute(select(Project))
                projects = result.scalars().all()
                print(f"Создано проектов: {len(projects)}")
            
            # Создаем тестового разработчика
            test_developer = Developer(
                last_name="Иванов",
                first_name="Иван",
                middle_name="Иванович",
                email="ivan.ivanov@example.com",
                position="Разработчик",
                department="IT",
                phone="+7 (999) 123-45-67",
                telegram="@ivan_ivanov",
                slack="@ivan.ivanov",
                gitlab_user_id=123,
                redmine_user_id=456,
                rm_id="RM-123",
                gitlab_username="ivan.ivanov",
                redmine_username="ivan.ivanov",
                is_active=True,
                notes="Тестовый разработчик"
            )
            
            session.add(test_developer)
            await session.commit()
            await session.refresh(test_developer)
            
            print(f"Разработчик создан: {test_developer.first_name} {test_developer.last_name} (ID: {test_developer.id})")
            
            # Добавляем связи с проектами
            if projects:
                for project in projects[:2]:  # Добавляем к первым двум проектам
                    dev_project = DeveloperProject(
                        developer_id=test_developer.id,
                        project_id=project.id,
                        active=True
                    )
                    session.add(dev_project)
                
                await session.commit()
                print(f"Добавлены связи с {len(projects[:2])} проектами")
            
            # Проверяем результат
            result = await session.execute(select(Developer))
            developers = result.scalars().all()
            print(f"Разработчиков в базе: {len(developers)}")
            
            for dev in developers:
                print(f"- {dev.first_name} {dev.last_name} ({dev.email})")
                if dev.redmine_user_id:
                    print(f"  Redmine ID: {dev.redmine_user_id}")
                if dev.rm_id:
                    print(f"  RM ID: {dev.rm_id}")
                
        except Exception as e:
            print(f"Ошибка: {e}")
        break

if __name__ == "__main__":
    asyncio.run(test_developer_creation())