#!/usr/bin/env python3
"""
Система аутентификации с кэшированием пользователей в памяти
"""

import logging
from typing import Optional, Dict
from jose import JWTError, jwt
from fastapi import Request
from models import User
from config import settings
from utils import verify_password
import asyncio
import threading
import time

logger = logging.getLogger(__name__)

# Кэш пользователей в памяти
_user_cache: Dict[str, User] = {}
_cache_lock = threading.Lock()
_cache_expiry = 300  # 5 минут


def get_user_by_username_memory(username: str) -> Optional[User]:
    """Получение пользователя из кэша памяти"""
    try:
        with _cache_lock:
            # Проверяем кэш
            if username in _user_cache:
                user = _user_cache[username]
                # Проверяем, не истек ли кэш (простая проверка по времени)
                if hasattr(user, '_cached_at') and time.time() - user._cached_at < _cache_expiry:
                    return user
                else:
                    # Удаляем устаревший кэш
                    del _user_cache[username]
            
            # Если пользователя нет в кэше, создаем заглушку
            # В реальном приложении здесь должна быть загрузка из БД
            if username == "admin":
                # Создаем пользователя-заглушку для тестирования
                user = User(
                    id=1,
                    username="admin",
                    email="admin@example.com",
                    password_hash="admin123",  # Пароль без хеширования
                    is_admin=True
                )
                user._cached_at = time.time()
                _user_cache[username] = user
                return user
            
            return None
            
    except Exception as e:
        logger.error(f"Ошибка при получении пользователя {username}: {e}")
        return None


def authenticate_user_memory(username: str, password: str) -> Optional[User]:
    """Аутентификация пользователя через кэш памяти"""
    try:
        user = get_user_by_username_memory(username)
        if not user:
            return None
        
        if not verify_password(password, user.password_hash):
            return None
        
        return user
    except Exception as e:
        logger.error(f"Ошибка при аутентификации пользователя {username}: {e}")
        return None


def get_user_from_cookie_memory(request: Request) -> Optional[User]:
    """Получение пользователя из cookie через кэш памяти"""
    try:
        # Проверяем cookie
        token = request.cookies.get("access_token")
        if not token:
            return None
        
        # Убеждаемся, что токен имеет правильный формат
        if not token.startswith("Bearer "):
            token = f"Bearer {token}"
        
        # Извлекаем токен
        token = token.split(" ")[1]
        
        # Декодируем JWT
        payload = jwt.decode(token, settings.secret_key, algorithms=[settings.algorithm])
        username: str = payload.get("sub")
        if username is None:
            return None
        
        # Получаем пользователя из кэша памяти
        user = get_user_by_username_memory(username)
        return user
    except (JWTError, IndexError) as e:
        logger.debug(f"Ошибка при получении пользователя из cookie: {e}")
        return None
    except Exception as e:
        logger.error(f"Ошибка при получении пользователя из cookie: {e}")
        return None


def clear_user_cache():
    """Очистка кэша пользователей"""
    with _cache_lock:
        _user_cache.clear()


def test_memory_auth():
    """Тестирование аутентификации через кэш памяти"""
    print("🧪 Тестирование аутентификации через кэш памяти...")
    
    try:
        # Тест получения пользователя
        user = get_user_by_username_memory("admin")
        if user:
            print(f"✅ Пользователь найден: {user.username}")
        else:
            print("⚠️ Пользователь admin не найден")
        
        # Тест аутентификации
        if user:
            auth_user = authenticate_user_memory("admin", "admin123")
            if auth_user:
                print("✅ Аутентификация работает")
            else:
                print("❌ Аутентификация не работает")
        
    except Exception as e:
        print(f"❌ Ошибка при тестировании: {e}")


if __name__ == "__main__":
    test_memory_auth()
