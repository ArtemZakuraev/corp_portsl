#!/usr/bin/env python3
"""
Скрипт для исправления проблем с базой данных
"""

import asyncio
import sys
import os
from sqlalchemy.ext.asyncio import AsyncSession
from database import get_async_session, engine
from models import User, Base
from sqlalchemy import select, text
import logging

# Настройка логирования
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


async def check_database_connection():
    """Проверка подключения к базе данных"""
    print("🔍 Проверка подключения к базе данных...")
    
    try:
        async with engine.begin() as conn:
            # Простой запрос для проверки подключения
            result = await conn.execute(text("SELECT 1"))
            print("✅ Подключение к базе данных работает")
            return True
    except Exception as e:
        print(f"❌ Ошибка подключения к базе данных: {e}")
        return False


async def fix_duplicate_users():
    """Исправление дублирующихся пользователей"""
    print("🔧 Проверка дублирующихся пользователей...")
    
    async for session in get_async_session():
        try:
            # Находим дублирующихся пользователей по username
            result = await session.execute(
                text("""
                    SELECT username, COUNT(*) as count 
                    FROM users 
                    GROUP BY username 
                    HAVING COUNT(*) > 1
                """)
            )
            duplicates = result.fetchall()
            
            if duplicates:
                print(f"⚠️ Найдено дублирующихся пользователей: {len(duplicates)}")
                for username, count in duplicates:
                    print(f"   - {username}: {count} записей")
                    
                    # Удаляем дубликаты, оставляя только первую запись
                    await session.execute(
                        text("""
                            DELETE FROM users 
                            WHERE username = :username 
                            AND id NOT IN (
                                SELECT MIN(id) FROM users WHERE username = :username
                            )
                        """),
                        {"username": username}
                    )
                    print(f"   ✅ Удалены дубликаты для {username}")
            else:
                print("✅ Дублирующихся пользователей не найдено")
            
            await session.commit()
            
        except Exception as e:
            print(f"❌ Ошибка при исправлении дубликатов: {e}")
            await session.rollback()
        finally:
            await session.close()
        break


async def fix_duplicate_settings():
    """Исправление дублирующихся настроек"""
    print("🔧 Проверка дублирующихся настроек...")
    
    async for session in get_async_session():
        try:
            # Находим дублирующиеся настройки
            result = await session.execute(
                text("SELECT COUNT(*) FROM settings")
            )
            count = result.scalar()
            
            if count > 1:
                print(f"⚠️ Найдено настроек: {count}")
                
                # Удаляем все кроме первой записи
                await session.execute(
                    text("""
                        DELETE FROM settings 
                        WHERE id NOT IN (
                            SELECT MIN(id) FROM settings
                        )
                    """)
                )
                print("✅ Удалены дублирующиеся настройки")
            else:
                print("✅ Дублирующихся настроек не найдено")
            
            await session.commit()
            
        except Exception as e:
            print(f"❌ Ошибка при исправлении настроек: {e}")
            await session.rollback()
        finally:
            await session.close()
        break


async def fix_duplicate_projects():
    """Исправление дублирующихся проектов"""
    print("🔧 Проверка дублирующихся проектов...")
    
    async for session in get_async_session():
        try:
            # Находим дублирующиеся проекты по name
            result = await session.execute(
                text("""
                    SELECT name, COUNT(*) as count 
                    FROM projects 
                    GROUP BY name 
                    HAVING COUNT(*) > 1
                """)
            )
            duplicates = result.fetchall()
            
            if duplicates:
                print(f"⚠️ Найдено дублирующихся проектов: {len(duplicates)}")
                for name, count in duplicates:
                    print(f"   - {name}: {count} записей")
                    
                    # Удаляем дубликаты, оставляя только первую запись
                    await session.execute(
                        text("""
                            DELETE FROM projects 
                            WHERE name = :name 
                            AND id NOT IN (
                                SELECT MIN(id) FROM projects WHERE name = :name
                            )
                        """),
                        {"name": name}
                    )
                    print(f"   ✅ Удалены дубликаты для {name}")
            else:
                print("✅ Дублирующихся проектов не найдено")
            
            await session.commit()
            
        except Exception as e:
            print(f"❌ Ошибка при исправлении проектов: {e}")
            await session.rollback()
        finally:
            await session.close()
        break


async def create_missing_admin():
    """Создание отсутствующего администратора"""
    print("🔧 Проверка наличия администратора...")
    
    async for session in get_async_session():
        try:
            result = await session.execute(select(User).where(User.is_admin == True))
            existing_admins = result.scalars().all()
            
            if not existing_admins:
                print("⚠️ Администратор не найден, создаем...")
                
                from utils import get_password_hash
                admin_password_hash = get_password_hash("admin123")
                admin = User(
                    username="admin",
                    email="admin@example.com",
                    password_hash=admin_password_hash,
                    is_admin=True
                )
                session.add(admin)
                await session.commit()
                print("✅ Создан администратор: admin / admin123")
            else:
                print(f"✅ Администратор найден: {existing_admins[0].username}")
                
        except Exception as e:
            print(f"❌ Ошибка при создании администратора: {e}")
            await session.rollback()
        finally:
            await session.close()
        break


async def fix_all_database_issues():
    """Исправление всех проблем с базой данных"""
    print("🔧 Исправление проблем с базой данных...")
    print("="*50)
    
    # Проверяем подключение
    if not await check_database_connection():
        print("❌ Не удается подключиться к базе данных")
        return False
    
    try:
        # Создаем таблицы если их нет
        print("\n🔧 Создание таблиц...")
        async with engine.begin() as conn:
            await conn.run_sync(Base.metadata.create_all)
        print("✅ Таблицы созданы")
        
        # Исправляем дубликаты
        await fix_duplicate_users()
        await fix_duplicate_settings()
        await fix_duplicate_projects()
        
        # Создаем администратора если нужно
        await create_missing_admin()
        
        print("\n🎉 Все проблемы с базой данных исправлены!")
        return True
        
    except Exception as e:
        print(f"❌ Ошибка при исправлении базы данных: {e}")
        return False


async def main():
    """Главная функция"""
    if len(sys.argv) > 1 and sys.argv[1] == "help":
        print("Использование:")
        print("  python fix_database.py           - Исправить все проблемы с базой данных")
        print("  python fix_database.py check     - Проверить подключение к базе данных")
        print("  python fix_database.py help      - Показать эту справку")
    elif len(sys.argv) > 1 and sys.argv[1] == "check":
        await check_database_connection()
    else:
        await fix_all_database_issues()


if __name__ == "__main__":
    asyncio.run(main())

