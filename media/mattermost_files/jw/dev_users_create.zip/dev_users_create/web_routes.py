from fastapi import APIRouter, Depends, Request, Form, HTTPException, File, UploadFile
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from typing import Optional, List
import os

from database import get_async_session
from models import User, Settings, Developer, Project, DeveloperProject
from utils import get_current_user, get_current_admin_user, get_current_user_optional, get_password_hash, authenticate_user, create_access_token
from schemas import UserCreate, UserLogin, DeveloperCreate, SettingsCreate
from config import settings
from api_integrations import GitLabAPI, RedmineAPI, KubernetesAPI

router = APIRouter()
templates = Jinja2Templates(directory="templates")


async def get_current_user_from_cookie(request: Request, session: AsyncSession) -> Optional[User]:
    """Получение текущего пользователя из cookie (для веб-роутов)"""
    try:
        # Используем функцию кэша памяти
        from memory_auth import get_user_from_cookie_memory
        user = get_user_from_cookie_memory(request)
        return user
    except Exception as e:
        import logging
        logger = logging.getLogger(__name__)
        logger.error(f"Ошибка при получении текущего пользователя из cookie: {e}")
        return None


# Главная страница
@router.get("/", response_class=HTMLResponse)
async def dashboard(
    request: Request,
    session: AsyncSession = Depends(get_async_session)
):
    """Главная страница"""
    # Получаем текущего пользователя из cookie
    current_user = await get_current_user_from_cookie(request, session)
    
    # Если пользователь не аутентифицирован, перенаправляем на страницу входа
    if not current_user:
        return RedirectResponse(url="/login", status_code=302)
    
    # Получаем статистику из базы данных
    # Подсчитываем количество разработчиков
    developers_result = await session.execute(select(Developer))
    developers_count = len(developers_result.scalars().all())
    
    # Подсчитываем количество проектов
    projects_result = await session.execute(select(Project))
    projects_count = len(projects_result.scalars().all())
    
    return templates.TemplateResponse("dashboard.html", {
        "request": request,
        "user": current_user,
        "developers_count": developers_count,
        "projects_count": projects_count,
        "app_name": settings.app_name
    })




# Страница входа
@router.get("/login", response_class=HTMLResponse)
async def login_page(
    request: Request,
    session: AsyncSession = Depends(get_async_session)
):
    """Страница входа"""
    # Получаем настройки из базы данных
    result = await session.execute(select(Settings).order_by(Settings.id.desc()).limit(1))
    settings_obj = result.scalar_one_or_none()
    
    return templates.TemplateResponse("login.html", {
        "request": request,
        "app_name": settings.app_name,
        "settings": settings_obj
    })


@router.post("/login", response_class=HTMLResponse)
async def login_user(
    request: Request,
    username: str = Form(...),
    password: str = Form(...),
    session: AsyncSession = Depends(get_async_session)
):
    """Обработка входа"""
    from datetime import timedelta
    
    from memory_auth import authenticate_user_memory
    user = authenticate_user_memory(username, password)
    if not user:
        return templates.TemplateResponse("login.html", {
            "request": request,
            "error": "Invalid username or password",
            "app_name": settings.app_name
        })
    
    # Создаем токен и устанавливаем cookie
    access_token_expires = timedelta(minutes=settings.access_token_expire_minutes)
    access_token = create_access_token(
        data={"sub": user.username}, expires_delta=access_token_expires
    )
    
    response = RedirectResponse(url="/", status_code=302)
    response.set_cookie(
        key="access_token",
        value=f"Bearer {access_token}",
        httponly=True,
        max_age=settings.access_token_expire_minutes * 60
    )
    
    return response


# Страница настроек
@router.get("/settings", response_class=HTMLResponse)
async def settings_page(
    request: Request,
    session: AsyncSession = Depends(get_async_session)
):
    """Страница настроек"""
    # Получаем текущего пользователя из cookie
    current_user = await get_current_user_from_cookie(request, session)
    
    # Если пользователь не аутентифицирован, перенаправляем на страницу входа
    if not current_user:
        return RedirectResponse(url="/login", status_code=302)
    
    # Проверяем права администратора
    if not current_user.is_admin:
        return RedirectResponse(url="/", status_code=302)
    
    # Получаем настройки из базы данных
    result = await session.execute(select(Settings).order_by(Settings.id.desc()).limit(1))
    settings_obj = result.scalar_one_or_none()
    
    # Если настроек нет, создаем настройки по умолчанию
    if not settings_obj:
        settings_obj = Settings()
        session.add(settings_obj)
        await session.commit()
        await session.refresh(settings_obj)
    
    return templates.TemplateResponse("settings.html", {
        "request": request,
        "user": current_user,
        "settings": settings_obj,
        "app_name": settings.app_name
    })


@router.post("/settings", response_class=HTMLResponse)
async def update_settings(
    request: Request,
    gitlab_url: str = Form(None),
    gitlab_token: str = Form(None),
    project_id: str = Form(None),
    redmine_url: str = Form(None),
    redmine_token: str = Form(None),
    kubernetes_api_url: str = Form(None),
    kubernetes_token: str = Form(None),
    session: AsyncSession = Depends(get_async_session)
):
    """Обновление настроек"""
    # Получаем текущего пользователя из cookie
    current_user = await get_current_user_from_cookie(request, session)
    
    # Если пользователь не аутентифицирован, перенаправляем на страницу входа
    if not current_user:
        return RedirectResponse(url="/login", status_code=302)
    
    # Проверяем права администратора
    if not current_user.is_admin:
        return RedirectResponse(url="/", status_code=302)
    
    # Получаем настройки из базы данных
    result = await session.execute(select(Settings).order_by(Settings.id.desc()).limit(1))
    settings_obj = result.scalar_one_or_none()
    
    if settings_obj:
        # Обновляем существующие настройки
        settings_obj.gitlab_url = gitlab_url
        settings_obj.gitlab_token = gitlab_token
        settings_obj.project_id = project_id
        settings_obj.redmine_url = redmine_url
        settings_obj.redmine_token = redmine_token
        settings_obj.kubernetes_api_url = kubernetes_api_url
        settings_obj.kubernetes_token = kubernetes_token
    else:
        # Создаем новые настройки
        settings_obj = Settings(
            gitlab_url=gitlab_url,
            gitlab_token=gitlab_token,
            project_id=project_id,
            redmine_url=redmine_url,
            redmine_token=redmine_token,
            kubernetes_api_url=kubernetes_api_url,
            kubernetes_token=kubernetes_token
        )
        session.add(settings_obj)
    
    # Сохраняем в базу данных
    await session.commit()
    await session.refresh(settings_obj)
    
    return RedirectResponse(url="/settings", status_code=302)


# Страница добавления разработчика
@router.get("/developers/add", response_class=HTMLResponse)
async def add_developer_page(
    request: Request,
    session: AsyncSession = Depends(get_async_session)
):
    """Страница добавления разработчика"""
    # Получаем текущего пользователя из cookie
    current_user = await get_current_user_from_cookie(request, session)
    
    # Если пользователь не аутентифицирован, перенаправляем на страницу входа
    if not current_user:
        return RedirectResponse(url="/login", status_code=302)
    
    # Проверяем права администратора
    if not current_user.is_admin:
        return RedirectResponse(url="/", status_code=302)
    
    # Получаем проекты из базы данных
    result = await session.execute(select(Project))
    projects = result.scalars().all()
    
    # Если проектов нет, создаем проекты из init_db.py
    if not projects:
        projects_data = [
            {"name": "АС ФЗД", "gitlab_project_id": "1", "description": "Автоматизированная система ФЗД"},
            {"name": "АС КУБ", "gitlab_project_id": "2", "description": "Автоматизированная система КУБ"},
            {"name": "АС ЕУС", "gitlab_project_id": "3", "description": "Автоматизированная система ЕУС"},
            {"name": "АС ЕКК", "gitlab_project_id": "4", "description": "Автоматизированная система ЕКК"},
            {"name": "АС ПШ", "gitlab_project_id": "5", "description": "Автоматизированная система ПШ"},
            {"name": "АС УП", "gitlab_project_id": "6", "description": "Автоматизированная система УП"}
        ]
        
        for project_data in projects_data:
            project = Project(**project_data)
            session.add(project)
        
        await session.commit()
        
        # Получаем проекты снова
        result = await session.execute(select(Project))
        projects = result.scalars().all()
    
    return templates.TemplateResponse("add_developer.html", {
        "request": request,
        "user": current_user,
        "projects": projects,
        "app_name": settings.app_name
    })


@router.post("/developers/add", response_class=HTMLResponse)
async def add_developer(
    request: Request,
    last_name: str = Form(...),
    first_name: str = Form(...),
    middle_name: str = Form(None),
    email: str = Form(...),
    position: str = Form(...),
    department: str = Form(...),
    phone: str = Form(None),
    gitlab_user_id: str = Form(None),
    redmine_user_id: str = Form(None),
    gitlab_username: str = Form(None),
    redmine_username: str = Form(None),
    is_active: bool = Form(True),
    notes: str = Form(None),
    session: AsyncSession = Depends(get_async_session)
):
    """Добавление разработчика"""
    # Получаем текущего пользователя из cookie
    current_user = await get_current_user_from_cookie(request, session)
    
    # Если пользователь не аутентифицирован, перенаправляем на страницу входа
    if not current_user:
        return RedirectResponse(url="/login", status_code=302)
    
    # Проверяем права администратора
    if not current_user.is_admin:
        return RedirectResponse(url="/", status_code=302)
    
    # Получаем project_ids из формы
    form_data = await request.form()
    project_ids = []
    for key, value in form_data.items():
        if key == "project_ids" and value:
            try:
                project_ids.append(int(value))
            except ValueError:
                pass
    
    # Проверяем, существует ли разработчик с таким email в БД
    existing_developer = await session.execute(
        select(Developer).where(Developer.email == email)
    )
    if existing_developer.scalar_one_or_none():
        # Получаем проекты для отображения ошибки
        result = await session.execute(select(Project))
        projects = result.scalars().all()
        
        return templates.TemplateResponse("add_developer.html", {
            "request": request,
            "user": current_user,
            "projects": projects,
            "error": "Developer with this email already exists",
            "app_name": settings.app_name
        })
    
    # Обрабатываем числовые поля
    gitlab_id = None
    if gitlab_user_id and gitlab_user_id.strip():
        try:
            gitlab_id = int(gitlab_user_id)
        except ValueError:
            gitlab_id = None
    
    redmine_id = None
    if redmine_user_id and redmine_user_id.strip():
        try:
            redmine_id = int(redmine_user_id)
        except ValueError:
            redmine_id = None
    
    # Создаем разработчика в базе данных
    db_developer = Developer(
        last_name=last_name,
        first_name=first_name,
        middle_name=middle_name,
        email=email,
        position=position,
        department=department,
        phone=phone,
        gitlab_user_id=gitlab_id,
        redmine_user_id=redmine_id,
        gitlab_username=gitlab_username,
        redmine_username=redmine_username,
        is_active=is_active,
        notes=notes
    )
    
    session.add(db_developer)
    await session.commit()
    await session.refresh(db_developer)
    
    # Добавляем связи с проектами
    if project_ids:
        for project_id in project_ids:
            # Проверяем, существует ли проект
            project_result = await session.execute(
                select(Project).where(Project.id == project_id)
            )
            project = project_result.scalar_one_or_none()
            
            if project:
                # Создаем связь разработчик-проект
                dev_project = DeveloperProject(
                    developer_id=db_developer.id,
                    project_id=project_id,
                    active=True
                )
                session.add(dev_project)
        
        await session.commit()
    
    new_developer = db_developer
    
    return RedirectResponse(url="/developers", status_code=302)


# Страница списка разработчиков
@router.get("/developers", response_class=HTMLResponse)
async def developers_page(
    request: Request,
    session: AsyncSession = Depends(get_async_session)
):
    """Страница списка разработчиков с проектами из Redmine"""
    # Получаем текущего пользователя из cookie
    current_user = await get_current_user_from_cookie(request, session)
    
    # Если пользователь не аутентифицирован, перенаправляем на страницу входа
    if not current_user:
        return RedirectResponse(url="/login", status_code=302)
    
    # Получаем разработчиков из базы данных
    result = await session.execute(select(Developer))
    developers = result.scalars().all()
    
    # Получаем настройки для подключения к Redmine
    result = await session.execute(select(Settings).order_by(Settings.id.desc()).limit(1))
    settings_obj = result.scalar_one_or_none()
    
    # Получаем проекты из Redmine для каждого разработчика
    developers_with_projects = []
    for developer in developers:
        developer_data = {
            'developer': developer,
            'redmine_projects': []
        }
        
        # Если есть настройки Redmine и у разработчика указан username
        if settings_obj and settings_obj.redmine_url and settings_obj.redmine_token:
            if developer.redmine_username:
                try:
                    redmine_api = RedmineAPI(settings_obj.redmine_url, settings_obj.redmine_token)
                    redmine_projects = await redmine_api.get_user_projects(developer.redmine_username)
                    developer_data['redmine_projects'] = redmine_projects
                except Exception as e:
                    import logging
                    logger = logging.getLogger(__name__)
                    logger.error(f"Error loading Redmine projects for {developer.redmine_username}: {e}")
        
        developers_with_projects.append(developer_data)
    
    return templates.TemplateResponse("developers.html", {
        "request": request,
        "user": current_user,
        "developers_with_projects": developers_with_projects,
        "app_name": settings.app_name
    })


# Создание пользователя в GitLab
@router.post("/developers/{developer_id}/create-gitlab-user", response_class=HTMLResponse)
async def create_gitlab_user_web(
    developer_id: int,
    request: Request,
    session: AsyncSession = Depends(get_async_session)
):
    """Создание пользователя в GitLab через веб-интерфейс"""
    # Получаем текущего пользователя из cookie
    current_user = await get_current_user_from_cookie(request, session)
    
    # Если пользователь не аутентифицирован, перенаправляем на страницу входа
    if not current_user:
        return RedirectResponse(url="/login", status_code=302)
    
    # Проверяем права администратора
    if not current_user.is_admin:
        return RedirectResponse(url="/", status_code=302)
    
    try:
        # Получаем разработчика
        result = await session.execute(
            select(Developer).where(Developer.id == developer_id)
        )
        developer = result.scalar_one_or_none()
        
        if not developer:
            return RedirectResponse(url="/developers?error=Developer not found", status_code=302)
        
        # Получаем настройки
        result = await session.execute(select(Settings).order_by(Settings.id.desc()).limit(1))
        settings_obj = result.scalar_one_or_none()
        
        if not settings_obj or not settings_obj.gitlab_url or not settings_obj.gitlab_token:
            return RedirectResponse(url="/developers?error=GitLab settings not configured", status_code=302)
        
        # Подготавливаем данные для API
        from utils import generate_username_from_email
        username = generate_username_from_email(developer.email)
        
        user_data = {
            'username': username,
            'email': developer.email,
            'first_name': developer.first_name,
            'last_name': developer.last_name,
            'middle_name': developer.middle_name,
            'position': developer.position,
            'department': developer.department
        }
        
        # Проверяем, существует ли пользователь в GitLab
        try:
            gitlab_api = GitLabAPI(settings_obj.gitlab_url, settings_obj.gitlab_token)
        except Exception as e:
            return RedirectResponse(url=f"/developers?error=GitLab integration error: {str(e)}", status_code=302)
        
        # Ищем существующего пользователя по username и email
        existing_user = await gitlab_api.find_existing_user(username, developer.email)
        
        if existing_user:
            # Пользователь уже существует
            gitlab_user_id = existing_user['id']
            
            # Обновляем данные разработчика
            developer.gitlab_user_id = gitlab_user_id
            developer.gitlab_username = existing_user['username']
            await session.commit()
            
            return RedirectResponse(url=f"/developers?warning=User already exists in GitLab (ID: {gitlab_user_id})", status_code=302)
        
        # Создаем нового пользователя в GitLab
        gitlab_user_id = await gitlab_api.create_user(user_data)
        
        if gitlab_user_id:
            # Обновляем разработчика
            developer.gitlab_user_id = gitlab_user_id
            developer.gitlab_username = username
            await session.commit()
            
            return RedirectResponse(url=f"/developers?success=GitLab user created successfully (ID: {gitlab_user_id})", status_code=302)
        else:
            return RedirectResponse(url="/developers?error=Failed to create GitLab user", status_code=302)
            
    except Exception as e:
        return RedirectResponse(url=f"/developers?error=GitLab integration error: {str(e)}", status_code=302)


# Создание пользователя в Redmine
@router.post("/developers/{developer_id}/create-redmine-user", response_class=HTMLResponse)
async def create_redmine_user_web(
    developer_id: int,
    request: Request,
    session: AsyncSession = Depends(get_async_session)
):
    """Создание пользователя в Redmine через веб-интерфейс"""
    # Получаем текущего пользователя из cookie
    current_user = await get_current_user_from_cookie(request, session)
    
    # Если пользователь не аутентифицирован, перенаправляем на страницу входа
    if not current_user:
        return RedirectResponse(url="/login", status_code=302)
    
    # Проверяем права администратора
    if not current_user.is_admin:
        return RedirectResponse(url="/", status_code=302)
    
    try:
        # Получаем разработчика
        result = await session.execute(
            select(Developer).where(Developer.id == developer_id)
        )
        developer = result.scalar_one_or_none()
        
        if not developer:
            return RedirectResponse(url="/developers?error=Developer not found", status_code=302)
        
        # Получаем настройки
        result = await session.execute(select(Settings).order_by(Settings.id.desc()).limit(1))
        settings_obj = result.scalar_one_or_none()
        
        if not settings_obj or not settings_obj.redmine_url or not settings_obj.redmine_token:
            return RedirectResponse(url="/developers?error=Redmine settings not configured", status_code=302)
        
        # Подготавливаем данные для API
        from utils import generate_username_from_email
        username = generate_username_from_email(developer.email)
        
        user_data = {
            'username': username,
            'email': developer.email,
            'first_name': developer.first_name,
            'last_name': developer.last_name,
            'middle_name': developer.middle_name,
            'position': developer.position,
            'department': developer.department
        }
        
        # Проверяем, существует ли пользователь в Redmine
        redmine_api = RedmineAPI(settings_obj.redmine_url, settings_obj.redmine_token)
        
        # Ищем существующего пользователя по username и email
        existing_user = await redmine_api.find_existing_user(username, developer.email)
        
        if existing_user:
            # Пользователь уже существует
            redmine_user_id = existing_user['id']
            sequential_number = redmine_user_id
            
            # Обновляем данные разработчика
            developer.redmine_user_id = redmine_user_id
            developer.redmine_username = existing_user['login']
            await session.commit()
            
            return RedirectResponse(url=f"/developers?warning=User already exists in Redmine (ID: {redmine_user_id}, Sequential: {sequential_number})", status_code=302)
        
        # Создаем нового пользователя в Redmine
        redmine_user_id = await redmine_api.create_user(user_data)
        
        if redmine_user_id:
            # Получаем порядковый номер пользователя
            sequential_number = await redmine_api.get_user_sequential_number(redmine_user_id)
            user_info = await redmine_api.get_user_info(redmine_user_id)
            
            # Обновляем разработчика
            developer.redmine_user_id = redmine_user_id
            developer.redmine_username = username
            await session.commit()
            
            return RedirectResponse(url=f"/developers?success=Redmine user created successfully (ID: {redmine_user_id}, Sequential: {sequential_number})", status_code=302)
        else:
            return RedirectResponse(url="/developers?error=Failed to create Redmine user", status_code=302)
            
    except Exception as e:
        return RedirectResponse(url=f"/developers?error=Redmine integration error: {str(e)}", status_code=302)




# Страница "О программе"
@router.get("/about", response_class=HTMLResponse)
async def about_page(
    request: Request,
    session: AsyncSession = Depends(get_async_session)
):
    """Страница о программе"""
    # Получаем текущего пользователя из cookie
    current_user = await get_current_user_from_cookie(request, session)
    
    # Получаем настройки из базы данных
    result = await session.execute(select(Settings).order_by(Settings.id.desc()).limit(1))
    settings_obj = result.scalar_one_or_none()
    
    return templates.TemplateResponse("about.html", {
        "request": request,
        "user": current_user,
        "app_name": settings.app_name,
        "app_version": settings.app_version,
        "author": "a.zakuraev@123.com",
        "settings": settings_obj
    })


# Профиль разработчика
@router.get("/developers/{developer_id}", response_class=HTMLResponse)
async def developer_profile(
    developer_id: int,
    request: Request,
    session: AsyncSession = Depends(get_async_session)
):
    """Страница профиля разработчика с автоматическим поиском"""
    # Получаем текущего пользователя из cookie
    current_user = await get_current_user_from_cookie(request, session)
    
    # Если пользователь не аутентифицирован, перенаправляем на страницу входа
    if not current_user:
        return RedirectResponse(url="/login", status_code=302)
    
    # Получаем разработчика из базы данных с его проектами
    from sqlalchemy.orm import selectinload
    result = await session.execute(
        select(Developer)
        .where(Developer.id == developer_id)
        .options(selectinload(Developer.projects).selectinload(DeveloperProject.project))
    )
    developer = result.scalar_one_or_none()
    
    if not developer:
        return RedirectResponse(url="/developers?error=Developer not found", status_code=302)
    
    # Получаем настройки
    result = await session.execute(select(Settings).order_by(Settings.id.desc()).limit(1))
    settings_obj = result.scalar_one_or_none()
    
    # Автоматический поиск по системам
    search_results = {
        'gitlab': [],
        'redmine': [],
        'kubernetes': []
    }
    
    search_errors = {
        'gitlab': None,
        'redmine': None,
        'kubernetes': None
    }
    
    # Поиск в GitLab
    if settings_obj and settings_obj.gitlab_url and settings_obj.gitlab_token:
        try:
            # Проверяем, что настройки не пустые
            if not settings_obj.gitlab_url.strip() or not settings_obj.gitlab_token.strip():
                search_errors['gitlab'] = "GitLab URL или токен пустые"
            else:
                gitlab_api = GitLabAPI(settings_obj.gitlab_url.strip(), settings_obj.gitlab_token.strip())
                
                # Сначала проверяем подключение
                connection_test = await gitlab_api.test_connection()
                if not connection_test['success']:
                    search_errors['gitlab'] = connection_test['message']
                else:
                    # Если подключение успешно, выполняем поиск
                    try:
                        search_term = f"{developer.first_name} {developer.last_name}"
                        search_results['gitlab'] = await gitlab_api.search_users_by_name_or_email(search_term)
                        # Если не найдено по имени, пробуем по email
                        if not search_results['gitlab']:
                            search_results['gitlab'] = await gitlab_api.search_users_by_name_or_email(developer.email)
                    except Exception as search_error:
                        import logging
                        logger = logging.getLogger(__name__)
                        logger.error(f"GitLab search execution error: {search_error}")
                        search_errors['gitlab'] = f"GitLab недоступен: Ошибка поиска - {str(search_error)}"
        except ValueError as e:
            # Ошибка инициализации GitLab API
            import logging
            logger = logging.getLogger(__name__)
            logger.error(f"GitLab API initialization error: {e}")
            search_errors['gitlab'] = f"GitLab недоступен: Ошибка инициализации - {str(e)}"
        except Exception as e:
            import logging
            logger = logging.getLogger(__name__)
            logger.error(f"GitLab search error: {e}")
            search_errors['gitlab'] = f"GitLab недоступен: {str(e)}"
    else:
        search_errors['gitlab'] = "GitLab не настроен"
    
    # Поиск в Redmine
    if settings_obj and settings_obj.redmine_url and settings_obj.redmine_token:
        try:
            redmine_api = RedmineAPI(settings_obj.redmine_url, settings_obj.redmine_token)
            
            # Сначала проверяем подключение
            connection_test = await redmine_api.test_connection()
            if not connection_test['success']:
                search_errors['redmine'] = connection_test['message']
            else:
                # Если у разработчика уже есть данные Redmine, показываем их
                if developer.redmine_user_id and developer.redmine_username:
                    search_results['redmine'] = [{
                        'id': developer.redmine_user_id,
                        'login': developer.redmine_username,
                        'firstname': developer.first_name,
                        'lastname': developer.last_name,
                        'mail': developer.email,
                        'status': 1,  # Предполагаем активный статус
                        'match_type': 'existing_data'
                    }]
                else:
                    # Если данных нет, выполняем поиск
                    search_term = f"{developer.first_name} {developer.last_name}"
                    search_results['redmine'] = await redmine_api.search_users_by_name_or_email(search_term)
                    # Если не найдено по имени, пробуем по email
                    if not search_results['redmine']:
                        search_results['redmine'] = await redmine_api.search_users_by_name_or_email(developer.email)
                    
                    # Если найдены результаты, сохраняем ID и username в базу данных
                    if search_results['redmine']:
                        # Берем первого найденного пользователя (наиболее релевантного)
                        redmine_user = search_results['redmine'][0]
                        redmine_id = redmine_user.get('id')
                        redmine_username = redmine_user.get('login')
                        
                        # Обновляем данные разработчика в базе данных
                        if redmine_id and redmine_id != developer.redmine_user_id:
                            developer.redmine_user_id = redmine_id
                        if redmine_username and redmine_username != developer.redmine_username:
                            developer.redmine_username = redmine_username
                        
                        # Сохраняем изменения в базе данных
                        await session.commit()
        except Exception as e:
            import logging
            logger = logging.getLogger(__name__)
            logger.error(f"Redmine search error: {e}")
            search_errors['redmine'] = f"Redmine недоступен: {str(e)}"
    else:
        search_errors['redmine'] = "Redmine не настроен"
    
    # Получение проектов из Redmine
    redmine_projects = []
    if settings_obj and settings_obj.redmine_url and settings_obj.redmine_token:
        try:
            if developer.redmine_username:
                redmine_api = RedmineAPI(settings_obj.redmine_url, settings_obj.redmine_token)
                redmine_projects = await redmine_api.get_user_projects(developer.redmine_username)
                logger.info(f"Loaded {len(redmine_projects)} projects from Redmine for user {developer.redmine_username}")
        except Exception as e:
            import logging
            logger = logging.getLogger(__name__)
            logger.error(f"Error loading Redmine projects: {e}")
    
    # Поиск в Kubernetes по Redmine ID
    kubernetes_namespaces = []
    if settings_obj and settings_obj.kubernetes_api_url and settings_obj.kubernetes_token:
        try:
            kubernetes_api = KubernetesAPI(settings_obj.kubernetes_api_url, settings_obj.kubernetes_token)
            
            # Сначала проверяем подключение
            connection_test = await kubernetes_api.test_connection()
            if not connection_test['success']:
                search_errors['kubernetes'] = connection_test['message']
            else:
                # Если подключение успешно и есть Redmine ID, ищем namespaces
                if developer.redmine_user_id:
                    # Получаем namespaces по Redmine ID
                    kubernetes_namespaces = await kubernetes_api.get_namespaces_by_redmine_id(developer.redmine_user_id)
                    
                    if kubernetes_namespaces:
                        search_results['kubernetes'] = kubernetes_namespaces
                        logger.info(f"Found {len(kubernetes_namespaces)} Kubernetes namespaces for Redmine ID {developer.redmine_user_id}")
                    else:
                        search_errors['kubernetes'] = f"Namespaces не найдены для пользователя с Redmine ID {developer.redmine_user_id}"
                else:
                    search_errors['kubernetes'] = "Redmine ID не найден - невозможно найти namespace пользователя"
        except Exception as e:
            import logging
            logger = logging.getLogger(__name__)
            logger.error(f"Kubernetes search error: {e}")
            search_errors['kubernetes'] = f"Kubernetes недоступен: {str(e)}"
    else:
        search_errors['kubernetes'] = "Kubernetes не настроен"
    
    return templates.TemplateResponse("developer_profile.html", {
        "request": request,
        "user": current_user,
        "developer": developer,
        "search_results": search_results,
        "search_errors": search_errors,
        "redmine_projects": redmine_projects,  # Проекты из Redmine
        "kubernetes_namespaces": kubernetes_namespaces,  # Namespaces из Kubernetes
        "app_name": settings.app_name
    })


# Поиск по системам
@router.get("/developers/{developer_id}/search", response_class=HTMLResponse)
async def search_in_systems(
    developer_id: int,
    request: Request,
    search_term: str = "",
    session: AsyncSession = Depends(get_async_session)
):
    """Поиск разработчика в системах (Redmine, GitLab, Kubernetes)"""
    # Получаем текущего пользователя из cookie
    current_user = await get_current_user_from_cookie(request, session)
    
    # Если пользователь не аутентифицирован, перенаправляем на страницу входа
    if not current_user:
        return RedirectResponse(url="/login", status_code=302)
    
    # Получаем разработчика из базы данных
    result = await session.execute(
        select(Developer).where(Developer.id == developer_id)
    )
    developer = result.scalar_one_or_none()
    
    if not developer:
        return RedirectResponse(url="/developers?error=Developer not found", status_code=302)
    
    # Получаем настройки
    result = await session.execute(select(Settings).order_by(Settings.id.desc()).limit(1))
    settings_obj = result.scalar_one_or_none()
    
    search_results = {
        'gitlab': [],
        'redmine': [],
        'kubernetes': []
    }
    
    # Если есть поисковый запрос, выполняем поиск
    if search_term.strip():
        # Поиск в GitLab
        if settings_obj and settings_obj.gitlab_url and settings_obj.gitlab_token:
            try:
                gitlab_api = GitLabAPI(settings_obj.gitlab_url, settings_obj.gitlab_token)
                search_results['gitlab'] = await gitlab_api.search_users_by_name_or_email(search_term)
            except ValueError as e:
                import logging
                logger = logging.getLogger(__name__)
                logger.error(f"GitLab API initialization error: {e}")
                search_errors['gitlab'] = f"GitLab недоступен: Ошибка инициализации - {str(e)}"
            except Exception as e:
                import logging
                logger = logging.getLogger(__name__)
                logger.error(f"GitLab search error: {e}")
                search_errors['gitlab'] = f"GitLab недоступен: {str(e)}"
        
        # Поиск в Redmine
        if settings_obj and settings_obj.redmine_url and settings_obj.redmine_token:
            try:
                redmine_api = RedmineAPI(settings_obj.redmine_url, settings_obj.redmine_token)
                search_results['redmine'] = await redmine_api.search_users_by_name_or_email(search_term)
                
                # Если найдены результаты, сохраняем ID и username в базу данных
                if search_results['redmine']:
                    # Берем первого найденного пользователя (наиболее релевантного)
                    redmine_user = search_results['redmine'][0]
                    redmine_id = redmine_user.get('id')
                    redmine_username = redmine_user.get('login')
                    
                    # Обновляем данные разработчика в базе данных
                    if redmine_id and redmine_id != developer.redmine_user_id:
                        developer.redmine_user_id = redmine_id
                    if redmine_username and redmine_username != developer.redmine_username:
                        developer.redmine_username = redmine_username
                    
                    # Сохраняем изменения в базе данных
                    await session.commit()
            except Exception as e:
                import logging
                logger = logging.getLogger(__name__)
                logger.error(f"Redmine search error: {e}")
        
        # Поиск в Kubernetes
        if settings_obj and settings_obj.kubernetes_api_url and settings_obj.kubernetes_token:
            try:
                kubernetes_api = KubernetesAPI(settings_obj.kubernetes_api_url, settings_obj.kubernetes_token)
                
                # Если есть Redmine ID, выполняем kubectl команду
                if developer.redmine_user_id:
                    kubernetes_result = await kubernetes_api.check_user_namespace_with_postgres(developer.redmine_user_id)
                    if kubernetes_result['success']:
                        search_results['kubernetes'] = [kubernetes_result]
                    else:
                        # Если kubectl команда не сработала, пробуем старый метод поиска
                        search_results['kubernetes'] = await kubernetes_api.search_service_accounts_by_name(search_term)
                else:
                    # Если нет Redmine ID, используем старый метод поиска
                    search_results['kubernetes'] = await kubernetes_api.search_service_accounts_by_name(search_term)
            except Exception as e:
                import logging
                logger = logging.getLogger(__name__)
                logger.error(f"Kubernetes search error: {e}")
    
    return templates.TemplateResponse("developer_search.html", {
        "request": request,
        "user": current_user,
        "developer": developer,
        "search_term": search_term,
        "search_results": search_results,
        "app_name": settings.app_name
    })


# Выход


@router.get("/logout", response_class=HTMLResponse)
async def logout():
    """Выход из системы"""
    response = RedirectResponse(url="/login", status_code=302)
    response.delete_cookie(key="access_token")
    return response
