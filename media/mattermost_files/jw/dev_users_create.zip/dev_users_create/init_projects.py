#!/usr/bin/env python3
"""Инициализация проектов в базе данных"""

import asyncio
from database import get_async_session
from models import Project
from sqlalchemy import select

async def init_projects():
    print("Инициализация проектов...")
    
    async for session in get_async_session():
        try:
            # Проверяем, есть ли уже проекты
            result = await session.execute(select(Project))
            existing_projects = result.scalars().all()
            
            if existing_projects:
                print(f"Проекты уже существуют: {len(existing_projects)}")
                for project in existing_projects:
                    print(f"- {project.name} (ID: {project.id})")
                return
            
            # Создаем проекты из init_db.py
            projects_data = [
                {"name": "АС ФЗД", "gitlab_project_id": "1", "description": "Автоматизированная система ФЗД"},
                {"name": "АС КУБ", "gitlab_project_id": "2", "description": "Автоматизированная система КУБ"},
                {"name": "АС ЕУС", "gitlab_project_id": "3", "description": "Автоматизированная система ЕУС"},
                {"name": "АС ЕКК", "gitlab_project_id": "4", "description": "Автоматизированная система ЕКК"},
                {"name": "АС ПШ", "gitlab_project_id": "5", "description": "Автоматизированная система ПШ"},
                {"name": "АС УП", "gitlab_project_id": "6", "description": "Автоматизированная система УП"}
            ]
            
            test_projects = []
            for project_data in projects_data:
                test_projects.append(Project(**project_data))
            
            for project in test_projects:
                session.add(project)
            
            await session.commit()
            print("Тестовые проекты созданы!")
            
            # Проверяем результат
            result = await session.execute(select(Project))
            projects = result.scalars().all()
            print(f"Создано проектов: {len(projects)}")
            for project in projects:
                print(f"- {project.name} (ID: {project.id})")
                
        except Exception as e:
            print(f"Ошибка: {e}")
        break

if __name__ == "__main__":
    asyncio.run(init_projects())
