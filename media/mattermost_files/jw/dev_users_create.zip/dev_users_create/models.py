from sqlalchemy import Column, Integer, String, Boolean, DateTime, ForeignKey, Text
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
from database import Base


class User(Base):
    __tablename__ = "users"
    
    id = Column(Integer, primary_key=True, index=True)
    username = Column(String(50), unique=True, index=True, nullable=False)
    email = Column(String(100), unique=True, index=True, nullable=False)
    password_hash = Column(String(255), nullable=False)
    is_admin = Column(Boolean, default=False)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())


class Settings(Base):
    __tablename__ = "settings"
    
    id = Column(Integer, primary_key=True, index=True)
    gitlab_url = Column(String(255))
    gitlab_token = Column(String(255))
    project_id = Column(String(100))  # ID проекта по умолчанию
    redmine_url = Column(String(255))
    redmine_token = Column(String(255))
    kubernetes_api_url = Column(String(255))
    kubernetes_token = Column(String(2000))
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())


class Developer(Base):
    __tablename__ = "developers"
    
    id = Column(Integer, primary_key=True, index=True)
    last_name = Column(String(100), nullable=False)
    first_name = Column(String(100), nullable=False)
    middle_name = Column(String(100))
    email = Column(String(100), unique=True, index=True, nullable=False)
    position = Column(String(100), nullable=False)
    department = Column(String(100), nullable=False)
    phone = Column(String(20))  # Телефон
    telegram = Column(String(100))  # Telegram
    slack = Column(String(100))  # Slack
    gitlab_user_id = Column(Integer)  # ID пользователя в GitLab
    redmine_user_id = Column(Integer)  # ID пользователя в Redmine
    rm_id = Column(String(50))  # ID в Redmine (можно заполнить вручную или получить из артефакта)
    gitlab_username = Column(String(100))  # Username в GitLab
    redmine_username = Column(String(100))  # Username в Redmine
    is_active = Column(Boolean, default=True)  # Активен ли разработчик
    notes = Column(Text)  # Заметки
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())
    
    # Связь с проектами
    projects = relationship("DeveloperProject", back_populates="developer")


class Project(Base):
    __tablename__ = "projects"
    
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(100), unique=True, nullable=False)
    gitlab_project_id = Column(String(100))
    description = Column(Text)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())
    
    # Связь с разработчиками
    developers = relationship("DeveloperProject", back_populates="project")


class DeveloperProject(Base):
    __tablename__ = "developer_projects"
    
    developer_id = Column(Integer, ForeignKey("developers.id"), primary_key=True)
    project_id = Column(Integer, ForeignKey("projects.id"), primary_key=True)
    active = Column(Boolean, default=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    
    # Связи
    developer = relationship("Developer", back_populates="projects")
    project = relationship("Project", back_populates="developers")

