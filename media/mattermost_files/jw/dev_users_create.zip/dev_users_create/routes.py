from fastapi import APIRouter, Depends, HTTPException, status, UploadFile, File
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from typing import List, Optional
import aiofiles
import os
import logging
from datetime import timedelta

logger = logging.getLogger(__name__)

from database import get_async_session
from models import User, Settings, Developer, Project, DeveloperProject
from schemas import (
    UserCreate, UserLogin, UserResponse, SettingsCreate, SettingsResponse,
    DeveloperCreate, DeveloperResponse, ProjectCreate, ProjectResponse, Token
)
from utils import (
    get_password_hash, verify_password, create_access_token, authenticate_user,
    get_current_user, get_current_admin_user, generate_username_from_email
)
from memory_auth import authenticate_user_memory
from config import settings
from api_integrations import GitLabAPI, RedmineAPI, KubernetesAPI

router = APIRouter()


# Аутентификация
@router.post("/auth/register", response_model=UserResponse)
async def register(
    user_data: UserCreate,
    session: AsyncSession = Depends(get_async_session)
):
    """Регистрация нового пользователя"""
    # Проверяем, существует ли пользователь
    existing_user = await session.execute(
        select(User).where(User.username == user_data.username)
    )
    if existing_user.scalar_one_or_none():
        raise HTTPException(
            status_code=400,
            detail="Username already registered"
        )
    
    existing_email = await session.execute(
        select(User).where(User.email == user_data.email)
    )
    if existing_email.scalar_one_or_none():
        raise HTTPException(
            status_code=400,
            detail="Email already registered"
        )
    
    # Создаем нового пользователя
        # Пароль без хеширования
        hashed_password = user_data.password
    db_user = User(
        username=user_data.username,
        email=user_data.email,
        password_hash=hashed_password,
        is_admin=False
    )
    
    session.add(db_user)
    await session.commit()
    await session.refresh(db_user)
    
    return db_user


@router.post("/auth/login", response_model=Token)
async def login(
    user_data: UserLogin,
    session: AsyncSession = Depends(get_async_session)
):
    """Вход пользователя"""
    user = authenticate_user_memory(user_data.username, user_data.password)
    if not user:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect username or password",
            headers={"WWW-Authenticate": "Bearer"},
        )
    
    access_token_expires = timedelta(minutes=settings.access_token_expire_minutes)
    access_token = create_access_token(
        data={"sub": user.username}, expires_delta=access_token_expires
    )
    
    return {"access_token": access_token, "token_type": "bearer"}


# Настройки
@router.get("/settings", response_model=SettingsResponse)
async def get_settings(
    current_user: User = Depends(get_current_admin_user),
    session: AsyncSession = Depends(get_async_session)
):
    """Получение настроек"""
    result = await session.execute(select(Settings).order_by(Settings.id.desc()).limit(1))
    settings_obj = result.scalar_one_or_none()
    
    if not settings_obj:
        # Создаем настройки по умолчанию
        settings_obj = Settings()
        session.add(settings_obj)
        await session.commit()
        await session.refresh(settings_obj)
    
    return settings_obj


@router.post("/settings", response_model=SettingsResponse)
async def update_settings(
    settings_data: SettingsCreate,
    current_user: User = Depends(get_current_admin_user),
    session: AsyncSession = Depends(get_async_session)
):
    """Обновление настроек"""
    result = await session.execute(select(Settings).order_by(Settings.id.desc()).limit(1))
    settings_obj = result.scalar_one_or_none()
    
    if settings_obj:
        # Обновляем существующие настройки
        for field, value in settings_data.dict(exclude_unset=True).items():
            setattr(settings_obj, field, value)
    else:
        # Создаем новые настройки
        settings_obj = Settings(**settings_data.dict())
        session.add(settings_obj)
    
    await session.commit()
    await session.refresh(settings_obj)
    
    return settings_obj




# Проекты
@router.get("/projects", response_model=List[ProjectResponse])
async def get_projects(
    session: AsyncSession = Depends(get_async_session)
):
    """Получение списка проектов"""
    result = await session.execute(select(Project))
    projects = result.scalars().all()
    return projects


@router.post("/projects", response_model=ProjectResponse)
async def create_project(
    project_data: ProjectCreate,
    current_user: User = Depends(get_current_admin_user),
    session: AsyncSession = Depends(get_async_session)
):
    """Создание нового проекта"""
    db_project = Project(**project_data.dict())
    session.add(db_project)
    await session.commit()
    await session.refresh(db_project)
    
    return db_project


# Разработчики
@router.get("/developers", response_model=List[DeveloperResponse])
async def get_developers(
    session: AsyncSession = Depends(get_async_session)
):
    """Получение списка разработчиков"""
    result = await session.execute(select(Developer))
    developers = result.scalars().all()
    return developers


@router.post("/developers/add", response_model=DeveloperResponse)
async def add_developer(
    developer_data: DeveloperCreate,
    current_user: User = Depends(get_current_admin_user),
    session: AsyncSession = Depends(get_async_session)
):
    """Добавление нового разработчика с интеграцией в GitLab и Redmine"""
    
    # Проверяем, существует ли разработчик с таким email
    existing_developer = await session.execute(
        select(Developer).where(Developer.email == developer_data.email)
    )
    if existing_developer.scalar_one_or_none():
        raise HTTPException(
            status_code=400,
            detail="Developer with this email already exists"
        )
    
    # Получаем настройки
    result = await session.execute(select(Settings).order_by(Settings.id.desc()).limit(1))
    settings_obj = result.scalar_one_or_none()
    
    if not settings_obj:
        raise HTTPException(
            status_code=400,
            detail="Settings not configured"
        )
    
    # Создаем разработчика в БД
    username = generate_username_from_email(developer_data.email)
    
    db_developer = Developer(
        last_name=developer_data.last_name,
        first_name=developer_data.first_name,
        middle_name=developer_data.middle_name,
        email=developer_data.email,
        position=developer_data.position,
        department=developer_data.department
    )
    
    session.add(db_developer)
    await session.commit()
    await session.refresh(db_developer)
    
    # Подготавливаем данные для API
    user_data = {
        'username': username,
        'email': developer_data.email,
        'first_name': developer_data.first_name,
        'last_name': developer_data.last_name,
        'middle_name': developer_data.middle_name,
        'position': developer_data.position,
        'department': developer_data.department
    }
    
    # Интеграция с GitLab
    if settings_obj.gitlab_url and settings_obj.gitlab_token:
        try:
            gitlab_api = GitLabAPI(settings_obj.gitlab_url, settings_obj.gitlab_token)
            
            # Ищем существующего пользователя по username и email
            existing_user = await gitlab_api.find_existing_user(user_data['username'], developer_data.email)
            
            if existing_user:
                # Пользователь уже существует, используем его ID
                gitlab_user_id = existing_user['id']
                db_developer.gitlab_user_id = gitlab_user_id
                db_developer.gitlab_username = existing_user['username']
                logger.info(f"Found existing GitLab user with ID {gitlab_user_id}")
            else:
                # Создаем нового пользователя в GitLab
                gitlab_user_id = await gitlab_api.create_user(user_data)
                
                if gitlab_user_id:
                    db_developer.gitlab_user_id = gitlab_user_id
                    db_developer.gitlab_username = user_data['username']
                    logger.info(f"Created new GitLab user with ID {gitlab_user_id}")
            
            if gitlab_user_id:
                
                # Получаем названия проектов для пайплайна
                project_names = []
                if developer_data.project_ids:
                    for project_id in developer_data.project_ids:
                        project_result = await session.execute(
                            select(Project).where(Project.id == project_id)
                        )
                        project = project_result.scalar_one_or_none()
                        
                        if project:
                            project_names.append(project.name)
                            
                            if project.gitlab_project_id:
                                await gitlab_api.add_user_to_project(
                                    gitlab_user_id, 
                                    project.gitlab_project_id
                                )
                            
                            # Создаем связь разработчик-проект
                            dev_project = DeveloperProject(
                                developer_id=db_developer.id,
                                project_id=project_id,
                                active=True
                            )
                            session.add(dev_project)
                
                # Запускаем пайплайн в проекте по умолчанию
                if settings_obj.project_id:
                    pipeline_id = await gitlab_api.trigger_pipeline(
                        settings_obj.project_id,
                        user_data,
                        project_names
                    )
                    if pipeline_id:
                        logger.info(f"GitLab pipeline {pipeline_id} triggered for developer {developer_data.email}")
                    else:
                        logger.warning(f"Failed to trigger GitLab pipeline for developer {developer_data.email}")
                        
        except Exception as e:
            logger.error(f"GitLab integration error: {e}")
    
    # Интеграция с Redmine
    if settings_obj.redmine_url and settings_obj.redmine_token:
        try:
            redmine_api = RedmineAPI(settings_obj.redmine_url, settings_obj.redmine_token)
            
            # Ищем существующего пользователя по username и email
            existing_user = await redmine_api.find_existing_user(user_data['username'], developer_data.email)
            
            if existing_user:
                # Пользователь уже существует, используем его ID
                redmine_user_id = existing_user['id']
                db_developer.redmine_user_id = redmine_user_id
                db_developer.redmine_username = existing_user['login']
                logger.info(f"Found existing Redmine user with ID {redmine_user_id}")
            else:
                # Создаем нового пользователя в Redmine
                redmine_user_id = await redmine_api.create_user(user_data)
                
                if redmine_user_id:
                    db_developer.redmine_user_id = redmine_user_id
                    db_developer.redmine_username = user_data['username']
                    logger.info(f"Created new Redmine user with ID {redmine_user_id}")
            
            # Добавляем пользователя к проектам в Redmine
            if redmine_user_id and developer_data.project_ids:
                for project_id in developer_data.project_ids:
                    project_result = await session.execute(
                        select(Project).where(Project.id == project_id)
                    )
                    project = project_result.scalar_one_or_none()
                    
                    if project:
                        await redmine_api.add_user_to_project(
                            redmine_user_id, 
                            str(project.id)  # Redmine использует строковые ID проектов
                        )
        except Exception as e:
            logger.error(f"Redmine integration error: {e}")
    
    await session.commit()
    await session.refresh(db_developer)
    
    return db_developer


@router.post("/developers/{developer_id}/create-gitlab-user")
async def create_gitlab_user(
    developer_id: int,
    current_user: User = Depends(get_current_admin_user),
    session: AsyncSession = Depends(get_async_session)
):
    """Создание пользователя в GitLab для существующего разработчика"""
    # Получаем разработчика
    result = await session.execute(
        select(Developer).where(Developer.id == developer_id)
    )
    developer = result.scalar_one_or_none()
    
    if not developer:
        raise HTTPException(status_code=404, detail="Developer not found")
    
    # Получаем настройки
    result = await session.execute(select(Settings).order_by(Settings.id.desc()).limit(1))
    settings_obj = result.scalar_one_or_none()
    
    if not settings_obj or not settings_obj.gitlab_url or not settings_obj.gitlab_token:
        raise HTTPException(status_code=400, detail="GitLab settings not configured")
    
    # Подготавливаем данные для API
    from utils import generate_username_from_email
    username = generate_username_from_email(developer.email)
    
    user_data = {
        'username': username,
        'email': developer.email,
        'first_name': developer.first_name,
        'last_name': developer.last_name,
        'middle_name': developer.middle_name,
        'position': developer.position,
        'department': developer.department
    }
    
    # Проверяем, существует ли пользователь в GitLab
    try:
        gitlab_api = GitLabAPI(settings_obj.gitlab_url, settings_obj.gitlab_token)
        
        # Ищем существующего пользователя по username и email
        existing_user = await gitlab_api.find_existing_user(username, developer.email)
        
        if existing_user:
            # Пользователь уже существует
            gitlab_user_id = existing_user['id']
            
            # Обновляем данные разработчика
            developer.gitlab_user_id = gitlab_user_id
            developer.gitlab_username = existing_user['username']
            await session.commit()
            
            return {
                "message": f"User already exists in GitLab with ID {gitlab_user_id}",
                "gitlab_user_id": gitlab_user_id,
                "gitlab_username": existing_user['username'],
                "user_info": existing_user,
                "existing": True
            }
        
        # Создаем нового пользователя в GitLab
        gitlab_user_id = await gitlab_api.create_user(user_data)
        
        if gitlab_user_id:
            # Обновляем разработчика
            developer.gitlab_user_id = gitlab_user_id
            developer.gitlab_username = username
            await session.commit()
            
            return {
                "message": "GitLab user created successfully",
                "gitlab_user_id": gitlab_user_id,
                "gitlab_username": username,
                "existing": False
            }
        else:
            raise HTTPException(status_code=500, detail="Failed to create GitLab user")
            
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"GitLab integration error: {str(e)}")


@router.post("/developers/{developer_id}/create-redmine-user")
async def create_redmine_user(
    developer_id: int,
    current_user: User = Depends(get_current_admin_user),
    session: AsyncSession = Depends(get_async_session)
):
    """Создание пользователя в Redmine для существующего разработчика"""
    # Получаем разработчика
    result = await session.execute(
        select(Developer).where(Developer.id == developer_id)
    )
    developer = result.scalar_one_or_none()
    
    if not developer:
        raise HTTPException(status_code=404, detail="Developer not found")
    
    # Получаем настройки
    result = await session.execute(select(Settings).order_by(Settings.id.desc()).limit(1))
    settings_obj = result.scalar_one_or_none()
    
    if not settings_obj or not settings_obj.redmine_url or not settings_obj.redmine_token:
        raise HTTPException(status_code=400, detail="Redmine settings not configured")
    
    # Подготавливаем данные для API
    from utils import generate_username_from_email
    username = generate_username_from_email(developer.email)
    
    user_data = {
        'username': username,
        'email': developer.email,
        'first_name': developer.first_name,
        'last_name': developer.last_name,
        'middle_name': developer.middle_name,
        'position': developer.position,
        'department': developer.department
    }
    
    # Проверяем, существует ли пользователь в Redmine
    try:
        redmine_api = RedmineAPI(settings_obj.redmine_url, settings_obj.redmine_token)
        
        # Ищем существующего пользователя по username и email
        existing_user = await redmine_api.find_existing_user(username, developer.email)
        
        if existing_user:
            # Пользователь уже существует
            redmine_user_id = existing_user['id']
            sequential_number = redmine_user_id
            user_info = existing_user
            
            # Обновляем данные разработчика
            developer.redmine_user_id = redmine_user_id
            developer.redmine_username = existing_user['login']
            await session.commit()
            
            return {
                "message": f"User already exists in Redmine with ID {redmine_user_id}",
                "redmine_user_id": redmine_user_id,
                "sequential_number": sequential_number,
                "user_info": user_info,
                "existing": True
            }
        
        # Создаем нового пользователя в Redmine
        redmine_user_id = await redmine_api.create_user(user_data)
        
        if redmine_user_id:
            # Получаем порядковый номер пользователя
            sequential_number = await redmine_api.get_user_sequential_number(redmine_user_id)
            user_info = await redmine_api.get_user_info(redmine_user_id)
            
            # Обновляем разработчика
            developer.redmine_user_id = redmine_user_id
            developer.redmine_username = username
            await session.commit()
            
            return {
                "message": "Redmine user created successfully",
                "redmine_user_id": redmine_user_id,
                "redmine_username": username,
                "sequential_number": sequential_number,
                "user_info": user_info
            }
        else:
            raise HTTPException(status_code=500, detail="Failed to create Redmine user")
            
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Redmine integration error: {str(e)}")


@router.get("/developers/{developer_id}/redmine-info")
async def get_redmine_user_info(
    developer_id: int,
    current_user: User = Depends(get_current_admin_user),
    session: AsyncSession = Depends(get_async_session)
):
    """Получение информации о пользователе из Redmine"""
    # Получаем разработчика
    result = await session.execute(
        select(Developer).where(Developer.id == developer_id)
    )
    developer = result.scalar_one_or_none()
    
    if not developer:
        raise HTTPException(status_code=404, detail="Developer not found")
    
    if not developer.redmine_user_id:
        raise HTTPException(status_code=400, detail="Developer has no Redmine user ID")
    
    # Получаем настройки
    result = await session.execute(select(Settings).order_by(Settings.id.desc()).limit(1))
    settings_obj = result.scalar_one_or_none()
    
    if not settings_obj or not settings_obj.redmine_url or not settings_obj.redmine_token:
        raise HTTPException(status_code=400, detail="Redmine settings not configured")
    
    try:
        redmine_api = RedmineAPI(settings_obj.redmine_url, settings_obj.redmine_token)
        
        # Получаем информацию о пользователе
        user_info = await redmine_api.get_user_info(developer.redmine_user_id)
        sequential_number = await redmine_api.get_user_sequential_number(developer.redmine_user_id)
        
        return {
            "developer_id": developer.id,
            "redmine_user_id": developer.redmine_user_id,
            "sequential_number": sequential_number,
            "user_info": user_info
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error getting Redmine user info: {str(e)}")
