#!/usr/bin/env python3
"""
Простая система аутентификации без конфликтов сессий
"""

import asyncio
import logging
from typing import Optional
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from jose import JWTError, jwt
from fastapi import Request
from models import User
from config import settings
from utils import verify_password

logger = logging.getLogger(__name__)


async def get_user_by_username_isolated(username: str) -> Optional[User]:
    """Изолированное получение пользователя по имени с собственной сессией"""
    try:
        from database import async_session_maker
        async with async_session_maker() as session:
            result = await session.execute(select(User).where(User.username == username))
            return result.scalar_one_or_none()
    except Exception as e:
        logger.error(f"Ошибка при получении пользователя {username}: {e}")
        return None


async def authenticate_user_isolated(username: str, password: str) -> Optional[User]:
    """Изолированная аутентификация пользователя с собственной сессией"""
    try:
        user = await get_user_by_username_isolated(username)
        if not user:
            return None
        
        if not verify_password(password, user.password_hash):
            return None
        
        return user
    except Exception as e:
        logger.error(f"Ошибка при аутентификации пользователя {username}: {e}")
        return None


async def get_user_from_cookie_isolated(request: Request) -> Optional[User]:
    """Изолированное получение пользователя из cookie с собственной сессией"""
    try:
        # Проверяем cookie
        token = request.cookies.get("access_token")
        if not token:
            return None
        
        # Убеждаемся, что токен имеет правильный формат
        if not token.startswith("Bearer "):
            token = f"Bearer {token}"
        
        # Извлекаем токен
        token = token.split(" ")[1]
        
        # Декодируем JWT
        payload = jwt.decode(token, settings.secret_key, algorithms=[settings.algorithm])
        username: str = payload.get("sub")
        if username is None:
            return None
        
        # Получаем пользователя с изолированной сессией
        user = await get_user_by_username_isolated(username)
        return user
    except (JWTError, IndexError) as e:
        logger.debug(f"Ошибка при получении пользователя из cookie: {e}")
        return None
    except Exception as e:
        logger.error(f"Ошибка при получении пользователя из cookie: {e}")
        return None


async def test_simple_auth():
    """Тестирование простой аутентификации"""
    print("🧪 Тестирование изолированной аутентификации...")
    
    try:
        # Тест получения пользователя
        user = await get_user_by_username_isolated("admin")
        if user:
            print(f"✅ Пользователь найден: {user.username}")
        else:
            print("⚠️ Пользователь admin не найден")
        
        # Тест аутентификации
        if user:
            auth_user = await authenticate_user_isolated("admin", "admin123")
            if auth_user:
                print("✅ Аутентификация работает")
            else:
                print("❌ Аутентификация не работает")
        
    except Exception as e:
        print(f"❌ Ошибка при тестировании: {e}")


if __name__ == "__main__":
    asyncio.run(test_simple_auth())
