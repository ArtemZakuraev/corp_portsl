"""Add new fields to developers table

Revision ID: 002
Revises: 001
Create Date: 2024-01-01 12:00:00.000000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '002'
down_revision = '001'
branch_labels = None
depends_on = None


def upgrade():
    """Add new fields to developers table"""
    # Add new columns to developers table
    op.add_column('developers', sa.Column('phone', sa.String(20), nullable=True))
    op.add_column('developers', sa.Column('telegram', sa.String(100), nullable=True))
    op.add_column('developers', sa.Column('slack', sa.String(100), nullable=True))
    op.add_column('developers', sa.Column('rm_id', sa.String(50), nullable=True))
    op.add_column('developers', sa.Column('gitlab_username', sa.String(100), nullable=True))
    op.add_column('developers', sa.Column('redmine_username', sa.String(100), nullable=True))
    op.add_column('developers', sa.Column('is_active', sa.Boolean(), nullable=True, default=True))
    op.add_column('developers', sa.Column('notes', sa.Text(), nullable=True))


def downgrade():
    """Remove new fields from developers table"""
    op.drop_column('developers', 'notes')
    op.drop_column('developers', 'is_active')
    op.drop_column('developers', 'redmine_username')
    op.drop_column('developers', 'gitlab_username')
    op.drop_column('developers', 'rm_id')
    op.drop_column('developers', 'slack')
    op.drop_column('developers', 'telegram')
    op.drop_column('developers', 'phone')
