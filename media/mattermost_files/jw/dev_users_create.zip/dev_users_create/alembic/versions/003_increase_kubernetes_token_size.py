"""Increase kubernetes_token field size

Revision ID: 003
Revises: 002
Create Date: 2024-01-01 12:00:00.000000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '003'
down_revision = '002'
branch_labels = None
depends_on = None


def upgrade():
    """Increase kubernetes_token field size to support longer JWT tokens"""
    # Alter the kubernetes_token column to support longer tokens
    op.alter_column('settings', 'kubernetes_token',
                    existing_type=sa.String(255),
                    type_=sa.String(2000),
                    existing_nullable=True)


def downgrade():
    """Revert kubernetes_token field size back to 255 characters"""
    # Revert the kubernetes_token column back to original size
    op.alter_column('settings', 'kubernetes_token',
                    existing_type=sa.String(2000),
                    type_=sa.String(255),
                    existing_nullable=True)


