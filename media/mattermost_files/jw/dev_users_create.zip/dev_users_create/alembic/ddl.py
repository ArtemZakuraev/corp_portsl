"""
DDL utilities for Alembic migrations
"""

from typing import List, Any


def sort_tables(tables: List[Any]) -> List[Any]:
    """
    Sort tables in dependency order for migrations.
    This ensures that tables are created in the correct order
    to avoid foreign key constraint violations.
    """
    # Define the order of table creation based on dependencies
    table_order = [
        'users',
        'settings', 
        'projects',
        'developers',
        'developer_projects'
    ]
    
    # Create a mapping of table names to table objects
    table_map = {table.name: table for table in tables}
    
    # Sort tables according to the defined order
    sorted_tables = []
    for table_name in table_order:
        if table_name in table_map:
            sorted_tables.append(table_map[table_name])
    
    # Add any remaining tables that weren't in our predefined order
    for table in tables:
        if table not in sorted_tables:
            sorted_tables.append(table)
    
    return sorted_tables


