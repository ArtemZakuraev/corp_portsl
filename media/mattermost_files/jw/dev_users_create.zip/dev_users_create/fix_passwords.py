#!/usr/bin/env python3
"""
Скрипт для исправления проблем с хешированием паролей
"""

import asyncio
import sys
import os
from sqlalchemy.ext.asyncio import AsyncSession
from database import get_async_session, engine
from models import User, Base
from utils import get_password_hash, verify_password
from sqlalchemy import select


async def fix_user_passwords():
    """Исправление паролей пользователей"""
    print("🔧 Исправление проблем с паролями...")
    
    # Создаем таблицы если их нет
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    
    async for session in get_async_session():
        try:
            # Получаем всех пользователей
            result = await session.execute(select(User))
            users = result.scalars().all()
            
            if not users:
                print("📊 Пользователи не найдены")
                return
            
            print(f"👥 Найдено пользователей: {len(users)}")
            
            updated_count = 0
            for user in users:
                print(f"\n🔍 Проверка пользователя: {user.username}")
                
                # Проверяем, работает ли текущий хеш
                test_password = "test123"  # Тестовый пароль
                try:
                    # Пытаемся проверить пароль
                    is_valid = verify_password(test_password, user.password_hash)
                    if is_valid:
                        print(f"   ✅ Пароль работает корректно")
                        continue
                except Exception as e:
                    print(f"   ⚠️ Ошибка при проверке пароля: {e}")
                
                # Если пароль не работает, предлагаем обновить
                print(f"   🔧 Пароль требует обновления")
                
                # Для администратора по умолчанию используем стандартный пароль
                if user.username == "admin" and user.email == "admin@example.com":
                    new_password = "admin123"
                    print(f"   🔑 Устанавливаем стандартный пароль для admin")
                else:
                    # Для других пользователей запрашиваем новый пароль
                    new_password = input(f"   Введите новый пароль для {user.username} (или Enter для пропуска): ").strip()
                    if not new_password:
                        print(f"   ⏭️ Пропускаем пользователя {user.username}")
                        continue
                
                # Хешируем новый пароль
                try:
                    new_hash = get_password_hash(new_password)
                    user.password_hash = new_hash
                    updated_count += 1
                    print(f"   ✅ Пароль обновлен для {user.username}")
                except Exception as e:
                    print(f"   ❌ Ошибка при обновлении пароля для {user.username}: {e}")
            
            if updated_count > 0:
                await session.commit()
                print(f"\n🎉 Обновлено паролей: {updated_count}")
            else:
                print(f"\n✅ Все пароли в порядке")
                
        except Exception as e:
            print(f"❌ Ошибка при исправлении паролей: {e}")
            await session.rollback()
        finally:
            await session.close()
        break


async def test_password_system():
    """Тестирование системы паролей"""
    print("🧪 Тестирование системы паролей...")
    
    test_passwords = [
        "admin123",
        "password",
        "test123",
        "a" * 100,  # Длинный пароль
        "пароль123",  # Пароль с кириллицей
        "password!@#$%^&*()",  # Пароль со спецсимволами
    ]
    
    for password in test_passwords:
        try:
            print(f"\n🔍 Тестирование пароля: '{password[:20]}{'...' if len(password) > 20 else ''}'")
            
            # Хешируем пароль
            hashed = get_password_hash(password)
            print(f"   📝 Хеш создан: {hashed[:50]}...")
            
            # Проверяем пароль
            is_valid = verify_password(password, hashed)
            print(f"   ✅ Проверка: {'Успешно' if is_valid else 'Неудачно'}")
            
        except Exception as e:
            print(f"   ❌ Ошибка: {e}")


async def create_test_admin():
    """Создание тестового администратора"""
    print("👤 Создание тестового администратора...")
    
    async for session in get_async_session():
        try:
            # Проверяем, существует ли тестовый пользователь
            result = await session.execute(select(User).where(User.username == "testadmin"))
            existing_user = result.scalar_one_or_none()
            
            if existing_user:
                print("✅ Тестовый администратор уже существует")
                return existing_user
            
            # Создаем тестового администратора
            password = "test123"
            hashed_password = get_password_hash(password)
            
            test_admin = User(
                username="testadmin",
                email="test@example.com",
                password_hash=hashed_password,
                is_admin=True
            )
            
            session.add(test_admin)
            await session.commit()
            await session.refresh(test_admin)
            
            print(f"✅ Тестовый администратор создан:")
            print(f"   Имя пользователя: testadmin")
            print(f"   Пароль: test123")
            print(f"   Email: test@example.com")
            
            return test_admin
            
        except Exception as e:
            print(f"❌ Ошибка при создании тестового администратора: {e}")
            await session.rollback()
        finally:
            await session.close()
        break


async def main():
    """Главная функция"""
    if len(sys.argv) > 1:
        if sys.argv[1] == "test":
            await test_password_system()
        elif sys.argv[1] == "create-test":
            await create_test_admin()
        elif sys.argv[1] == "help":
            print("Использование:")
            print("  python fix_passwords.py           - Исправить пароли пользователей")
            print("  python fix_passwords.py test      - Тестировать систему паролей")
            print("  python fix_passwords.py create-test - Создать тестового администратора")
            print("  python fix_passwords.py help      - Показать эту справку")
        else:
            print(f"❌ Неизвестная команда: {sys.argv[1]}")
            print("Используйте 'python fix_passwords.py help' для справки")
    else:
        await fix_user_passwords()


if __name__ == "__main__":
    asyncio.run(main())

