#!/usr/bin/env python3
"""
Скрипт для первоначальной настройки системы
"""

import asyncio
import sys
import os

async def setup_system():
    """Настройка системы"""
    print("🔧 Настройка Developer Management System...")
    print("="*50)
    
    # Проверяем, существует ли база данных
    db_exists = os.path.exists("app.db")
    
    if db_exists:
        print("📊 База данных уже существует")
        choice = input("Хотите пересоздать базу данных? (y/N): ").strip().lower()
        if choice in ['y', 'yes', 'да']:
            print("🗑️ Удаление старой базы данных...")
            try:
                os.remove("app.db")
                print("✅ Старая база данных удалена")
            except Exception as e:
                print(f"❌ Ошибка при удалении базы данных: {e}")
                return
        else:
            print("📊 Используем существующую базу данных")
    
    # Инициализируем базу данных
    try:
        from init_db import init_database
        print("\n🔧 Инициализация базы данных...")
        await init_database(interactive=True)
        print("\n✅ Система настроена!")
        
        # Показываем информацию о запуске
        print("\n" + "="*50)
        print("🎉 Настройка завершена!")
        print("\n📋 Следующие шаги:")
        print("1. Запустите приложение: python run_app.py")
        print("2. Откройте браузер: http://localhost:8000")
        print("3. Войдите в систему с созданными учетными данными")
        print("\n📚 Дополнительные команды:")
        print("  python init_db.py list         - Показать пользователей")
        print("  python init_db.py interactive  - Создать нового администратора")
        print("  python create_admin.py         - Альтернативный способ создания администратора")
        
    except Exception as e:
        print(f"❌ Ошибка при настройке системы: {e}")
        return

if __name__ == "__main__":
    asyncio.run(setup_system())

