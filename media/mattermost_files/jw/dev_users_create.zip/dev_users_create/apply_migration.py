#!/usr/bin/env python3
"""
Скрипт для применения миграции базы данных
"""
import asyncio
import sys
import os
from sqlalchemy import text
from database import engine

async def apply_migration():
    """Применяет миграцию для увеличения размера поля kubernetes_token"""
    
    try:
        async with engine.begin() as conn:
            # Проверяем текущий размер поля
            result = await conn.execute(text("""
                SELECT character_maximum_length 
                FROM information_schema.columns 
                WHERE table_name = 'settings' 
                AND column_name = 'kubernetes_token'
            """))
            
            current_length = result.scalar()
            print(f"Текущий размер поля kubernetes_token: {current_length}")
            
            if current_length == 255:
                print("Применяем миграцию для увеличения размера поля...")
                await conn.execute(text("""
                    ALTER TABLE settings 
                    ALTER COLUMN kubernetes_token TYPE VARCHAR(2000)
                """))
                print("Миграция успешно применена!")
            else:
                print(f"Поле уже имеет размер {current_length}, миграция не требуется")
                
    except Exception as e:
        print(f"Ошибка при применении миграции: {e}")
        return False
    finally:
        await engine.dispose()
    
    return True

if __name__ == "__main__":
    success = asyncio.run(apply_migration())
    sys.exit(0 if success else 1)
