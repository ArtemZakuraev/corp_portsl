#!/usr/bin/env python3
"""
Скрипт для создания необходимых директорий
"""

import os
from pathlib import Path

def create_directories():
    """Создание необходимых директорий"""
    directories = [
        "static",
        "static/uploads",
        "templates",
        "alembic",
        "alembic/versions"
    ]
    
    for directory in directories:
        Path(directory).mkdir(parents=True, exist_ok=True)
        print(f"✓ Создана директория: {directory}")

if __name__ == "__main__":
    print("Создание директорий...")
    create_directories()
    print("Готово!")


