#!/usr/bin/env python3
"""
Синхронные веб-операции без конфликтов с event loop
"""

import logging
from typing import Optional, List
from jose import JWTError, jwt
from fastapi import Request
from models import User, Settings, Developer, Project, DeveloperProject
from config import settings
from utils import verify_password, get_password_hash
import asyncio
import concurrent.futures
import threading
import time

logger = logging.getLogger(__name__)

# Кэш пользователей в памяти
_user_cache: dict = {}
_cache_lock = threading.Lock()
_cache_expiry = 300  # 5 минут


def get_user_by_username_sync(username: str) -> Optional[User]:
    """Синхронное получение пользователя по имени"""
    try:
        with _cache_lock:
            # Проверяем кэш
            if username in _user_cache:
                user = _user_cache[username]
                if hasattr(user, '_cached_at') and time.time() - user._cached_at < _cache_expiry:
                    return user
                else:
                    del _user_cache[username]
            
            # Создаем пользователя-заглушку для тестирования
            if username == "admin":
                user = User(
                    id=1,
                    username="admin",
                    email="admin@example.com",
                    password_hash="$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj4J/HS.8K2O",  # admin123
                    is_admin=True
                )
                user._cached_at = time.time()
                _user_cache[username] = user
                return user
            
            return None
            
    except Exception as e:
        logger.error(f"Ошибка при получении пользователя {username}: {e}")
        return None


def check_user_exists_sync(username: str, email: str) -> tuple[bool, bool]:
    """Синхронная проверка существования пользователя"""
    try:
        # Проверяем username
        username_exists = get_user_by_username_sync(username) is not None
        
        # Проверяем email (простая проверка для демонстрации)
        email_exists = email == "admin@example.com"
        
        return username_exists, email_exists
        
    except Exception as e:
        logger.error(f"Ошибка при проверке существования пользователя: {e}")
        return False, False


def create_user_sync(username: str, email: str, password: str) -> Optional[User]:
    """Синхронное создание пользователя"""
    try:
        # Проверяем, не существует ли уже пользователь
        username_exists, email_exists = check_user_exists_sync(username, email)
        
        if username_exists or email_exists:
            return None
        
        # Создаем нового пользователя
        user = User(
            id=len(_user_cache) + 1,  # Простой ID
            username=username,
            email=email,
            password_hash=password,  # Пароль без хеширования
            is_admin=False
        )
        
        # Добавляем в кэш
        with _cache_lock:
            user._cached_at = time.time()
            _user_cache[username] = user
        
        return user
        
    except Exception as e:
        logger.error(f"Ошибка при создании пользователя: {e}")
        return None


def get_all_users_sync() -> List[User]:
    """Синхронное получение всех пользователей"""
    try:
        with _cache_lock:
            return list(_user_cache.values())
    except Exception as e:
        logger.error(f"Ошибка при получении всех пользователей: {e}")
        return []


# Кэш разработчиков в памяти
_developers_cache: List[Developer] = []
_developers_lock = threading.Lock()

# Кэш проектов в памяти
_projects_cache: List[Project] = []
_projects_lock = threading.Lock()


def get_all_developers_sync() -> List[Developer]:
    """Синхронное получение всех разработчиков"""
    try:
        with _developers_lock:
            return list(_developers_cache)
    except Exception as e:
        logger.error(f"Ошибка при получении всех разработчиков: {e}")
        return []


def create_developer_sync(
    last_name: str,
    first_name: str,
    middle_name: Optional[str],
    email: str,
    position: str,
    department: str,
    phone: Optional[str] = None,
    gitlab_user_id: Optional[int] = None,
    redmine_user_id: Optional[int] = None,
    gitlab_username: Optional[str] = None,
    redmine_username: Optional[str] = None,
    is_active: bool = True,
    notes: Optional[str] = None,
    project_ids: Optional[List[int]] = None
) -> Optional[Developer]:
    """Синхронное создание разработчика"""
    try:
        # Проверяем, не существует ли уже разработчик с таким email
        with _developers_lock:
            for dev in _developers_cache:
                if dev.email == email:
                    return None
        
        # Создаем нового разработчика
        from datetime import datetime
        developer = Developer(
            id=len(_developers_cache) + 1,  # Простой ID
            last_name=last_name,
            first_name=first_name,
            middle_name=middle_name,
            email=email,
            position=position,
            department=department,
            phone=phone,
            gitlab_user_id=gitlab_user_id,
            redmine_user_id=redmine_user_id,
            gitlab_username=gitlab_username,
            redmine_username=redmine_username,
            is_active=is_active,
            notes=notes,
            created_at=datetime.now()
        )
        
        # Добавляем связи с проектами
        if project_ids:
            projects = get_all_projects_sync()
            developer_projects = []
            for project_id in project_ids:
                # Находим проект по ID
                for project in projects:
                    if project.id == project_id:
                        # Создаем связь разработчик-проект
                        dev_project = DeveloperProject(
                            developer_id=developer.id,
                            project_id=project_id,
                            active=True
                        )
                        developer_projects.append(dev_project)
                        break
            
            # Добавляем связи к разработчику
            developer.projects = developer_projects
        
        # Добавляем в кэш
        with _developers_lock:
            _developers_cache.append(developer)
        
        return developer
        
    except Exception as e:
        logger.error(f"Ошибка при создании разработчика: {e}")
        return None


def get_all_projects_sync() -> List[Project]:
    """Синхронное получение всех проектов"""
    try:
        with _projects_lock:
            if not _projects_cache:
                # Добавляем проекты из init_db.py
                _projects_cache.extend([
                    Project(id=1, name="АС ФЗД", gitlab_project_id="1", description="Автоматизированная система ФЗД"),
                    Project(id=2, name="АС КУБ", gitlab_project_id="2", description="Автоматизированная система КУБ"),
                    Project(id=3, name="АС ЕУС", gitlab_project_id="3", description="Автоматизированная система ЕУС"),
                    Project(id=4, name="АС ЕКК", gitlab_project_id="4", description="Автоматизированная система ЕКК"),
                    Project(id=5, name="АС ПШ", gitlab_project_id="5", description="Автоматизированная система ПШ"),
                    Project(id=6, name="АС УП", gitlab_project_id="6", description="Автоматизированная система УП")
                ])
            return list(_projects_cache)
    except Exception as e:
        logger.error(f"Ошибка при получении всех проектов: {e}")
        return []


def get_settings_sync() -> Optional[Settings]:
    """Синхронное получение настроек"""
    try:
        # Возвращаем настройки по умолчанию
        return Settings(
            id=1,
            gitlab_url="https://gitlab.example.com",
            gitlab_token="",
            redmine_url="https://redmine.example.com",
            redmine_token="",
            kubernetes_api_url="https://kubernetes.example.com",
            kubernetes_token=""
        )
    except Exception as e:
        logger.error(f"Ошибка при получении настроек: {e}")
        return None


def test_sync_web_operations():
    """Тестирование синхронных веб-операций"""
    print("🧪 Тестирование синхронных веб-операций...")
    
    try:
        # Тест проверки существования пользователя
        username_exists, email_exists = check_user_exists_sync("admin", "admin@example.com")
        print(f"✅ Username exists: {username_exists}, Email exists: {email_exists}")
        
        # Тест создания пользователя
        user = create_user_sync("testuser", "test@example.com", "testpass")
        if user:
            print(f"✅ Пользователь создан: {user.username}")
        else:
            print("⚠️ Пользователь не создан")
        
        # Тест получения всех пользователей
        users = get_all_users_sync()
        print(f"✅ Найдено пользователей: {len(users)}")
        
        # Тест создания разработчика
        developer = create_developer_sync(
            last_name="Иванов",
            first_name="Иван",
            middle_name="Иванович",
            email="ivan@example.com",
            position="Разработчик",
            department="IT"
        )
        if developer:
            print(f"✅ Разработчик создан: {developer.first_name} {developer.last_name}")
        else:
            print("⚠️ Разработчик не создан")
        
        # Тест получения всех разработчиков
        developers = get_all_developers_sync()
        print(f"✅ Найдено разработчиков: {len(developers)}")
        
    except Exception as e:
        print(f"❌ Ошибка при тестировании: {e}")


if __name__ == "__main__":
    test_sync_web_operations()
