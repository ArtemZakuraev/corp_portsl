#!/usr/bin/env python3
"""
Скрипт для наполнения базы данных начальными данными
"""

import asyncio
import logging
import sys
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from database import async_session_maker, engine
from models import User, Project, Settings, Base
# Хеширование паролей отключено

# Настройка логирования
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


async def create_admin_user_interactive(session: AsyncSession):
    """Интерактивное создание администратора"""
    print("\n🔧 Создание администратора системы...")
    
    # Проверяем, есть ли уже администраторы
    result = await session.execute(select(User).where(User.is_admin == True))
    existing_admins = result.scalars().all()
    
    if existing_admins:
        admin = existing_admins[0]  # Берем первого администратора
        print(f"✅ Администратор уже существует: {admin.username}")
        print(f"   Email: {admin.email}")
        return admin
    
    # Запрашиваем данные администратора
    print("\n📝 Введите данные для создания администратора:")
    username = input("Имя пользователя: ").strip()
    email = input("Email: ").strip()
    password = input("Пароль: ").strip()
    
    if not username or not email or not password:
        print("❌ Все поля обязательны для заполнения!")
        return None
    
    # Проверяем, не существует ли пользователь с таким именем
    result = await session.execute(select(User).where(User.username == username))
    if result.scalar_one_or_none():
        print(f"❌ Пользователь с именем '{username}' уже существует!")
        return None
    
    # Проверяем, не существует ли пользователь с таким email
    result = await session.execute(select(User).where(User.email == email))
    if result.scalar_one_or_none():
        print(f"❌ Пользователь с email '{email}' уже существует!")
        return None
    
    # Создаем администратора
    try:
        # Пароль без хеширования
        hashed_password = password
        admin_user = User(
            username=username,
            email=email,
            password_hash=hashed_password,
            is_admin=True
        )
        
        session.add(admin_user)
        await session.flush()  # Получаем ID без коммита
        
        print(f"\n✅ Администратор успешно создан!")
        print(f"   ID: {admin_user.id}")
        print(f"   Имя пользователя: {admin_user.username}")
        print(f"   Email: {admin_user.email}")
        print(f"   Права: Администратор")
        
        return admin_user
        
    except Exception as e:
        logger.error(f"Ошибка при создании администратора: {e}")
        return None


async def create_default_admin(session: AsyncSession):
    """Создание администратора по умолчанию"""
    # Проверяем, есть ли уже администраторы
    result = await session.execute(select(User).where(User.is_admin == True))
    existing_admins = result.scalars().all()
    
    if existing_admins:
        admin = existing_admins[0]  # Берем первого администратора
        print(f"✅ Администратор уже существует: {admin.username}")
        return admin
    
    try:
        # Пароль без хеширования
        admin_password_hash = "admin123"
        admin = User(
            username="admin",
            email="admin@example.com",
            password_hash=admin_password_hash,
            is_admin=True
        )
        session.add(admin)
        print("✓ Создан администратор по умолчанию: admin / admin123")
        return admin
    except Exception as e:
        logger.error(f"Ошибка при создании администратора: {e}")
        # Используем простой хеш как fallback
        import hashlib
        admin_password_hash = hashlib.sha256("admin123".encode()).hexdigest()
        admin = User(
            username="admin",
            email="admin@example.com",
            password_hash=admin_password_hash,
            is_admin=True
        )
        session.add(admin)
        print("✓ Создан администратор с fallback хешем: admin / admin123")
        return admin


async def init_database(interactive=False):
    """Инициализация базы данных начальными данными"""
    
    # Создаем таблицы если их нет
    print("🔧 Создание таблиц базы данных...")
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    print("✅ Таблицы созданы")
    
    async with async_session_maker() as session:
        try:
            # Создаем администратора
            if interactive:
                admin_user = await create_admin_user_interactive(session)
            else:
                admin_user = await create_default_admin(session)
            
            if not admin_user:
                print("❌ Не удалось создать администратора")
                return
            
            # Создаем проекты по умолчанию
            projects_data = [
                {"name": "АС ФЗД", "gitlab_project_id": "1", "description": "Автоматизированная система ФЗД"},
                {"name": "АС КУБ", "gitlab_project_id": "2", "description": "Автоматизированная система КУБ"},
                {"name": "АС ЕУС", "gitlab_project_id": "3", "description": "Автоматизированная система ЕУС"},
                {"name": "АС ЕКК", "gitlab_project_id": "4", "description": "Автоматизированная система ЕКК"},
                {"name": "АС ПШ", "gitlab_project_id": "5", "description": "Автоматизированная система ПШ"},
                {"name": "АС УП", "gitlab_project_id": "6", "description": "Автоматизированная система УП"},
            ]
            
            for project_data in projects_data:
                existing_project = await session.execute(
                    select(Project).where(Project.name == project_data["name"])
                )
                if not existing_project.scalar_one_or_none():
                    project = Project(**project_data)
                    session.add(project)
                    print(f"✓ Создан проект: {project_data['name']}")
            
            # Создаем настройки по умолчанию
            settings_result = await session.execute(
                select(Settings).order_by(Settings.id.desc()).limit(1)
            )
            settings_obj = settings_result.scalar_one_or_none()
            if not settings_obj:
                default_settings = Settings(
                    gitlab_url="https://gitlab.com",
                    redmine_url="https://redmine.example.com",
                    kubernetes_api_url="https://kubernetes.example.com",
                    project_id="1"
                )
                session.add(default_settings)
                print("✓ Созданы настройки по умолчанию")
            
            await session.commit()
            print("\n🎉 База данных успешно инициализирована!")
            print(f"🌐 Теперь вы можете войти в систему по адресу: http://localhost:8000/login")
            
        except Exception as e:
            logger.error(f"Ошибка при инициализации базы данных: {e}")
            await session.rollback()
            raise


async def list_users():
    """Список всех пользователей"""
    print("👥 Список пользователей:")
    
    async with async_session_maker() as session:
        try:
            result = await session.execute(select(User))
            users = result.scalars().all()
            
            if not users:
                print("   Пользователи не найдены")
                return
            
            for user in users:
                role = "Администратор" if user.is_admin else "Пользователь"
                print(f"   {user.id}. {user.username} ({user.email}) - {role}")
                
        except Exception as e:
            print(f"❌ Ошибка при получении списка пользователей: {e}")


if __name__ == "__main__":
    if len(sys.argv) > 1:
        if sys.argv[1] == "interactive":
            print("🔧 Интерактивная инициализация базы данных...")
            asyncio.run(init_database(interactive=True))
        elif sys.argv[1] == "list":
            asyncio.run(list_users())
        elif sys.argv[1] == "help":
            print("Использование:")
            print("  python init_db.py              - Создание базы с администратором по умолчанию")
            print("  python init_db.py interactive  - Интерактивное создание администратора")
            print("  python init_db.py list         - Показать список пользователей")
            print("  python init_db.py help         - Показать эту справку")
        else:
            print(f"❌ Неизвестная команда: {sys.argv[1]}")
            print("Используйте 'python init_db.py help' для справки")
    else:
        print("🔧 Инициализация базы данных...")
        asyncio.run(init_database())
