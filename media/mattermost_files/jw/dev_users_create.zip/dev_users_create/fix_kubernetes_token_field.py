#!/usr/bin/env python3
"""
Скрипт для исправления размера поля kubernetes_token в базе данных
"""
import asyncio
import sys
import os
from sqlalchemy import text
from database import engine

async def fix_kubernetes_token_field():
    """Исправляет размер поля kubernetes_token в таблице settings"""
    
    try:
        async with engine.begin() as conn:
            print("Проверяем текущее состояние поля kubernetes_token...")
            
            # Проверяем текущий размер поля
            result = await conn.execute(text("""
                SELECT character_maximum_length 
                FROM information_schema.columns 
                WHERE table_name = 'settings' 
                AND column_name = 'kubernetes_token'
            """))
            
            current_length = result.scalar()
            print(f"Текущий размер поля kubernetes_token: {current_length}")
            
            if current_length == 255:
                print("Увеличиваем размер поля kubernetes_token с 255 до 2000 символов...")
                await conn.execute(text("""
                    ALTER TABLE settings 
                    ALTER COLUMN kubernetes_token TYPE VARCHAR(2000)
                """))
                print("✅ Поле kubernetes_token успешно увеличено до 2000 символов!")
            else:
                print(f"✅ Поле уже имеет размер {current_length} символов")
                
            # Проверяем результат
            result = await conn.execute(text("""
                SELECT character_maximum_length 
                FROM information_schema.columns 
                WHERE table_name = 'settings' 
                AND column_name = 'kubernetes_token'
            """))
            
            new_length = result.scalar()
            print(f"Новый размер поля kubernetes_token: {new_length}")
                
    except Exception as e:
        print(f"❌ Ошибка при исправлении поля: {e}")
        return False
    finally:
        await engine.dispose()
    
    return True

if __name__ == "__main__":
    print("🔧 Исправление размера поля kubernetes_token...")
    success = asyncio.run(fix_kubernetes_token_field())
    if success:
        print("✅ Исправление завершено успешно!")
    else:
        print("❌ Ошибка при исправлении!")
    sys.exit(0 if success else 1)
