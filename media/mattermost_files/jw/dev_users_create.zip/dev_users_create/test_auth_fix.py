#!/usr/bin/env python3
"""
Скрипт для тестирования исправлений аутентификации
"""

import asyncio
import sys
import os
from sqlalchemy.ext.asyncio import AsyncSession
from database import get_async_session, engine
from models import User, Base
from utils import get_password_hash, verify_password, authenticate_user
from sqlalchemy import select
import logging

# Настройка логирования
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


async def test_authentication():
    """Тестирование аутентификации"""
    print("🧪 Тестирование аутентификации...")
    
    # Создаем таблицы если их нет
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    
    async for session in get_async_session():
        try:
            # Проверяем, есть ли пользователь admin
            result = await session.execute(select(User).where(User.username == "admin"))
            admin_user = result.scalar_one_or_none()
            
            if not admin_user:
                print("⚠️ Пользователь admin не найден, создаем...")
                admin_password_hash = get_password_hash("admin123")
                admin = User(
                    username="admin",
                    email="admin@example.com",
                    password_hash=admin_password_hash,
                    is_admin=True
                )
                session.add(admin)
                await session.commit()
                await session.refresh(admin)
                admin_user = admin
                print("✅ Пользователь admin создан")
            
            # Тестируем аутентификацию
            print("\n🔍 Тестирование аутентификации...")
            
            # Создаем новую сессию для тестирования
            from database import async_session_maker
            async with async_session_maker() as test_session:
                # Тест 1: Правильный пароль
                print("   Тест 1: Правильный пароль")
                user = await authenticate_user(test_session, "admin", "admin123")
                if user:
                    print("   ✅ Аутентификация с правильным паролем работает")
                else:
                    print("   ❌ Аутентификация с правильным паролем не работает")
                
                # Тест 2: Неправильный пароль
                print("   Тест 2: Неправильный пароль")
                user = await authenticate_user(test_session, "admin", "wrongpassword")
                if not user:
                    print("   ✅ Аутентификация с неправильным паролем корректно отклонена")
                else:
                    print("   ❌ Аутентификация с неправильным паролем не отклонена")
                
                # Тест 3: Несуществующий пользователь
                print("   Тест 3: Несуществующий пользователь")
                user = await authenticate_user(test_session, "nonexistent", "password")
                if not user:
                    print("   ✅ Аутентификация несуществующего пользователя корректно отклонена")
                else:
                    print("   ❌ Аутентификация несуществующего пользователя не отклонена")
            
            print("\n🎉 Тестирование аутентификации завершено!")
            
        except Exception as e:
            print(f"❌ Ошибка при тестировании аутентификации: {e}")
        finally:
            await session.close()
        break


async def test_concurrent_authentication():
    """Тестирование одновременной аутентификации"""
    print("\n🧪 Тестирование одновременной аутентификации...")
    
    async def auth_task(username: str, password: str, task_id: int):
        """Задача аутентификации"""
        try:
            from database import async_session_maker
            async with async_session_maker() as session:
                user = await authenticate_user(session, username, password)
                print(f"   Задача {task_id}: {'✅' if user else '❌'} {username}")
                return user is not None
        except Exception as e:
            print(f"   Задача {task_id}: ❌ Ошибка - {e}")
            return False
    
    # Создаем несколько одновременных задач аутентификации
    tasks = []
    for i in range(5):
        task = asyncio.create_task(auth_task("admin", "admin123", i + 1))
        tasks.append(task)
    
    # Ждем завершения всех задач
    results = await asyncio.gather(*tasks, return_exceptions=True)
    
    success_count = sum(1 for r in results if r is True)
    print(f"✅ Успешных аутентификаций: {success_count}/5")
    
    if success_count == 5:
        print("🎉 Одновременная аутентификация работает корректно!")
    else:
        print("⚠️ Есть проблемы с одновременной аутентификацией")


async def test_password_verification():
    """Тестирование проверки паролей"""
    print("\n🧪 Тестирование проверки паролей...")
    
    test_passwords = [
        "admin123",
        "password",
        "test123",
        "a" * 100,  # Длинный пароль
        "пароль123",  # Пароль с кириллицей
    ]
    
    for password in test_passwords:
        try:
            print(f"   Тестирование пароля: '{password[:20]}{'...' if len(password) > 20 else ''}'")
            
            # Хешируем пароль
            hashed = get_password_hash(password)
            print(f"   📝 Хеш создан: {hashed[:50]}...")
            
            # Проверяем пароль
            is_valid = verify_password(password, hashed)
            print(f"   ✅ Проверка: {'Успешно' if is_valid else 'Неудачно'}")
            
        except Exception as e:
            print(f"   ❌ Ошибка: {e}")


async def main():
    """Главная функция"""
    print("🔧 Тестирование исправлений аутентификации...")
    print("="*50)
    
    try:
        await test_authentication()
        await test_concurrent_authentication()
        await test_password_verification()
        
        print("\n" + "="*50)
        print("🎉 Все тесты завершены!")
        
    except Exception as e:
        print(f"❌ Критическая ошибка при тестировании: {e}")


if __name__ == "__main__":
    asyncio.run(main())

