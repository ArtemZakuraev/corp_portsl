from datetime import datetime, timedelta
from typing import Optional
from jose import JWTError, jwt
from passlib.context import CryptContext
from fastapi import HTTPException, status, Depends, Request
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from config import settings
from database import get_async_session
from models import User
import logging

# Настройка логирования
logger = logging.getLogger(__name__)

# Хеширование паролей отключено - пароли хранятся в открытом виде
pwd_context = None
logger.info("Хеширование паролей отключено - пароли хранятся в открытом виде")

# Настройка для JWT
security = HTTPBearer()


def verify_password(plain_password: str, stored_password: str) -> bool:
    """Проверка пароля - простое сравнение без хеширования"""
    try:
        # Простое сравнение паролей без хеширования
        return plain_password == stored_password
    except Exception as e:
        logger.error(f"Ошибка при проверке пароля: {e}")
        return False


def get_password_hash(password: str) -> str:
    """Возвращает пароль без хеширования"""
    try:
        # Возвращаем пароль как есть без хеширования
        return password
    except Exception as e:
        logger.error(f"Ошибка при обработке пароля: {e}")
        return password


def create_access_token(data: dict, expires_delta: Optional[timedelta] = None):
    """Создание JWT токена"""
    to_encode = data.copy()
    if expires_delta:
        expire = datetime.utcnow() + expires_delta
    else:
        expire = datetime.utcnow() + timedelta(minutes=settings.access_token_expire_minutes)
    
    to_encode.update({"exp": expire})
    encoded_jwt = jwt.encode(to_encode, settings.secret_key, algorithm=settings.algorithm)
    return encoded_jwt


async def get_user_by_username(session: AsyncSession, username: str) -> Optional[User]:
    """Получение пользователя по имени"""
    try:
        result = await session.execute(select(User).where(User.username == username))
        return result.scalar_one_or_none()
    except Exception as e:
        logger.error(f"Ошибка при получении пользователя {username}: {e}")
        return None


async def get_user_by_email(session: AsyncSession, email: str) -> Optional[User]:
    """Получение пользователя по email"""
    try:
        result = await session.execute(select(User).where(User.email == email))
        return result.scalar_one_or_none()
    except Exception as e:
        logger.error(f"Ошибка при получении пользователя по email {email}: {e}")
        return None


async def authenticate_user(session: AsyncSession, username: str, password: str) -> Optional[User]:
    """Аутентификация пользователя с улучшенной обработкой ошибок"""
    try:
        user = await get_user_by_username(session, username)
        if not user:
            return None
        
        # Проверяем пароль
        if not verify_password(password, user.password_hash):
            return None
        
        return user
    except Exception as e:
        logger.error(f"Ошибка при аутентификации пользователя {username}: {e}")
        return None


async def get_current_user(
    credentials: HTTPAuthorizationCredentials = Depends(security),
    session: AsyncSession = Depends(get_async_session)
) -> User:
    """Получение текущего пользователя из JWT токена"""
    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Could not validate credentials",
        headers={"WWW-Authenticate": "Bearer"},
    )
    
    try:
        token = credentials.credentials
        payload = jwt.decode(token, settings.secret_key, algorithms=[settings.algorithm])
        username: str = payload.get("sub")
        if username is None:
            raise credentials_exception
    except JWTError:
        raise credentials_exception
    
    try:
        user = await get_user_by_username(session, username)
        if user is None:
            raise credentials_exception
        return user
    except Exception as e:
        logger.error(f"Ошибка при получении текущего пользователя: {e}")
        raise credentials_exception


async def get_current_user_optional(
    request: Request,
    session: AsyncSession = Depends(get_async_session)
) -> Optional[User]:
    """Получение текущего пользователя из JWT токена (опционально для веб-роутов)"""
    try:
        # Проверяем заголовок Authorization
        auth_header = request.headers.get("authorization")
        if not auth_header or not auth_header.startswith("Bearer "):
            return None
        
        token = auth_header.split(" ")[1]
        payload = jwt.decode(token, settings.secret_key, algorithms=[settings.algorithm])
        username: str = payload.get("sub")
        if username is None:
            return None
        
        user = await get_user_by_username(session, username)
        return user
    except (JWTError, IndexError) as e:
        logger.debug(f"Ошибка при получении пользователя из токена: {e}")
        return None
    except Exception as e:
        logger.error(f"Ошибка при получении текущего пользователя: {e}")
        return None


async def get_current_admin_user(current_user: User = Depends(get_current_user)) -> User:
    """Получение текущего администратора"""
    if not current_user.is_admin:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Not enough permissions"
        )
    return current_user


def generate_username_from_email(email: str) -> str:
    """Генерация имени пользователя из email"""
    username = email.split('@')[0]
    username = username.replace('.', '')
    return username.lower()

