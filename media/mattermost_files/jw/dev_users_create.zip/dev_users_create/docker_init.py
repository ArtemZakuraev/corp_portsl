#!/usr/bin/env python3
"""
Скрипт инициализации базы данных для Docker
"""

import asyncio
import os
import sys
import logging
from pathlib import Path

# Добавляем текущую директорию в путь
sys.path.insert(0, str(Path(__file__).parent))

# Настройка логирования
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

from database import async_session_maker, engine
from models import Base
from init_db import init_database
from sqlalchemy import text
import time


async def wait_for_database(max_retries=30, retry_delay=2):
    """Ожидание доступности базы данных"""
    print("🔍 Проверка доступности базы данных...")
    
    for attempt in range(max_retries):
        try:
            # Пробуем подключиться к базе данных
            async with engine.begin() as conn:
                result = await conn.execute(text("SELECT 1"))
                print("✅ База данных доступна")
                return True
        except Exception as e:
            print(f"⏳ Попытка {attempt + 1}/{max_retries}: База данных недоступна ({e})")
            if attempt < max_retries - 1:
                print(f"   Ожидание {retry_delay} секунд...")
                await asyncio.sleep(retry_delay)
            else:
                print("❌ База данных недоступна после всех попыток")
                return False
    
    return False


async def test_database_connection():
    """Тестирование подключения к базе данных"""
    print("🧪 Тестирование подключения к базе данных...")
    
    try:
        async with engine.begin() as conn:
            # Простой запрос для проверки подключения
            result = await conn.execute(text("SELECT 1 as test"))
            test_value = result.scalar()
            
            if test_value == 1:
                print("✅ Подключение к базе данных работает")
                return True
            else:
                print("❌ Неожиданный результат теста подключения")
                return False
                
    except Exception as e:
        print(f"❌ Ошибка при тестировании подключения: {e}")
        return False


async def docker_init():
    """Инициализация для Docker контейнера"""
    print("🐳 Инициализация базы данных в Docker...")
    
    try:
        # Ждем доступности базы данных
        if not await wait_for_database():
            print("❌ Не удалось подключиться к базе данных")
            print("⚠️ Продолжаем запуск приложения...")
            return
        
        # Тестируем подключение
        if not await test_database_connection():
            print("❌ Тест подключения к базе данных не прошел")
            print("⚠️ Продолжаем запуск приложения...")
            return
        
        # Создаем таблицы
        print("🔧 Создание таблиц базы данных...")
        async with engine.begin() as conn:
            await conn.run_sync(Base.metadata.create_all)
        print("✅ Таблицы созданы")
        
        # Инициализируем данные
        print("🔧 Инициализация данных...")
        try:
            # Проверяем доступность базы данных перед инициализацией данных
            if not await test_database_connection():
                print("⚠️ База данных недоступна, пропускаем инициализацию данных")
            else:
                await init_database()
                print("✅ Данные инициализированы")
        except Exception as e:
            logger.warning(f"Предупреждение при инициализации данных: {e}")
            print(f"⚠️ Предупреждение при инициализации данных: {e}")
        
        # Исправляем проблемы с базой данных
        print("🔧 Исправление проблем с базой данных...")
        try:
            # Проверяем доступность базы данных перед исправлением проблем
            if not await test_database_connection():
                print("⚠️ База данных недоступна, пропускаем исправление проблем")
            else:
                from fix_database import fix_all_database_issues
                await fix_all_database_issues()
                print("✅ Проблемы с базой данных исправлены")
        except Exception as e:
            logger.warning(f"Предупреждение при исправлении базы данных: {e}")
            print(f"⚠️ Предупреждение при исправлении базы данных: {e}")
        
        # Исправляем проблемы с паролями
        print("🔧 Исправление проблем с паролями...")
        try:
            # Проверяем доступность базы данных перед работой с паролями
            if not await test_database_connection():
                print("⚠️ База данных недоступна, пропускаем исправление паролей")
            else:
                from fix_passwords import fix_user_passwords, test_password_system
                
                # Тестируем систему паролей
                await test_password_system()
                
                # Исправляем пароли пользователей
                await fix_user_passwords()
                
                print("✅ Проблемы с паролями исправлены")
        except Exception as e:
            logger.warning(f"Предупреждение при исправлении паролей: {e}")
            print(f"⚠️ Предупреждение при исправлении паролей: {e}")
        
        print("🎉 База данных готова!")
        
    except Exception as e:
        logger.error(f"Ошибка инициализации: {e}")
        print(f"❌ Ошибка инициализации: {e}")
        # Не завершаем процесс, чтобы контейнер мог продолжить работу
        print("⚠️ Продолжаем запуск приложения...")


if __name__ == "__main__":
    asyncio.run(docker_init())


