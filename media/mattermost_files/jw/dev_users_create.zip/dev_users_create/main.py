"""
Главный модуль приложения FastAPI для системы управления разработчиками.

Этот модуль инициализирует FastAPI приложение, подключает маршруты,
настраивает middleware и управляет жизненным циклом приложения.
"""

from fastapi import FastAPI, Request, Depends, HTTPException
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from fastapi.middleware.cors import CORSMiddleware
from contextlib import asynccontextmanager
import os

# Импортируем компоненты приложения
from database import engine  # Движок базы данных
from models import Base  # Базовый класс для моделей SQLAlchemy
from routes import router as api_router  # API маршруты
from web_routes import router as web_router  # Веб маршруты
from config import settings  # Настройки приложения


@asynccontextmanager
async def lifespan(app: FastAPI):
    """
    Управление жизненным циклом приложения.
    
    Выполняет действия при запуске и остановке приложения:
    - При запуске: создает необходимые директории
    - При остановке: корректно закрывает соединения с БД
    """
    # Действия при запуске приложения (Startup)
    try:
        # Создаем директории для загрузок и шаблонов, если их нет
        os.makedirs("static/uploads", exist_ok=True)
        os.makedirs("templates", exist_ok=True)
        
        # Выводим информацию о создании администратора
        print("💡 Для создания администратора выполните: python init_db.py")
    except Exception as e:
        print(f"⚠️ Ошибка при инициализации: {e}")
        # Продолжаем работу даже если возникла ошибка
    
    yield  # Здесь приложение работает
    
    # Действия при остановке приложения (Shutdown)
    # Корректно закрываем все соединения с базой данных
    await engine.dispose()


# Создаем экземпляр FastAPI приложения
app = FastAPI(
    title=settings.app_name,  # Название приложения
    version=settings.app_version,  # Версия приложения
    description="Система управления разработчиками с интеграцией GitLab, Redmine и Kubernetes",
    lifespan=lifespan  # Функция управления жизненным циклом
)

# Настройка CORS (Cross-Origin Resource Sharing)
# Разрешаем запросы с любых доменов для разработки
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Разрешаем все источники (в продакшене нужно ограничить)
    allow_credentials=True,  # Разрешаем отправку cookies
    allow_methods=["*"],  # Разрешаем все HTTP методы
    allow_headers=["*"],  # Разрешаем все заголовки
)

# Подключаем статические файлы (CSS, JS, изображения)
app.mount("/static", StaticFiles(directory="static"), name="static")
app.mount("/templates", StaticFiles(directory="templates"), name="templates")

# Подключаем маршруты приложения
app.include_router(api_router, prefix="/api", tags=["API"])  # API маршруты с префиксом /api
app.include_router(web_router, tags=["Web"])  # Веб-страницы без префикса




# Middleware для обработки токенов из cookies
@app.middleware("http")
async def auth_middleware(request: Request, call_next):
    """
    Middleware для обработки авторизации через cookies.
    
    Различает запросы к API и веб-страницам:
    - API запросы используют Bearer токены в заголовках
    - Веб-страницы используют токены из cookies
    """
    # Для API запросов используем стандартную авторизацию через заголовки
    if request.url.path.startswith("/api/"):
        response = await call_next(request)
        return response
    
    # Для веб-страниц просто передаем запрос дальше
    # Аутентификация будет обрабатываться непосредственно в роутах
    response = await call_next(request)
    return response


if __name__ == "__main__":
    # Тест исправления ошибки с длинными паролями
    print("Тестирование исправления ошибки с длинными паролями...")
    try:
        from utils import get_password_hash, verify_password
        
        # Создаем пароль длиннее 72 байт
        long_password = "a" * 100  # 100 символов 'a'
        
        print(f"Длина пароля в символах: {len(long_password)}")
        print(f"Длина пароля в байтах: {len(long_password.encode('utf-8'))}")
        
        # Пытаемся хешировать длинный пароль
        hashed = get_password_hash(long_password)
        print(f"Хеширование успешно! Хеш: {hashed[:50]}...")
        
        # Проверяем, что пароль корректно проверяется
        is_valid = verify_password(long_password, hashed)
        print(f"Проверка пароля: {'Успешно' if is_valid else 'Неудачно'}")
        
        print("✅ Тест прошел успешно! Ошибка исправлена.")
        
    except Exception as e:
        print(f"❌ Ошибка в тесте: {e}")
    
    print("\nЗапуск сервера...")
    import uvicorn
    uvicorn.run(
        "main:app",
        host="0.0.0.0",
        port=8000,
        reload=settings.debug
    )
