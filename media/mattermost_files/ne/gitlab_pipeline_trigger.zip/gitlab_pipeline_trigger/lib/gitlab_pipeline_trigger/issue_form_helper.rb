module GitlabPipelineTrigger
  class IssueFormHelper
    # Получает значения полей из задачи
    def self.get_field_values(issue, field_names)
      return {} if issue.nil? || field_names.blank?
      
      field_names = field_names.split(',').map(&:strip) if field_names.is_a?(String)
      
      values = {}
      field_names.each do |field_name|
        value = get_field_value(issue, field_name)
        values[field_name] = value if value.present?
      end
      
      values
    end
    
    # Получает значение конкретного поля из задачи
    def self.get_field_value(issue, field_name)
      # Проверяем стандартные поля
      if issue.respond_to?(field_name)
        value = issue.send(field_name)
        return format_value(value)
      end
      
      # Проверяем пользовательские поля
      custom_field_value = issue.custom_field_values.find { |cfv| cfv.custom_field.name == field_name }
      return format_value(custom_field_value.value) if custom_field_value
      
      nil
    end
    
    # Форматирует значение для передачи в pipeline
    def self.format_value(value)
      case value
      when User
        value.login
      when Project
        value.identifier
      when IssueStatus
        value.name
      when Array
        value.join(',')
      else
        value.to_s
      end
    end
  end
end