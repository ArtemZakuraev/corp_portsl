require 'net/http'
require 'uri'
require 'json'

module GitlabPipelineTrigger
  class GitlabApi
    attr_reader :gitlab_url, :gitlab_token, :project_id
    
    def initialize(gitlab_url, gitlab_token, project_id)
      @gitlab_url = gitlab_url
      @gitlab_token = gitlab_token
      @project_id = project_id
    end
    
    # Проверка соединения с GitLab API
    def test_connection
      uri = URI.parse("#{gitlab_url}/api/v4/projects/#{project_id}")
      response = make_request(uri, :get)
      
      return {
        success: response.code.to_i == 200,
        message: response.message,
        code: response.code.to_i
      }
    end
    
    # Запуск pipeline с переданными переменными
    def trigger_pipeline(ref = 'master', variables = {})
      uri = URI.parse("#{gitlab_url}/api/v4/projects/#{project_id}/trigger/pipeline")
      
      # Преобразуем переменные в формат, ожидаемый GitLab API
      formatted_variables = {}
      variables.each do |key, value|
        formatted_variables["variables[#{key}]"] = value
      end
      
      body = {
        ref: ref,
        token: gitlab_token
      }.merge(formatted_variables)
      
      response = make_request(uri, :post, body)
      
      parsed_data = nil
      begin
        parsed_data = JSON.parse(response.body)
      rescue
        # Ошибка парсинга JSON игнорируется
      end
      
      return {
        success: response.code.to_i == 201,
        message: response.message,
        code: response.code.to_i,
        data: parsed_data
      }
    end
    
    private
    
    def make_request(uri, method, params = nil)
      http = Net::HTTP.new(uri.host, uri.port)
      http.use_ssl = (uri.scheme == 'https')
      
      if method == :get
        request = Net::HTTP::Get.new(uri.path)
        request['PRIVATE-TOKEN'] = gitlab_token
      elsif method == :post
        # Для trigger/pipeline используем правильный формат запроса
        if uri.path.include?('/trigger/pipeline')
          request = Net::HTTP::Post.new(uri.path)
          request.set_form_data(params)
          # Для trigger/pipeline не нужен PRIVATE-TOKEN, используется token в параметрах
        else
          request = Net::HTTP::Post.new(uri.path)
          request.body = params.to_json if params
          request['PRIVATE-TOKEN'] = gitlab_token
          request['Content-Type'] = 'application/json'
        end
      end
      
      begin
        Rails.logger.info "GitLab API Request: #{uri.to_s}, Method: #{method}, Params: #{params.inspect}"
        response = http.request(request)
        Rails.logger.info "GitLab API Response: #{response.code} #{response.message}, Body: #{response.body[0..200]}"
        response
      rescue => e
        Rails.logger.error "GitLab API Error: #{e.message}"
        raise e
      end
    end
  end
end