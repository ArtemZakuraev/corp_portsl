module GitlabPipelineTrigger
  module Hooks
    class IssueHook < Redmine::Hook::ViewListener
      # Хук вызывается при обновлении задачи
      def controller_issues_edit_after_save(context = {})
        issue = context[:issue]
        journal = context[:journal]
        
        # Проверяем, изменился ли статус задачи
        if journal && journal.details.any? { |detail| detail.prop_key == 'status_id' }
          # Получаем информацию о статусе до и после изменения
          status_change = journal.details.find { |detail| detail.prop_key == 'status_id' }
          old_status_id = status_change.old_value.to_i
          new_status_id = status_change.value.to_i
          
          # Получаем названия статусов
          old_status = IssueStatus.find_by(id: old_status_id)&.name || "Неизвестно"
          new_status = IssueStatus.find_by(id: new_status_id)&.name || "Неизвестно"
          
          # Запускаем pipeline при любом изменении статуса
          trigger_gitlab_pipeline(issue, old_status_id, new_status_id, old_status, new_status)
        end
      end
      
      private
      
      # Метод для запуска pipeline в GitLab
      def trigger_gitlab_pipeline(issue, old_status_id, new_status_id, old_status_name, new_status_name)
        require_dependency 'gitlab_pipeline_trigger/gitlab_api'
        require_dependency 'gitlab_pipeline_trigger/issue_form_helper'
        
        # Получаем настройки плагина
        settings = Setting.plugin_gitlab_pipeline_trigger
        gitlab_url = settings['gitlab_url']
        gitlab_token = settings['gitlab_token']
        project_id = settings['project_id']
        branch = settings['branch'].presence || 'master'
        issue_id_variable = settings['issue_id_variable']
        status_variable = settings['status_variable']
        status_value = settings['status_value']
        status_conditions = settings['status_conditions']
        
        # Проверяем условия перехода статусов
        should_trigger = false
        
        if status_conditions.present?
          status_conditions.split('+').each do |condition|
            parts = condition.strip.split('|')
            next if parts.size < 2
            
            from_status = parts[0].strip.to_i
            to_status = parts[1].strip.to_i
            
            # Проверяем, соответствует ли текущее изменение статуса условию
            if (from_status == 0 || from_status == old_status_id) && 
               (to_status == 0 || to_status == new_status_id)
              should_trigger = true
              break
            end
          end
        else
          # Если условия не заданы, запускаем pipeline при любом изменении статуса
          should_trigger = true
        end
        
        # Если условия не выполнены, не запускаем pipeline
        return unless should_trigger
        
        # Создаем экземпляр GitLab API
        gitlab_api = GitlabPipelineTrigger::GitlabApi.new(gitlab_url, gitlab_token, project_id)
        
        # Инициализируем переменные для pipeline
        variables = {}
        
        # Добавляем информацию о задаче с использованием настраиваемых имен переменных
        if issue_id_variable.present?
          variables[issue_id_variable] = issue.id.to_s
        end
        
        # Добавляем информацию о статусе с использованием настраиваемого имени переменной
        if status_variable.present?
          # Если задано настраиваемое значение статуса, используем его вместо имени статуса
          if status_value.present?
            variables[status_variable] = status_value
          else
            variables[status_variable] = new_status_name
          end
          # Добавляем числовое значение статуса с суффиксом _ID
          variables["#{status_variable}_ID"] = new_status_id.to_s
        end
        
        # Запускаем pipeline с указанной веткой
        begin
          result = gitlab_api.trigger_pipeline(branch, variables)
          
          if result[:success]
            Rails.logger.info "GitLab Pipeline Trigger: Pipeline запущен для задачи ##{issue.id}. Изменение статуса: #{old_status_name} -> #{new_status_name}. Ответ: #{result[:code]} #{result[:message]}"
          else
            Rails.logger.error "GitLab Pipeline Trigger: Не удалось запустить pipeline для задачи ##{issue.id}. Ответ: #{result[:code]} #{result[:message]}"
          end
        rescue => e
          Rails.logger.error "GitLab Pipeline Trigger: Ошибка запуска pipeline для задачи ##{issue.id}. Ошибка: #{e.message}"
        end
      end
    end
  end
end