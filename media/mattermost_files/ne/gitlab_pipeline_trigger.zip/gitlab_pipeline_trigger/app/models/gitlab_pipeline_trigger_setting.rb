class GitlabPipelineTriggerSetting < ActiveRecord::Base
  include Redmine::SafeAttributes
  
  safe_attributes 'gitlab_url',
                  'gitlab_token',
                  'project_id',
                  'branch',
                  'issue_id_variable',
                  'status_variable',
                  'status_value',
                  'status_conditions'
  
  validates_presence_of :gitlab_url, :gitlab_token, :project_id
  validates_format_of :gitlab_url, with: URI::regexp(%w(http https))
  
  # Преобразует строку с условиями статусов в массив хешей
  def status_conditions_array
    return [] if status_conditions.blank?
    
    conditions = []
    status_conditions.split('+').each do |condition|
      parts = condition.strip.split('|')
      next if parts.size < 2
      
      conditions << {
        from_status_id: parts[0].strip.to_i,
        to_status_id: parts[1].strip.to_i
      }
    end
    
    conditions
  end
  
  # Получает значение настройки
  def self.get_setting(key)
    Setting.plugin_gitlab_pipeline_trigger[key]
  end
end