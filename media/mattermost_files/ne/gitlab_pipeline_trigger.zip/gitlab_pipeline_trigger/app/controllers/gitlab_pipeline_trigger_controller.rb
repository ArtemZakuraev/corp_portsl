class GitlabPipelineTriggerController < ApplicationController
  layout 'admin'
  before_action :require_admin
  
  def index
    @settings = Setting.plugin_gitlab_pipeline_trigger
    @statuses = IssueStatus.all
  end
  
  def update
    settings = Setting.plugin_gitlab_pipeline_trigger
    settings.merge!(params[:settings] || {})
    Setting.plugin_gitlab_pipeline_trigger = settings
    
    flash[:notice] = l(:notice_successful_update)
    redirect_to action: 'index'
  end
  
  def test_connection
    settings = Setting.plugin_gitlab_pipeline_trigger
    gitlab_url = settings['gitlab_url']
    gitlab_token = settings['gitlab_token']
    project_id = settings['project_id']
    
    begin
      require_dependency 'gitlab_pipeline_trigger/gitlab_api'
      gitlab_api = GitlabPipelineTrigger::GitlabApi.new(gitlab_url, gitlab_token, project_id)
      result = gitlab_api.test_connection
      
      if result[:success]
        flash[:notice] = l(:notice_connection_successful)
      else
        flash[:error] = l(:error_connection_failed, message: result[:message])
      end
    rescue => e
      flash[:error] = l(:error_connection_failed, message: e.message)
    end
    
    redirect_to action: 'index'
  end
end