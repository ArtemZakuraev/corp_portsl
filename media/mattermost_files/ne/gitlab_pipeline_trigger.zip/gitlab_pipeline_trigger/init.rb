require 'redmine'

Redmine::Plugin.register :gitlab_pipeline_trigger do
  name 'GitLab Pipeline Trigger'
  author 'a.zakuraev'
  description 'Запуск GitLab pipeline при изменении статуса задачи'
  version '0.1.0'
  url 'https://github.com/your-username/gitlab_pipeline_trigger'
  author_url 'https://github.com/your-username'
  
  # Добавляем настройки плагина
  settings default: {
    'gitlab_url' => 'https://gitlab.com',
    'gitlab_token' => '',
    'project_id' => '',
    'branch' => 'master',
    'issue_id_variable' => '',
    'status_variable' => '',
    'status_value' => '',
    'status_conditions' => ''
  }, partial: 'settings/gitlab_pipeline_trigger_settings'
  
  # Добавляем разрешения для доступа к настройкам плагина
  permission :manage_gitlab_pipeline_trigger, { gitlab_pipeline_trigger: [:index] }, require: :admin
  
  # Добавляем пункт меню в раздел администрирования
  menu :admin_menu, :gitlab_pipeline_trigger, 
    { controller: 'gitlab_pipeline_trigger', action: 'index' },
    caption: :label_gitlab_pipeline_trigger
end

# Регистрируем хук для отслеживания изменения статуса задачи
require_dependency 'gitlab_pipeline_trigger/hooks/issue_hook'