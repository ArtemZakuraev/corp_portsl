# Plugin's routes
# See: http://guides.rubyonrails.org/routing.html

Rails.application.routes.draw do
  scope '/admin' do
    get 'gitlab_pipeline_trigger', to: 'gitlab_pipeline_trigger#index'
    post 'gitlab_pipeline_trigger/update', to: 'gitlab_pipeline_trigger#update'
    get 'gitlab_pipeline_trigger/test_connection', to: 'gitlab_pipeline_trigger#test_connection'
  end
end