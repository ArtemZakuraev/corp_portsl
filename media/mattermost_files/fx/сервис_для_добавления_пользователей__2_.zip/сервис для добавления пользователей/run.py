#!/usr/bin/env python3
"""
Скрипт запуска Developer Management System
"""

import uvicorn
import os
import sys
from pathlib import Path

# Добавляем текущую директорию в путь
sys.path.insert(0, str(Path(__file__).parent))

try:
    from config import settings
except ImportError as e:
    print(f"❌ Ошибка импорта конфигурации: {e}")
    print("💡 Убедитесь, что все зависимости установлены:")
    print("   pip install -r requirements.txt")
    sys.exit(1)

if __name__ == "__main__":
    print("🚀 Запуск Developer Management System...")
    print(f"📱 Приложение: {settings.app_name}")
    print(f"🔧 Версия: {settings.app_version}")
    print(f"🌐 Режим отладки: {'Включен' if settings.debug else 'Выключен'}")
    print(f"🗄️ База данных: {settings.database_url}")
    print(f"🐍 Python версия: {sys.version}")
    print("=" * 50)
    
    try:
        uvicorn.run(
            "main:app",
            host="0.0.0.0",
            port=8000,
            reload=settings.debug,
            log_level="info" if settings.debug else "warning"
        )
    except KeyboardInterrupt:
        print("\n👋 Приложение остановлено пользователем")
    except Exception as e:
        print(f"❌ Ошибка запуска: {e}")
        print("💡 Проверьте логи выше для подробностей")
