#!/usr/bin/env python3
"""
Скрипт для наполнения базы данных начальными данными
"""

import asyncio
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from database import async_session_maker
from models import User, Project, Settings
from utils import get_password_hash


async def init_database():
    """Инициализация базы данных начальными данными"""
    
    async with async_session_maker() as session:
        # Создаем администратора по умолчанию
        admin_user = await session.execute(
            select(User).where(User.username == "admin")
        )
        if not admin_user.scalar_one_or_none():
            admin = User(
                username="admin",
                email="admin@example.com",
                password_hash=get_password_hash("admin123"),
                is_admin=True
            )
            session.add(admin)
            print("✓ Создан администратор: admin / admin123")
        
        # Создаем проекты по умолчанию
        projects_data = [
            {"name": "АС ФЗД", "gitlab_project_id": "1", "description": "Автоматизированная система ФЗД"},
            {"name": "АС КУБ", "gitlab_project_id": "2", "description": "Автоматизированная система КУБ"},
            {"name": "АС ЕУС", "gitlab_project_id": "3", "description": "Автоматизированная система ЕУС"},
            {"name": "АС ЕКК", "gitlab_project_id": "4", "description": "Автоматизированная система ЕКК"},
            {"name": "АС ПШ", "gitlab_project_id": "5", "description": "Автоматизированная система ПШ"},
            {"name": "АС УП", "gitlab_project_id": "6", "description": "Автоматизированная система УП"},
        ]
        
        for project_data in projects_data:
            existing_project = await session.execute(
                select(Project).where(Project.name == project_data["name"])
            )
            if not existing_project.scalar_one_or_none():
                project = Project(**project_data)
                session.add(project)
                print(f"✓ Создан проект: {project_data['name']}")
        
        # Создаем настройки по умолчанию
        settings_obj = await session.execute(
            select(Settings).order_by(Settings.id.desc()).limit(1)
        )
        if not settings_obj.scalar_one_or_none():
            default_settings = Settings(
                gitlab_url="https://gitlab.com",
                redmine_url="https://redmine.example.com",
                kubernetes_api_url="https://kubernetes.example.com",
                project_id="1"
            )
            session.add(default_settings)
            print("✓ Созданы настройки по умолчанию")
        
        await session.commit()
        print("\n🎉 База данных успешно инициализирована!")


if __name__ == "__main__":
    asyncio.run(init_database())
