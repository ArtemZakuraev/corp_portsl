#!/usr/bin/env python3
"""
Скрипт запуска Developer Management System для Python 3.14
"""

import sys
import subprocess
import os
from pathlib import Path

def check_python_version():
    """Проверка версии Python"""
    if sys.version_info < (3, 8):
        print("❌ ОШИБКА: Требуется Python 3.8 или выше")
        print(f"Текущая версия: {sys.version}")
        return False
    
    print(f"✅ Python версия: {sys.version}")
    return True

def install_dependencies():
    """Установка зависимостей с обновлением pip"""
    print("📦 Обновление pip...")
    subprocess.run([sys.executable, "-m", "pip", "install", "--upgrade", "pip"], check=True)
    
    print("📦 Установка зависимостей...")
    subprocess.run([sys.executable, "-m", "pip", "install", "-r", "requirements.txt"], check=True)

def create_directories():
    """Создание необходимых директорий"""
    directories = ["static/uploads", "templates", "alembic/versions"]
    for directory in directories:
        Path(directory).mkdir(parents=True, exist_ok=True)
        print(f"✅ Создана директория: {directory}")

def init_database():
    """Инициализация базы данных"""
    print("🗄️ Инициализация базы данных...")
    try:
        subprocess.run([sys.executable, "init_db.py"], check=True)
        print("✅ База данных инициализирована")
    except subprocess.CalledProcessError as e:
        print(f"❌ Ошибка инициализации БД: {e}")
        return False
    return True

def run_application():
    """Запуск приложения"""
    print("🚀 Запуск приложения...")
    print("=" * 50)
    print("🌐 Приложение будет доступно по адресу:")
    print("   http://localhost:8000")
    print()
    print("👤 Тестовый аккаунт:")
    print("   Логин: admin")
    print("   Пароль: admin123")
    print()
    print("📚 Документация API:")
    print("   Swagger UI: http://localhost:8000/docs")
    print("   ReDoc: http://localhost:8000/redoc")
    print("=" * 50)
    print()
    
    try:
        subprocess.run([sys.executable, "run.py"], check=True)
    except KeyboardInterrupt:
        print("\n👋 Приложение остановлено пользователем")
    except subprocess.CalledProcessError as e:
        print(f"❌ Ошибка запуска приложения: {e}")

def main():
    """Основная функция"""
    print("🚀 Developer Management System")
    print("=" * 50)
    
    # Проверка версии Python
    if not check_python_version():
        return
    
    # Создание директорий
    create_directories()
    
    # Установка зависимостей
    try:
        install_dependencies()
    except subprocess.CalledProcessError as e:
        print(f"❌ Ошибка установки зависимостей: {e}")
        print("💡 Попробуйте запустить от имени администратора")
        return
    
    # Инициализация базы данных
    if not init_database():
        return
    
    # Запуск приложения
    run_application()

if __name__ == "__main__":
    main()
