# 🐍 ИНСТРУКЦИЯ ДЛЯ PYTHON 3.14

## Решение проблем совместимости

Если у вас установлен Python 3.14 и возникают ошибки с модулем `typing`, следуйте этим инструкциям:

---

## 🔧 Быстрое решение

### Вариант 1: Используйте специальный скрипт

```bash
python start_python314.py
```

Этот скрипт автоматически:
- Проверит версию Python
- Обновит pip до последней версии
- Установит совместимые версии библиотек
- Создаст необходимые директории
- Инициализирует базу данных
- Запустит приложение

---

## 🛠 Ручное решение

### 1. Обновите pip

```bash
python -m pip install --upgrade pip
```

### 2. Установите зависимости с гибкими версиями

```bash
pip install -r requirements.txt
```

### 3. Если возникают ошибки, установите по одной:

```bash
pip install fastapi>=0.104.1
pip install uvicorn[standard]>=0.24.0
pip install sqlalchemy[asyncio]>=2.0.23
pip install aiosqlite>=0.19.0
pip install python-jose[cryptography]>=3.3.0
pip install passlib[bcrypt]>=1.7.4
pip install python-gitlab>=4.2.0
pip install python-redmine>=2.3.0
pip install aiohttp>=3.9.1
pip install alembic>=1.13.1
pip install itsdangerous>=2.1.2
pip install email-validator>=2.1.0
pip install pydantic-settings>=2.1.0
pip install python-multipart>=0.0.6
pip install aiofiles>=23.2.1
pip install Pillow>=10.0.0
pip install jinja2>=3.1.2
pip install python-dotenv>=1.0.0
```

---

## 🔍 Диагностика проблем

### Проверьте версию Python:

```bash
python --version
```

### Проверьте установленные пакеты:

```bash
pip list
```

### Проверьте совместимость:

```bash
python -c "import typing; print('typing OK')"
```

---

## ⚠️ Известные проблемы Python 3.14

1. **Модуль typing:** Некоторые библиотеки могут быть несовместимы
2. **Pydantic:** Может требовать обновления до последней версии
3. **SQLAlchemy:** Рекомендуется использовать версию 2.0+

---

## 🚀 Альтернативные решения

### Вариант 1: Используйте Python 3.12 (рекомендуется)

```bash
# Скачайте Python 3.12 с python.org
# Создайте новое виртуальное окружение
python3.12 -m venv venv312
venv312\Scripts\activate  # Windows
source venv312/bin/activate  # Linux/Mac
pip install -r requirements.txt
python run.py
```

### Вариант 2: Используйте Docker

```bash
# Создайте Dockerfile
cat > Dockerfile << EOF
FROM python:3.12-slim

WORKDIR /app
COPY requirements.txt .
RUN pip install -r requirements.txt

COPY . .
EXPOSE 8000

CMD ["python", "run.py"]
EOF

# Соберите и запустите
docker build -t dev-management .
docker run -p 8000:8000 dev-management
```

---

## 📞 Поддержка

Если проблемы продолжаются:

1. **Проверьте логи ошибок** - они покажут точную причину
2. **Обновите все библиотеки** до последних версий
3. **Используйте Python 3.12** для максимальной совместимости
4. **Обратитесь к автору:** a.zakuraev@123.com

---

## ✅ Проверка работоспособности

После успешной установки:

1. Запустите приложение: `python run.py`
2. Откройте браузер: http://localhost:8000
3. Войдите как admin/admin123
4. Проверьте все функции

---

**Удачного использования!** 🚀
