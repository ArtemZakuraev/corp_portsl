#!/bin/bash

echo "========================================"
echo "   Developer Management System"
echo "========================================"
echo

# Проверяем наличие Python
if ! command -v python3 &> /dev/null; then
    echo "ОШИБКА: Python3 не найден!"
    echo "Установите Python 3.8+ с https://python.org"
    exit 1
fi

# Проверяем наличие виртуального окружения
if [ ! -d "venv" ]; then
    echo "Создание виртуального окружения..."
    python3 -m venv venv
    if [ $? -ne 0 ]; then
        echo "ОШИБКА: Не удалось создать виртуальное окружение!"
        exit 1
    fi
fi

# Активируем виртуальное окружение
echo "Активация виртуального окружения..."
source venv/bin/activate

# Устанавливаем зависимости
echo "Установка зависимостей..."
pip install -r requirements.txt
if [ $? -ne 0 ]; then
    echo "ОШИБКА: Не удалось установить зависимости!"
    exit 1
fi

# Инициализируем базу данных
echo "Инициализация базы данных..."
python init_db.py
if [ $? -ne 0 ]; then
    echo "ОШИБКА: Не удалось инициализировать базу данных!"
    exit 1
fi

# Запускаем приложение
echo
echo "========================================"
echo "   Запуск приложения..."
echo "========================================"
echo
echo "Приложение будет доступно по адресу:"
echo "http://localhost:8000"
echo
echo "Тестовый аккаунт:"
echo "Логин: admin"
echo "Пароль: admin123"
echo
echo "Для остановки нажмите Ctrl+C"
echo "========================================"
echo

python run.py
