#!/usr/bin/env python3
"""
Скрипт инициализации базы данных для Docker
"""

import asyncio
import os
import sys
from pathlib import Path

# Добавляем текущую директорию в путь
sys.path.insert(0, str(Path(__file__).parent))

from database import async_session_maker, engine
from models import Base
from init_db import init_database


async def docker_init():
    """Инициализация для Docker контейнера"""
    print("🐳 Инициализация базы данных в Docker...")
    
    try:
        # Создаем таблицы
        async with engine.begin() as conn:
            await conn.run_sync(Base.metadata.create_all)
        print("✅ Таблицы созданы")
        
        # Инициализируем данные
        await init_database()
        print("✅ Данные инициализированы")
        
        print("🎉 База данных готова!")
        
    except Exception as e:
        print(f"❌ Ошибка инициализации: {e}")
        sys.exit(1)


if __name__ == "__main__":
    asyncio.run(docker_init())
