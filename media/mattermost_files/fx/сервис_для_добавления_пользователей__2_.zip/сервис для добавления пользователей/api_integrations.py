import aiohttp
import gitlab
import redmine
from typing import Optional, Dict, Any, List
import logging

logger = logging.getLogger(__name__)


class GitLabAPI:
    def __init__(self, url: str, token: str):
        self.url = url
        self.token = token
        self.gl = gitlab.Gitlab(url, private_token=token)
    
    async def create_user(self, user_data: Dict[str, Any]) -> Optional[int]:
        """Создание пользователя в GitLab"""
        try:
            username = user_data['username']
            email = user_data['email']
            name = f"{user_data['first_name']} {user_data['last_name']}"
            
            # Проверяем, существует ли пользователь
            try:
                existing_user = self.gl.users.list(username=username)
                if existing_user:
                    logger.info(f"User {username} already exists in GitLab")
                    return existing_user[0].id
            except:
                pass
            
            # Создаем нового пользователя
            user = self.gl.users.create({
                'email': email,
                'username': username,
                'name': name,
                'password': 'TempPassword123!',  # Временный пароль
                'skip_confirmation': True
            })
            
            logger.info(f"Created GitLab user {username} with ID {user.id}")
            return user.id
            
        except Exception as e:
            logger.error(f"Error creating GitLab user: {e}")
            return None
    
    async def add_user_to_project(self, user_id: int, project_id: str, access_level: int = 30) -> bool:
        """Добавление пользователя к проекту в GitLab"""
        try:
            project = self.gl.projects.get(project_id)
            member = project.members.create({
                'user_id': user_id,
                'access_level': access_level  # 30 = Developer
            })
            logger.info(f"Added user {user_id} to project {project_id}")
            return True
        except Exception as e:
            logger.error(f"Error adding user to GitLab project: {e}")
            return False


class RedmineAPI:
    def __init__(self, url: str, token: str):
        self.url = url
        self.token = token
        self.redmine = redmine.Redmine(url, key=token)
    
    async def create_user(self, user_data: Dict[str, Any]) -> Optional[int]:
        """Создание пользователя в Redmine"""
        try:
            username = user_data['username']
            email = user_data['email']
            first_name = user_data['first_name']
            last_name = user_data['last_name']
            
            # Проверяем, существует ли пользователь
            try:
                existing_user = self.redmine.user.filter(name=username)
                if existing_user:
                    logger.info(f"User {username} already exists in Redmine")
                    return existing_user[0].id
            except:
                pass
            
            # Создаем нового пользователя
            user = self.redmine.user.create(
                login=username,
                firstname=first_name,
                lastname=last_name,
                mail=email,
                password='TempPassword123!',  # Временный пароль
                status=1,  # Active
                mail_notification='only_my_events'
            )
            
            logger.info(f"Created Redmine user {username} with ID {user.id}")
            return user.id
            
        except Exception as e:
            logger.error(f"Error creating Redmine user: {e}")
            return None
    
    async def add_user_to_project(self, user_id: int, project_id: str, role_id: int = 4) -> bool:
        """Добавление пользователя к проекту в Redmine"""
        try:
            member = self.redmine.project_membership.create(
                project_id=project_id,
                user_id=user_id,
                role_ids=[role_id]  # 4 = Developer role
            )
            logger.info(f"Added user {user_id} to project {project_id}")
            return True
        except Exception as e:
            logger.error(f"Error adding user to Redmine project: {e}")
            return False


class KubernetesAPI:
    def __init__(self, api_url: str, token: str):
        self.api_url = api_url
        self.token = token
        self.headers = {
            'Authorization': f'Bearer {token}',
            'Content-Type': 'application/json'
        }
    
    async def create_namespace(self, namespace: str) -> bool:
        """Создание namespace в Kubernetes"""
        try:
            async with aiohttp.ClientSession() as session:
                url = f"{self.api_url}/api/v1/namespaces"
                data = {
                    "apiVersion": "v1",
                    "kind": "Namespace",
                    "metadata": {
                        "name": namespace
                    }
                }
                
                async with session.post(url, json=data, headers=self.headers) as response:
                    if response.status in [200, 201]:
                        logger.info(f"Created Kubernetes namespace {namespace}")
                        return True
                    else:
                        logger.error(f"Failed to create namespace: {response.status}")
                        return False
                        
        except Exception as e:
            logger.error(f"Error creating Kubernetes namespace: {e}")
            return False
    
    async def create_service_account(self, namespace: str, name: str) -> bool:
        """Создание ServiceAccount в Kubernetes"""
        try:
            async with aiohttp.ClientSession() as session:
                url = f"{self.api_url}/api/v1/namespaces/{namespace}/serviceaccounts"
                data = {
                    "apiVersion": "v1",
                    "kind": "ServiceAccount",
                    "metadata": {
                        "name": name,
                        "namespace": namespace
                    }
                }
                
                async with session.post(url, json=data, headers=self.headers) as response:
                    if response.status in [200, 201]:
                        logger.info(f"Created ServiceAccount {name} in namespace {namespace}")
                        return True
                    else:
                        logger.error(f"Failed to create ServiceAccount: {response.status}")
                        return False
                        
        except Exception as e:
            logger.error(f"Error creating Kubernetes ServiceAccount: {e}")
            return False
