# Developer Management System

Современная система управления разработчиками с интеграцией в GitLab, Redmine и Kubernetes.

## 🚀 Особенности

- **Авторизация пользователей** с JWT токенами
- **Интеграция с GitLab** - автоматическое создание пользователей и назначение к проектам
- **Интеграция с Redmine** - управление задачами и ролями
- **Интеграция с Kubernetes** - создание namespace и service accounts
- **Современный интерфейс** в стиле киберпанк с Bootstrap 5
- **Асинхронная архитектура** на FastAPI и SQLAlchemy
- **Гибкая конфигурация** через .env файлы

## 📋 Требования

- Python 3.8+
- SQLite (по умолчанию) или PostgreSQL
- GitLab API токен (опционально)
- Redmine API токен (опционально)
- Kubernetes API токен (опционально)

## 🛠 Установка

1. **Клонируйте репозиторий:**
```bash
git clone <repository-url>
cd developer-management-system
```

2. **Создайте виртуальное окружение:**
```bash
python -m venv venv
source venv/bin/activate  # Linux/Mac
# или
venv\Scripts\activate  # Windows
```

3. **Установите зависимости:**
```bash
pip install -r requirements.txt
```

4. **Настройте конфигурацию:**
```bash
cp config.env .env
# Отредактируйте .env файл под ваши нужды
```

5. **Инициализируйте базу данных:**
```bash
python init_db.py
```

6. **Запустите приложение:**
```bash
python main.py
```

Приложение будет доступно по адресу: http://localhost:8000

## 🔧 Конфигурация

### Основные настройки (.env файл):

```env
# Конфигурация приложения
SECRET_KEY=your-secret-key-change-this-in-production
ALGORITHM=HS256
ACCESS_TOKEN_EXPIRE_MINUTES=30

# База данных
DATABASE_URL=sqlite+aiosqlite:///./app.db
# Для PostgreSQL:
# DATABASE_URL=postgresql+asyncpg://user:password@localhost/dbname

# Настройки приложения
APP_NAME=Developer Management System
APP_VERSION=1.0.0
DEBUG=True

# Пути для загрузки файлов
UPLOAD_DIR=static/uploads
MAX_FILE_SIZE=5242880  # 5MB
```

### Интеграции:

Настройки интеграций можно изменить через веб-интерфейс в разделе "Настройки" (требуются права администратора).

## 👤 Тестовый аккаунт

- **Логин:** admin
- **Пароль:** admin123

## 📁 Структура проекта

```
├── alembic/                 # Миграции базы данных
├── static/                  # Статические файлы
│   └── uploads/             # Загруженные файлы
├── templates/              # HTML шаблоны
├── alembic.ini             # Конфигурация Alembic
├── config.py               # Настройки приложения
├── config.env              # Пример конфигурации
├── database.py             # Подключение к БД
├── init_db.py              # Скрипт инициализации БД
├── main.py                 # Основной файл приложения
├── models.py               # Модели SQLAlchemy
├── routes.py               # API роуты
├── schemas.py              # Pydantic схемы
├── utils.py                # Утилиты (JWT, хеширование)
├── web_routes.py           # Веб роуты
├── api_integrations.py     # Интеграции с внешними API
└── requirements.txt        # Зависимости Python
```

## 🔌 API Эндпоинты

### Аутентификация
- `POST /api/auth/register` - Регистрация пользователя
- `POST /api/auth/login` - Вход в систему

### Настройки
- `GET /api/settings` - Получение настроек
- `POST /api/settings` - Обновление настроек
- `POST /api/settings/upload-logo` - Загрузка логотипа
- `POST /api/settings/upload-favicon` - Загрузка favicon

### Разработчики
- `GET /api/developers` - Список разработчиков
- `POST /api/developers/add` - Добавление разработчика

### Проекты
- `GET /api/projects` - Список проектов
- `POST /api/projects` - Создание проекта

## 🌐 Веб-интерфейс

- `/` - Главная страница (dashboard)
- `/login` - Страница входа
- `/register` - Страница регистрации
- `/settings` - Настройки системы (только для админов)
- `/developers` - Список разработчиков
- `/developers/add` - Добавление разработчика (только для админов)
- `/about` - О программе

## 🔐 Безопасность

- JWT токены для авторизации
- Хеширование паролей с bcrypt
- Валидация входных данных с Pydantic
- Защита от CSRF атак
- Ограничение размера загружаемых файлов

## 🎨 Дизайн

Интерфейс выполнен в стиле киберпанк с:
- Неоновыми акцентами (зеленый, розовый, голубой)
- Темной цветовой схемой
- Анимациями и эффектами
- Адаптивным дизайном
- Современными UI компонентами

## 🚀 Развертывание

### Docker (рекомендуется)

#### Быстрый запуск:
```bash
# Windows
docker-start.bat

# Linux/Mac
chmod +x docker-start.sh
./docker-start.sh
```

#### Ручной запуск:
```bash
# Разработка (SQLite)
docker-compose -f docker-compose.dev.yml up --build

# Продакшен (PostgreSQL + Redis)
docker-compose up --build

# Простой Docker
docker build -t dev-management .
docker run -p 8000:8000 dev-management
```

### Локальная разработка
```bash
python run.py
```

### Системные требования

- **Минимум:** 512MB RAM, 1 CPU core
- **Рекомендуется:** 1GB RAM, 2 CPU cores
- **Диск:** 100MB для приложения + место для БД

## 🐛 Устранение неполадок

### Проблемы с базой данных
```bash
# Пересоздайте базу данных
rm app.db
python init_db.py
```

### Проблемы с зависимостями
```bash
# Переустановите зависимости
pip install --upgrade -r requirements.txt
```

### Проблемы с миграциями
```bash
# Примените миграции
alembic upgrade head
```

## 📝 Логи

Логи приложения выводятся в консоль. Для продакшена рекомендуется настроить логирование в файлы.

## 🤝 Поддержка

По всем вопросам обращайтесь к автору: **a.zakuraev@123.com**

## 📄 Лицензия

Этот проект разработан для внутреннего использования.

---

**Автор:** a.zakuraev@123.com  
**Версия:** 1.0.0  
**Дата:** 2024
