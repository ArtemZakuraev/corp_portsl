#!/bin/bash

echo "========================================"
echo "   Developer Management System"
echo "   Docker Quick Start"
echo "========================================"
echo

# Проверяем наличие Docker
if ! command -v docker &> /dev/null; then
    echo "ОШИБКА: Docker не найден!"
    echo "Установите Docker с https://docker.com"
    exit 1
fi

echo "✅ Docker найден"
echo

echo "Выберите режим запуска:"
echo "1. Разработка (SQLite)"
echo "2. Продакшен (PostgreSQL + Redis)"
echo "3. Только сборка образа"
echo

read -p "Введите номер (1-3): " choice

case $choice in
    1)
        echo
        echo "🚀 Запуск в режиме разработки..."
        docker-compose -f docker-compose.dev.yml up --build
        ;;
    2)
        echo
        echo "🚀 Запуск в продакшен режиме..."
        docker-compose up --build
        ;;
    3)
        echo
        echo "🔨 Сборка образа..."
        docker build -t dev-management .
        echo "✅ Образ собран: dev-management"
        ;;
    *)
        echo "❌ Неверный выбор"
        exit 1
        ;;
esac

echo
echo "========================================"
echo "   Приложение доступно по адресу:"
echo "   http://localhost:8000"
echo
echo "   Тестовый аккаунт:"
echo "   Логин: admin"
echo "   Пароль: admin123"
echo "========================================"
