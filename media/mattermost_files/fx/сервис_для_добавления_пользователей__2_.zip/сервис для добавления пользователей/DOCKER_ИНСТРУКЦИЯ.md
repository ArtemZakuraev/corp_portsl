# 🐳 DOCKER ИНСТРУКЦИЯ

## Developer Management System в Docker

Полная инструкция по запуску проекта в Docker контейнерах.

---

## 🚀 Быстрый старт

### Вариант 1: Простой запуск (SQLite)

```bash
# Сборка и запуск
docker-compose -f docker-compose.dev.yml up --build

# Или в фоновом режиме
docker-compose -f docker-compose.dev.yml up -d --build
```

### Вариант 2: Полный запуск (PostgreSQL + Redis)

```bash
# Сборка и запуск всех сервисов
docker-compose up --build

# Или в фоновом режиме
docker-compose up -d --build
```

---

## 📋 Доступ к приложению

После запуска откройте браузер:

- **Приложение:** http://localhost:8000
- **API документация:** http://localhost:8000/docs
- **ReDoc:** http://localhost:8000/redoc

### Тестовый аккаунт:
- **Логин:** admin
- **Пароль:** admin123

---

## 🛠 Команды Docker

### Сборка образа

```bash
# Сборка образа
docker build -t dev-management .

# Сборка без кеша
docker build --no-cache -t dev-management .
```

### Запуск контейнера

```bash
# Запуск с SQLite
docker run -p 8000:8000 dev-management

# Запуск с переменными окружения
docker run -p 8000:8000 \
  -e DATABASE_URL="postgresql+asyncpg://user:pass@host:5432/db" \
  -e SECRET_KEY="your-secret-key" \
  dev-management
```

### Управление контейнерами

```bash
# Просмотр запущенных контейнеров
docker ps

# Остановка контейнеров
docker-compose down

# Остановка с удалением volumes
docker-compose down -v

# Просмотр логов
docker-compose logs -f app

# Вход в контейнер
docker exec -it <container_id> bash
```

---

## ⚙️ Конфигурация

### Переменные окружения

#### Основные настройки:
```env
DATABASE_URL=postgresql+asyncpg://postgres:password@db:5432/dev_management
SECRET_KEY=your-secret-key-change-this-in-production
DEBUG=False
APP_NAME=Developer Management System
APP_VERSION=1.0.0
```

#### Для разработки:
```env
DATABASE_URL=sqlite+aiosqlite:///./app.db
SECRET_KEY=dev-secret-key
DEBUG=True
```

### Порты:
- **8000** - Основное приложение
- **5432** - PostgreSQL (если используется)
- **6379** - Redis (если используется)

---

## 🗄️ База данных

### SQLite (по умолчанию для разработки)
- Файл базы данных создается автоматически
- Данные сохраняются в volume контейнера
- Подходит для разработки и тестирования

### PostgreSQL (для продакшена)
- Отдельный контейнер с PostgreSQL 15
- Данные сохраняются в Docker volume
- Более надежно для продакшена

### Инициализация БД
База данных инициализируется автоматически при первом запуске:
- Создаются все таблицы
- Добавляется администратор (admin/admin123)
- Создаются проекты по умолчанию
- Настраиваются базовые параметры

---

## 📁 Volumes

### Для разработки:
```yaml
volumes:
  - .:/app          # Монтирование исходного кода
  - /app/venv        # Исключение виртуального окружения
```

### Для продакшена:
```yaml
volumes:
  - ./static/uploads:/app/static/uploads  # Загруженные файлы
  - postgres_data:/var/lib/postgresql/data  # Данные PostgreSQL
```

---

## 🔧 Разработка с Docker

### Горячая перезагрузка
```bash
# Запуск с монтированием исходного кода
docker-compose -f docker-compose.dev.yml up --build
```

### Отладка
```bash
# Просмотр логов
docker-compose logs -f app

# Вход в контейнер для отладки
docker exec -it <container_id> bash

# Установка дополнительных пакетов
docker exec -it <container_id> pip install <package>
```

### Тестирование
```bash
# Запуск тестов в контейнере
docker exec -it <container_id> python -m pytest

# Проверка базы данных
docker exec -it <container_id> python -c "from database import engine; print('DB OK')"
```

---

## 🚀 Продакшен

### Оптимизированный Dockerfile

```dockerfile
# Многоэтапная сборка для уменьшения размера
FROM python:3.12-slim as builder

WORKDIR /app
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

FROM python:3.12-slim
WORKDIR /app
COPY --from=builder /usr/local/lib/python3.12/site-packages /usr/local/lib/python3.12/site-packages
COPY --from=builder /usr/local/bin /usr/local/bin
COPY . .

RUN useradd --create-home --shell /bin/bash app && \
    chown -R app:app /app
USER app

EXPOSE 8000
CMD ["python", "run.py"]
```

### Настройки для продакшена

```yaml
# docker-compose.prod.yml
version: '3.8'

services:
  app:
    build: .
    environment:
      - DATABASE_URL=postgresql+asyncpg://postgres:${DB_PASSWORD}@db:5432/dev_management
      - SECRET_KEY=${SECRET_KEY}
      - DEBUG=False
    depends_on:
      - db
    restart: always

  db:
    image: postgres:15-alpine
    environment:
      - POSTGRES_DB=dev_management
      - POSTGRES_USER=postgres
      - POSTGRES_PASSWORD=${DB_PASSWORD}
    volumes:
      - postgres_data:/var/lib/postgresql/data
    restart: always

  nginx:
    image: nginx:alpine
    ports:
      - "80:80"
      - "443:443"
    volumes:
      - ./nginx.conf:/etc/nginx/nginx.conf
      - ./ssl:/etc/nginx/ssl
    depends_on:
      - app
    restart: always

volumes:
  postgres_data:
```

---

## 🐛 Устранение неполадок

### Проблемы с портами
```bash
# Проверка занятых портов
netstat -tulpn | grep :8000

# Изменение порта в docker-compose.yml
ports:
  - "8080:8000"  # Внешний порт 8080
```

### Проблемы с базой данных
```bash
# Пересоздание базы данных
docker-compose down -v
docker-compose up --build

# Проверка подключения к БД
docker exec -it <container_id> python -c "from database import engine; print('Connected')"
```

### Проблемы с правами доступа
```bash
# Исправление прав на файлы
sudo chown -R $USER:$USER .

# Проверка пользователя в контейнере
docker exec -it <container_id> whoami
```

### Проблемы с памятью
```bash
# Очистка неиспользуемых образов
docker system prune -a

# Очистка volumes
docker volume prune
```

---

## 📊 Мониторинг

### Просмотр ресурсов
```bash
# Использование ресурсов контейнерами
docker stats

# Информация о контейнере
docker inspect <container_id>
```

### Логи
```bash
# Все логи
docker-compose logs

# Логи конкретного сервиса
docker-compose logs app

# Логи в реальном времени
docker-compose logs -f app
```

---

## 🔒 Безопасность

### Рекомендации:
1. **Измените SECRET_KEY** в продакшене
2. **Используйте сильные пароли** для БД
3. **Настройте SSL/TLS** через nginx
4. **Ограничьте доступ** к портам БД
5. **Регулярно обновляйте** образы

### Пример .env для продакшена:
```env
SECRET_KEY=your-very-secure-secret-key-here
DB_PASSWORD=very-strong-database-password
POSTGRES_PASSWORD=very-strong-postgres-password
```

---

## 📝 Полезные команды

```bash
# Полная очистка Docker
docker system prune -a --volumes

# Сборка только измененных слоев
docker-compose build

# Перезапуск только одного сервиса
docker-compose restart app

# Просмотр переменных окружения
docker exec -it <container_id> env

# Копирование файлов в/из контейнера
docker cp <container_id>:/app/file.txt ./file.txt
docker cp ./file.txt <container_id>:/app/file.txt
```

---

## 🎯 Итог

Docker обеспечивает:
- ✅ Изолированную среду выполнения
- ✅ Простое развертывание
- ✅ Масштабируемость
- ✅ Консистентность между средами
- ✅ Легкое управление зависимостями

**Приложение готово к запуску в Docker!** 🐳

---

**Автор:** a.zakuraev@123.com  
**Версия:** 1.0.0
