from pydantic import BaseModel, EmailStr, validator
from typing import Optional, List
from datetime import datetime


# Схемы для пользователей
class UserCreate(BaseModel):
    username: str
    email: EmailStr
    password: str


class UserLogin(BaseModel):
    username: str
    password: str


class UserResponse(BaseModel):
    id: int
    username: str
    email: str
    is_admin: bool
    created_at: datetime
    
    class Config:
        from_attributes = True


# Схемы для настроек
class SettingsCreate(BaseModel):
    gitlab_url: Optional[str] = None
    gitlab_token: Optional[str] = None
    project_id: Optional[str] = None
    redmine_url: Optional[str] = None
    redmine_token: Optional[str] = None
    kubernetes_api_url: Optional[str] = None
    kubernetes_token: Optional[str] = None


class SettingsResponse(BaseModel):
    id: int
    gitlab_url: Optional[str]
    gitlab_token: Optional[str]
    project_id: Optional[str]
    redmine_url: Optional[str]
    redmine_token: Optional[str]
    kubernetes_api_url: Optional[str]
    kubernetes_token: Optional[str]
    logo_path: Optional[str]
    favicon_path: Optional[str]
    created_at: datetime
    
    class Config:
        from_attributes = True


# Схемы для разработчиков
class DeveloperCreate(BaseModel):
    last_name: str
    first_name: str
    middle_name: Optional[str] = None
    email: EmailStr
    position: str
    department: str
    project_ids: List[int] = []


class DeveloperResponse(BaseModel):
    id: int
    last_name: str
    first_name: str
    middle_name: Optional[str]
    email: str
    position: str
    department: str
    gitlab_user_id: Optional[int]
    redmine_user_id: Optional[int]
    created_at: datetime
    projects: List['ProjectResponse'] = []
    
    class Config:
        from_attributes = True


# Схемы для проектов
class ProjectCreate(BaseModel):
    name: str
    gitlab_project_id: Optional[str] = None
    description: Optional[str] = None


class ProjectResponse(BaseModel):
    id: int
    name: str
    gitlab_project_id: Optional[str]
    description: Optional[str]
    created_at: datetime
    
    class Config:
        from_attributes = True


# Схемы для токенов
class Token(BaseModel):
    access_token: str
    token_type: str


class TokenData(BaseModel):
    username: Optional[str] = None


# Обновляем forward references
DeveloperResponse.model_rebuild()
ProjectResponse.model_rebuild()
