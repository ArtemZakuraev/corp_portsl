from fastapi import FastAPI, Request, Depends, HTTPException
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import text
import os

from database import engine, get_async_session
from models import Base
from routes import router as api_router
from web_routes import router as web_router
from config import settings

# Создаем приложение FastAPI
app = FastAPI(
    title=settings.app_name,
    version=settings.app_version,
    description="Система управления разработчиками с интеграцией GitLab, Redmine и Kubernetes"
)

# Настройка CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Подключаем статические файлы
app.mount("/static", StaticFiles(directory="static"), name="static")

# Подключаем роуты
app.include_router(api_router, prefix="/api", tags=["API"])
app.include_router(web_router, tags=["Web"])


@app.on_event("startup")
async def startup_event():
    """Инициализация при запуске"""
    # Создаем таблицы в базе данных
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    
    # Создаем директории если их нет
    os.makedirs("static/uploads", exist_ok=True)
    os.makedirs("templates", exist_ok=True)


@app.on_event("shutdown")
async def shutdown_event():
    """Очистка при завершении"""
    await engine.dispose()


# Middleware для обработки токенов из cookies
@app.middleware("http")
async def auth_middleware(request: Request, call_next):
    """Middleware для обработки авторизации через cookies"""
    if request.url.path.startswith("/api/"):
        # Для API используем стандартную авторизацию
        response = await call_next(request)
        return response
    
    # Для веб-страниц проверяем cookie
    if request.url.path not in ["/login", "/register"]:
        token = request.cookies.get("access_token")
        if token and token.startswith("Bearer "):
            # Добавляем токен в заголовки для веб-роутов
            request.headers.__dict__["_list"].append((b"authorization", token.encode()))
    
    response = await call_next(request)
    return response


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "main:app",
        host="0.0.0.0",
        port=8000,
        reload=settings.debug
    )
