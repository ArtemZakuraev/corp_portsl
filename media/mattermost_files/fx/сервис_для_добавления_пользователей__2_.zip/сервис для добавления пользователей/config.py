from pydantic_settings import BaseSettings
from typing import Optional
import os


class Settings(BaseSettings):
    # Основные настройки
    secret_key: str = "your-secret-key-change-this-in-production"
    algorithm: str = "HS256"
    access_token_expire_minutes: int = 30
    
    # База данных
    database_url: str = "sqlite+aiosqlite:///./app.db"
    
    # Настройки приложения
    app_name: str = "Developer Management System"
    app_version: str = "1.0.0"
    debug: bool = True
    
    # Пути для загрузки файлов
    upload_dir: str = "static/uploads"
    max_file_size: int = 5242880  # 5MB
    
    # Настройки по умолчанию для интеграций
    default_gitlab_url: str = "https://gitlab.com"
    default_redmine_url: str = "https://redmine.example.com"
    default_kubernetes_api_url: str = "https://kubernetes.example.com"
    
    class Config:
        env_file = "config.env"
        case_sensitive = False


# Создаем экземпляр настроек
settings = Settings()

# Создаем директорию для загрузок если её нет
os.makedirs(settings.upload_dir, exist_ok=True)
