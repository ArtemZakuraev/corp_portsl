from fastapi import APIRouter, Depends, Request, Form, HTTPException
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from typing import Optional, List
import os

from database import get_async_session
from models import User, Settings, Developer, Project, DeveloperProject
from utils import get_current_user, get_current_admin_user, get_password_hash, authenticate_user, create_access_token
from schemas import UserCreate, UserLogin, DeveloperCreate, SettingsCreate
from config import settings

router = APIRouter()
templates = Jinja2Templates(directory="templates")


# Главная страница
@router.get("/", response_class=HTMLResponse)
async def dashboard(
    request: Request,
    current_user: User = Depends(get_current_user),
    session: AsyncSession = Depends(get_async_session)
):
    """Главная страница"""
    # Получаем статистику
    developers_result = await session.execute(select(Developer))
    developers_count = len(developers_result.scalars().all())
    
    projects_result = await session.execute(select(Project))
    projects_count = len(projects_result.scalars().all())
    
    return templates.TemplateResponse("dashboard.html", {
        "request": request,
        "user": current_user,
        "developers_count": developers_count,
        "projects_count": projects_count,
        "app_name": settings.app_name
    })


# Страница регистрации
@router.get("/register", response_class=HTMLResponse)
async def register_page(request: Request):
    """Страница регистрации"""
    return templates.TemplateResponse("register.html", {
        "request": request,
        "app_name": settings.app_name
    })


@router.post("/register", response_class=HTMLResponse)
async def register_user(
    request: Request,
    username: str = Form(...),
    email: str = Form(...),
    password: str = Form(...),
    session: AsyncSession = Depends(get_async_session)
):
    """Обработка регистрации"""
    # Проверяем, существует ли пользователь
    existing_user = await session.execute(
        select(User).where(User.username == username)
    )
    if existing_user.scalar_one_or_none():
        return templates.TemplateResponse("register.html", {
            "request": request,
            "error": "Username already exists",
            "app_name": settings.app_name
        })
    
    existing_email = await session.execute(
        select(User).where(User.email == email)
    )
    if existing_email.scalar_one_or_none():
        return templates.TemplateResponse("register.html", {
            "request": request,
            "error": "Email already exists",
            "app_name": settings.app_name
        })
    
    # Создаем нового пользователя
    hashed_password = get_password_hash(password)
    db_user = User(
        username=username,
        email=email,
        password_hash=hashed_password,
        is_admin=False
    )
    
    session.add(db_user)
    await session.commit()
    
    return RedirectResponse(url="/login", status_code=302)


# Страница входа
@router.get("/login", response_class=HTMLResponse)
async def login_page(request: Request):
    """Страница входа"""
    return templates.TemplateResponse("login.html", {
        "request": request,
        "app_name": settings.app_name
    })


@router.post("/login", response_class=HTMLResponse)
async def login_user(
    request: Request,
    username: str = Form(...),
    password: str = Form(...),
    session: AsyncSession = Depends(get_async_session)
):
    """Обработка входа"""
    from datetime import timedelta
    
    user = await authenticate_user(session, username, password)
    if not user:
        return templates.TemplateResponse("login.html", {
            "request": request,
            "error": "Invalid username or password",
            "app_name": settings.app_name
        })
    
    # Создаем токен и устанавливаем cookie
    access_token_expires = timedelta(minutes=settings.access_token_expire_minutes)
    access_token = create_access_token(
        data={"sub": user.username}, expires_delta=access_token_expires
    )
    
    response = RedirectResponse(url="/", status_code=302)
    response.set_cookie(
        key="access_token",
        value=f"Bearer {access_token}",
        httponly=True,
        max_age=settings.access_token_expire_minutes * 60
    )
    
    return response


# Страница настроек
@router.get("/settings", response_class=HTMLResponse)
async def settings_page(
    request: Request,
    current_user: User = Depends(get_current_admin_user),
    session: AsyncSession = Depends(get_async_session)
):
    """Страница настроек"""
    result = await session.execute(select(Settings).order_by(Settings.id.desc()).limit(1))
    settings_obj = result.scalar_one_or_none()
    
    return templates.TemplateResponse("settings.html", {
        "request": request,
        "user": current_user,
        "settings": settings_obj,
        "app_name": settings.app_name
    })


@router.post("/settings", response_class=HTMLResponse)
async def update_settings(
    request: Request,
    gitlab_url: str = Form(None),
    gitlab_token: str = Form(None),
    project_id: str = Form(None),
    redmine_url: str = Form(None),
    redmine_token: str = Form(None),
    kubernetes_api_url: str = Form(None),
    kubernetes_token: str = Form(None),
    current_user: User = Depends(get_current_admin_user),
    session: AsyncSession = Depends(get_async_session)
):
    """Обновление настроек"""
    result = await session.execute(select(Settings).order_by(Settings.id.desc()).limit(1))
    settings_obj = result.scalar_one_or_none()
    
    if settings_obj:
        settings_obj.gitlab_url = gitlab_url
        settings_obj.gitlab_token = gitlab_token
        settings_obj.project_id = project_id
        settings_obj.redmine_url = redmine_url
        settings_obj.redmine_token = redmine_token
        settings_obj.kubernetes_api_url = kubernetes_api_url
        settings_obj.kubernetes_token = kubernetes_token
    else:
        settings_obj = Settings(
            gitlab_url=gitlab_url,
            gitlab_token=gitlab_token,
            project_id=project_id,
            redmine_url=redmine_url,
            redmine_token=redmine_token,
            kubernetes_api_url=kubernetes_api_url,
            kubernetes_token=kubernetes_token
        )
        session.add(settings_obj)
    
    await session.commit()
    
    return RedirectResponse(url="/settings", status_code=302)


# Страница добавления разработчика
@router.get("/developers/add", response_class=HTMLResponse)
async def add_developer_page(
    request: Request,
    current_user: User = Depends(get_current_admin_user),
    session: AsyncSession = Depends(get_async_session)
):
    """Страница добавления разработчика"""
    projects_result = await session.execute(select(Project))
    projects = projects_result.scalars().all()
    
    return templates.TemplateResponse("add_developer.html", {
        "request": request,
        "user": current_user,
        "projects": projects,
        "app_name": settings.app_name
    })


@router.post("/developers/add", response_class=HTMLResponse)
async def add_developer(
    request: Request,
    last_name: str = Form(...),
    first_name: str = Form(...),
    middle_name: str = Form(None),
    email: str = Form(...),
    position: str = Form(...),
    department: str = Form(...),
    project_ids: Optional[List[int]] = Form(None),
    current_user: User = Depends(get_current_admin_user),
    session: AsyncSession = Depends(get_async_session)
):
    """Добавление разработчика"""
    # Проверяем, существует ли разработчик с таким email
    existing_developer = await session.execute(
        select(Developer).where(Developer.email == email)
    )
    if existing_developer.scalar_one_or_none():
        projects_result = await session.execute(select(Project))
        projects = projects_result.scalars().all()
        
        return templates.TemplateResponse("add_developer.html", {
            "request": request,
            "user": current_user,
            "projects": projects,
            "error": "Developer with this email already exists",
            "app_name": settings.app_name
        })
    
    # Создаем разработчика
    db_developer = Developer(
        last_name=last_name,
        first_name=first_name,
        middle_name=middle_name,
        email=email,
        position=position,
        department=department
    )
    
    session.add(db_developer)
    await session.commit()
    await session.refresh(db_developer)
    
    # Добавляем связи с проектами
    if project_ids:
        for project_id in project_ids:
            dev_project = DeveloperProject(
                developer_id=db_developer.id,
                project_id=project_id,
                active=True
            )
            session.add(dev_project)
    
    await session.commit()
    
    return RedirectResponse(url="/developers", status_code=302)


# Страница списка разработчиков
@router.get("/developers", response_class=HTMLResponse)
async def developers_page(
    request: Request,
    current_user: User = Depends(get_current_user),
    session: AsyncSession = Depends(get_async_session)
):
    """Страница списка разработчиков"""
    result = await session.execute(select(Developer))
    developers = result.scalars().all()
    
    return templates.TemplateResponse("developers.html", {
        "request": request,
        "user": current_user,
        "developers": developers,
        "app_name": settings.app_name
    })


# Страница "О программе"
@router.get("/about", response_class=HTMLResponse)
async def about_page(
    request: Request,
    current_user: User = Depends(get_current_user)
):
    """Страница о программе"""
    return templates.TemplateResponse("about.html", {
        "request": request,
        "user": current_user,
        "app_name": settings.app_name,
        "app_version": settings.app_version,
        "author": "a.zakuraev@123.com"
    })


# Выход
@router.get("/logout", response_class=HTMLResponse)
async def logout():
    """Выход из системы"""
    response = RedirectResponse(url="/login", status_code=302)
    response.delete_cookie(key="access_token")
    return response
