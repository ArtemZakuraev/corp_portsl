from fastapi import APIRouter, Depends, HTTPException, status, UploadFile, File
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from typing import List, Optional
import aiofiles
import os
from datetime import timedelta

from database import get_async_session
from models import User, Settings, Developer, Project, DeveloperProject
from schemas import (
    UserCreate, UserLogin, UserResponse, SettingsCreate, SettingsResponse,
    DeveloperCreate, DeveloperResponse, ProjectCreate, ProjectResponse, Token
)
from utils import (
    get_password_hash, verify_password, create_access_token, authenticate_user,
    get_current_user, get_current_admin_user, generate_username_from_email
)
from config import settings
from api_integrations import GitLabAPI, RedmineAPI, KubernetesAPI

router = APIRouter()


# Аутентификация
@router.post("/auth/register", response_model=UserResponse)
async def register(
    user_data: UserCreate,
    session: AsyncSession = Depends(get_async_session)
):
    """Регистрация нового пользователя"""
    # Проверяем, существует ли пользователь
    existing_user = await session.execute(
        select(User).where(User.username == user_data.username)
    )
    if existing_user.scalar_one_or_none():
        raise HTTPException(
            status_code=400,
            detail="Username already registered"
        )
    
    existing_email = await session.execute(
        select(User).where(User.email == user_data.email)
    )
    if existing_email.scalar_one_or_none():
        raise HTTPException(
            status_code=400,
            detail="Email already registered"
        )
    
    # Создаем нового пользователя
    hashed_password = get_password_hash(user_data.password)
    db_user = User(
        username=user_data.username,
        email=user_data.email,
        password_hash=hashed_password,
        is_admin=False
    )
    
    session.add(db_user)
    await session.commit()
    await session.refresh(db_user)
    
    return db_user


@router.post("/auth/login", response_model=Token)
async def login(
    user_data: UserLogin,
    session: AsyncSession = Depends(get_async_session)
):
    """Вход пользователя"""
    user = await authenticate_user(session, user_data.username, user_data.password)
    if not user:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect username or password",
            headers={"WWW-Authenticate": "Bearer"},
        )
    
    access_token_expires = timedelta(minutes=settings.access_token_expire_minutes)
    access_token = create_access_token(
        data={"sub": user.username}, expires_delta=access_token_expires
    )
    
    return {"access_token": access_token, "token_type": "bearer"}


# Настройки
@router.get("/settings", response_model=SettingsResponse)
async def get_settings(
    current_user: User = Depends(get_current_admin_user),
    session: AsyncSession = Depends(get_async_session)
):
    """Получение настроек"""
    result = await session.execute(select(Settings).order_by(Settings.id.desc()).limit(1))
    settings_obj = result.scalar_one_or_none()
    
    if not settings_obj:
        # Создаем настройки по умолчанию
        settings_obj = Settings()
        session.add(settings_obj)
        await session.commit()
        await session.refresh(settings_obj)
    
    return settings_obj


@router.post("/settings", response_model=SettingsResponse)
async def update_settings(
    settings_data: SettingsCreate,
    current_user: User = Depends(get_current_admin_user),
    session: AsyncSession = Depends(get_async_session)
):
    """Обновление настроек"""
    result = await session.execute(select(Settings).order_by(Settings.id.desc()).limit(1))
    settings_obj = result.scalar_one_or_none()
    
    if settings_obj:
        # Обновляем существующие настройки
        for field, value in settings_data.dict(exclude_unset=True).items():
            setattr(settings_obj, field, value)
    else:
        # Создаем новые настройки
        settings_obj = Settings(**settings_data.dict())
        session.add(settings_obj)
    
    await session.commit()
    await session.refresh(settings_obj)
    
    return settings_obj


@router.post("/settings/upload-logo")
async def upload_logo(
    file: UploadFile = File(...),
    current_user: User = Depends(get_current_admin_user),
    session: AsyncSession = Depends(get_async_session)
):
    """Загрузка логотипа"""
    if not file.content_type.startswith('image/'):
        raise HTTPException(status_code=400, detail="File must be an image")
    
    if file.size > settings.max_file_size:
        raise HTTPException(status_code=400, detail="File too large")
    
    # Сохраняем файл
    filename = f"logo_{current_user.id}_{file.filename}"
    file_path = os.path.join(settings.upload_dir, filename)
    
    async with aiofiles.open(file_path, 'wb') as f:
        content = await file.read()
        await f.write(content)
    
    # Обновляем настройки
    result = await session.execute(select(Settings).order_by(Settings.id.desc()).limit(1))
    settings_obj = result.scalar_one_or_none()
    
    if settings_obj:
        settings_obj.logo_path = file_path
    else:
        settings_obj = Settings(logo_path=file_path)
        session.add(settings_obj)
    
    await session.commit()
    
    return {"message": "Logo uploaded successfully", "path": file_path}


@router.post("/settings/upload-favicon")
async def upload_favicon(
    file: UploadFile = File(...),
    current_user: User = Depends(get_current_admin_user),
    session: AsyncSession = Depends(get_async_session)
):
    """Загрузка favicon"""
    if not file.content_type.startswith('image/'):
        raise HTTPException(status_code=400, detail="File must be an image")
    
    if file.size > settings.max_file_size:
        raise HTTPException(status_code=400, detail="File too large")
    
    # Сохраняем файл
    filename = f"favicon_{current_user.id}_{file.filename}"
    file_path = os.path.join(settings.upload_dir, filename)
    
    async with aiofiles.open(file_path, 'wb') as f:
        content = await file.read()
        await f.write(content)
    
    # Обновляем настройки
    result = await session.execute(select(Settings).order_by(Settings.id.desc()).limit(1))
    settings_obj = result.scalar_one_or_none()
    
    if settings_obj:
        settings_obj.favicon_path = file_path
    else:
        settings_obj = Settings(favicon_path=file_path)
        session.add(settings_obj)
    
    await session.commit()
    
    return {"message": "Favicon uploaded successfully", "path": file_path}


# Проекты
@router.get("/projects", response_model=List[ProjectResponse])
async def get_projects(
    session: AsyncSession = Depends(get_async_session)
):
    """Получение списка проектов"""
    result = await session.execute(select(Project))
    projects = result.scalars().all()
    return projects


@router.post("/projects", response_model=ProjectResponse)
async def create_project(
    project_data: ProjectCreate,
    current_user: User = Depends(get_current_admin_user),
    session: AsyncSession = Depends(get_async_session)
):
    """Создание нового проекта"""
    db_project = Project(**project_data.dict())
    session.add(db_project)
    await session.commit()
    await session.refresh(db_project)
    
    return db_project


# Разработчики
@router.get("/developers", response_model=List[DeveloperResponse])
async def get_developers(
    session: AsyncSession = Depends(get_async_session)
):
    """Получение списка разработчиков"""
    result = await session.execute(select(Developer))
    developers = result.scalars().all()
    return developers


@router.post("/developers/add", response_model=DeveloperResponse)
async def add_developer(
    developer_data: DeveloperCreate,
    current_user: User = Depends(get_current_admin_user),
    session: AsyncSession = Depends(get_async_session)
):
    """Добавление нового разработчика с интеграцией в GitLab и Redmine"""
    
    # Проверяем, существует ли разработчик с таким email
    existing_developer = await session.execute(
        select(Developer).where(Developer.email == developer_data.email)
    )
    if existing_developer.scalar_one_or_none():
        raise HTTPException(
            status_code=400,
            detail="Developer with this email already exists"
        )
    
    # Получаем настройки
    result = await session.execute(select(Settings).order_by(Settings.id.desc()).limit(1))
    settings_obj = result.scalar_one_or_none()
    
    if not settings_obj:
        raise HTTPException(
            status_code=400,
            detail="Settings not configured"
        )
    
    # Создаем разработчика в БД
    username = generate_username_from_email(developer_data.email)
    
    db_developer = Developer(
        last_name=developer_data.last_name,
        first_name=developer_data.first_name,
        middle_name=developer_data.middle_name,
        email=developer_data.email,
        position=developer_data.position,
        department=developer_data.department
    )
    
    session.add(db_developer)
    await session.commit()
    await session.refresh(db_developer)
    
    # Подготавливаем данные для API
    user_data = {
        'username': username,
        'email': developer_data.email,
        'first_name': developer_data.first_name,
        'last_name': developer_data.last_name,
        'middle_name': developer_data.middle_name,
        'position': developer_data.position,
        'department': developer_data.department
    }
    
    # Интеграция с GitLab
    if settings_obj.gitlab_url and settings_obj.gitlab_token:
        try:
            gitlab_api = GitLabAPI(settings_obj.gitlab_url, settings_obj.gitlab_token)
            gitlab_user_id = await gitlab_api.create_user(user_data)
            
            if gitlab_user_id:
                db_developer.gitlab_user_id = gitlab_user_id
                
                # Добавляем пользователя к проектам
                if developer_data.project_ids:
                    for project_id in developer_data.project_ids:
                        project_result = await session.execute(
                            select(Project).where(Project.id == project_id)
                        )
                        project = project_result.scalar_one_or_none()
                        
                        if project and project.gitlab_project_id:
                            await gitlab_api.add_user_to_project(
                                gitlab_user_id, 
                                project.gitlab_project_id
                            )
                            
                            # Создаем связь разработчик-проект
                            dev_project = DeveloperProject(
                                developer_id=db_developer.id,
                                project_id=project_id,
                                active=True
                            )
                            session.add(dev_project)
        except Exception as e:
            print(f"GitLab integration error: {e}")
    
    # Интеграция с Redmine
    if settings_obj.redmine_url and settings_obj.redmine_token:
        try:
            redmine_api = RedmineAPI(settings_obj.redmine_url, settings_obj.redmine_token)
            redmine_user_id = await redmine_api.create_user(user_data)
            
            if redmine_user_id:
                db_developer.redmine_user_id = redmine_user_id
                
                # Добавляем пользователя к проектам в Redmine
                if developer_data.project_ids:
                    for project_id in developer_data.project_ids:
                        project_result = await session.execute(
                            select(Project).where(Project.id == project_id)
                        )
                        project = project_result.scalar_one_or_none()
                        
                        if project:
                            await redmine_api.add_user_to_project(
                                redmine_user_id, 
                                str(project.id)  # Redmine использует строковые ID проектов
                            )
        except Exception as e:
            print(f"Redmine integration error: {e}")
    
    await session.commit()
    await session.refresh(db_developer)
    
    return db_developer
