from database.session import async_session
from models.models import Log
import datetime
import asyncio

async def log_action(user_id: int, action: str):
    """
    Асинхронное логирование действий пользователя.
    """
    async def sync_log():
        async with async_session() as session:
            log_entry = Log(
                user_id=user_id,
                action=action,
                timestamp=datetime.datetime.utcnow().isoformat()
            )
            session.add(log_entry)
            await session.commit()

    await asyncio.to_thread(sync_log)
