import asyncio
from redminelib import Redmine
from core.settings import settings

async def add_to_redmine(email: str, project_ids: list[int], role="Developer"):
    username = email.split("@")[0].replace(".", "")
    
    def sync_add():
        rm = Redmine(settings.REDMINE_URL, key=settings.REDMINE_TOKEN)
        # Пример создания пользователя и добавления в проекты
        pass

    await asyncio.to_thread(sync_add)