import asyncio
import gitlab
from core.settings import settings

async def add_to_gitlab(email: str, project_ids: list[int], role="developer"):
    """
    Асинхронная обёртка для добавления пользователя в проекты GitLab.
    """
    username = email.split("@")[0].replace(".", "")
    
    def sync_add():
        gl = gitlab.Gitlab(settings.GITLAB_URL, private_token=settings.GITLAB_TOKEN)
        gl.auth()
        for pid in project_ids:
            project = gl.projects.get(pid)
            # Здесь нужно создать пользователя в проекте с нужной ролью
            # Пример: project.members.create({'user_id': username, 'access_level': 30})
            pass

    await asyncio.to_thread(sync_add)
