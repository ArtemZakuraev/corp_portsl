from fastapi import Request, HTTPException
from functools import wraps

# Простейший декоратор проверки администратора
def admin_required(func):
    @wraps(func)
    async def wrapper(request: Request, *args, **kwargs):
        # Проверяем в request.state.user или токен
        user = getattr(request.state, "user", None)
        if not user or not getattr(user, "is_admin", False):
            raise HTTPException(status_code=403, detail="Admin access required")
        return await func(request, *args, **kwargs)
    return wrapper
