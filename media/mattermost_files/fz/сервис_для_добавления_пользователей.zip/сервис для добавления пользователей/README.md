# 🧑‍💻 Создание баз данных для разработчиков Автор: a.zakuraev@rtinform.ru

Веб-приложение на **FastAPI**, **SQLAlchemy (async)**, **Jinja2** и **Bootstrap 5** для управления разработчиками и интеграции с **GitLab**, **Redmine** потом планирую добавить просмотр подов в **Kubernetes**.

## 🚀 Установка и запуск

```bash
cd fastapi_app
docker-compose up --build
