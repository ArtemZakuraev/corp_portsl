from fastapi import FastAPI, Request
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from starlette.middleware.sessions import SessionMiddleware
from core.settings import settings  
from routes import auth, settings as settings_routes, developers, logs, main_routes
from database.session import init_db
import uvicorn
import asyncio

app = FastAPI(title="Создание разработчиков и баз данных")

app.add_middleware(SessionMiddleware, secret_key=settings.SECRET_KEY)

app.mount("/static", StaticFiles(directory="static"), name="static")
templates = Jinja2Templates(directory="templates")

app.include_router(auth.router)
app.include_router(settings_routes.router)
app.include_router(developers.router)
app.include_router(logs.router)
app.include_router(main_routes.router)

@app.on_event("startup")
async def on_startup():
    await init_db()

if __name__ == "__main__":
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)