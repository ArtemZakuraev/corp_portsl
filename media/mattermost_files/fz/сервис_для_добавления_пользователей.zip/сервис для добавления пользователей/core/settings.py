from pydantic_settings import BaseSettings
from fastapi.templating import Jinja2Templates
from typing import Any

class Settings(BaseSettings):
    APP_NAME: str = "Create developers with bases"
    SECRET_KEY: str = "supersecret"
    POSTGRES_USER: str = "admin"
    POSTGRES_PASSWORD: str = "admin"
    POSTGRES_DB: str = "developers_db"
    POSTGRES_HOST: str = "db"
    POSTGRES_PORT: int = 5432

    JWT_SECRET: str = "supersecret"
    JWT_ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 60

    # Поле для хранения Jinja2Templates, не из .env
    templates: Any = None

    class Config:
        env_file = ".env"
        extra = "allow"  # можно разрешить лишние поля

# Инициализируем templates после создания экземпляра
settings = Settings()
settings.templates = Jinja2Templates(directory="templates")
