from pydantic import BaseModel
from typing import Optional

class SettingsBase(BaseModel):
    gitlab_url: Optional[str] = None
    gitlab_token: Optional[str] = None
    gitlab_default_project_id: Optional[str] = None
    redmine_url: Optional[str] = None
    redmine_token: Optional[str] = None
    kubernetes_api_url: Optional[str] = None
    kubernetes_token: Optional[str] = None
    logo_filename: Optional[str] = None
    favicon_filename: Optional[str] = None

class SettingsUpdate(SettingsBase):
    pass

class SettingsResponse(SettingsBase):
    id: int

    class Config:
        orm_mode = True
