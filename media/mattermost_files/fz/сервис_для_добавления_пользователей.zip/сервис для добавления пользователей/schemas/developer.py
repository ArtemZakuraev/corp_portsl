from pydantic import BaseModel, EmailStr
from typing import List, Optional

class DeveloperBase(BaseModel):
    last_name: str
    first_name: str
    middle_name: Optional[str] = None
    email: EmailStr
    position: Optional[str] = None
    department: Optional[str] = None

class DeveloperCreate(DeveloperBase):
    project_ids: List[int] = []

class DeveloperResponse(DeveloperBase):
    id: int
    projects: List[str] = []

    class Config:
        orm_mode = True
