from sqlalchemy import Column, Integer, String, Boolean, ForeignKey
from sqlalchemy.orm import relationship, declarative_base

Base = declarative_base()

class User(Base):
    __tablename__ = "users"
    id = Column(Integer, primary_key=True, index=True)
    username = Column(String, unique=True, index=True)
    email = Column(String, unique=True, index=True)
    password_hash = Column(String)

class Settings(Base):
    __tablename__ = "settings"
    id = Column(Integer, primary_key=True)
    gitlab_url = Column(String)
    gitlab_token = Column(String)
    redmine_url = Column(String)
    redmine_token = Column(String)
    kubernetes_api_url = Column(String)
    kubernetes_token = Column(String)
    project_id = Column(Integer, nullable=True)

class Developer(Base):
    __tablename__ = "developers"
    id = Column(Integer, primary_key=True)
    last_name = Column(String)
    first_name = Column(String)
    middle_name = Column(String)
    email = Column(String)
    position = Column(String)
    department = Column(String)
    projects = relationship("DeveloperProject", back_populates="developer")

class Project(Base):
    __tablename__ = "projects"
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, nullable=False)
    gitlab_project_id = Column(Integer, nullable=True)
    developers = relationship("DeveloperProject", back_populates="project")

class DeveloperProject(Base):
    __tablename__ = "developer_projects"
    developer_id = Column(Integer, ForeignKey("developers.id"), primary_key=True)
    project_id = Column(Integer, ForeignKey("projects.id"), primary_key=True)
    active = Column(Boolean, default=False)
    developer = relationship("Developer", back_populates="projects")
    project = relationship("Project", back_populates="developers")

class Log(Base):
    __tablename__ = "logs"
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer)
    action = Column(String)
    timestamp = Column(String)
