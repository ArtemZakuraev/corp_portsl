from fastapi import APIRouter, Depends, Request
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select
from database.session import get_session
from models.models import Log
from utils.auth import admin_required

router = APIRouter(prefix="/logs", tags=["Logs"])

@router.get("/")
async def logs_page(request: Request, session: AsyncSession = Depends(get_session), user=Depends(admin_required)):
    query = await session.execute(select(Log))
    logs = query.scalars().all()
    return {"request": request, "logs": logs}
