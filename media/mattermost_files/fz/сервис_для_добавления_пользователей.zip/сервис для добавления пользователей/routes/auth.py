from fastapi import APIRouter, Depends, Request, Form, status
from fastapi.responses import RedirectResponse
from sqlalchemy.ext.asyncio import AsyncSession
from jose import jwt
from passlib.hash import bcrypt
from database.session import get_session
from models.models import User
from core.settings import settings
import datetime

router = APIRouter(tags=["Auth"])

SECRET_KEY = settings.SECRET_KEY
ALGORITHM = "HS256"

# регистрация
@router.get("/register")
async def register_page(request: Request):
    return settings.templates.TemplateResponse("register.html", {"request": request})

@router.post("/register")
async def register_user(
    request: Request,
    username: str = Form(...),
    email: str = Form(...),
    password: str = Form(...),
    session: AsyncSession = Depends(get_session),
):
    user = User(username=username, email=email, password_hash=bcrypt.hash(password))
    session.add(user)
    await session.commit()
    return RedirectResponse(url="/login", status_code=status.HTTP_303_SEE_OTHER)

# авторизация
@router.get("/login")
async def login_page(request: Request):
    return settings.templates.TemplateResponse("login.html", {"request": request})

@router.post("/login")
async def login_user(
    request: Request,
    username: str = Form(...),
    password: str = Form(...),
    session: AsyncSession = Depends(get_session),
):
    query = await session.execute(User.__table__.select().where(User.username == username))
    user = query.scalar_one_or_none()
    if not user or not bcrypt.verify(password, user.password_hash):
        return settings.templates.TemplateResponse("login.html", {"request": request, "error": "Неверный логин или пароль"})
    token_data = {"sub": user.username, "exp": datetime.datetime.utcnow() + datetime.timedelta(hours=12)}
    token = jwt.encode(token_data, SECRET_KEY, algorithm=ALGORITHM)
    response = RedirectResponse(url="/dashboard", status_code=status.HTTP_303_SEE_OTHER)
    response.set_cookie("access_token", token)
    return response