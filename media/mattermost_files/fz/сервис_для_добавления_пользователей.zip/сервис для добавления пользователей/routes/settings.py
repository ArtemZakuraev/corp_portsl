from fastapi import APIRouter, Request, Form, Depends
from fastapi.responses import RedirectResponse
from sqlalchemy.ext.asyncio import AsyncSession
from database.session import get_session
from models.models import Settings
from core.settings import settings

router = APIRouter(prefix="/settings", tags=["Settings"])

@router.get("/")
async def get_settings_page(request: Request, session: AsyncSession = Depends(get_session)):
    query = await session.execute(Settings.__table__.select())
    conf = query.scalar_one_or_none()
    return settings.templates.TemplateResponse("settings.html", {"request": request, "settings": conf})

@router.post("/")
async def update_settings(
    request: Request,
    gitlab_url: str = Form(None),
    gitlab_token: str = Form(None),
    redmine_url: str = Form(None),
    redmine_token: str = Form(None),
    kubernetes_api_url: str = Form(None),
    kubernetes_token: str = Form(None),
    session: AsyncSession = Depends(get_session)
):
    query = await session.execute(Settings.__table__.select())
    conf = query.scalar_one_or_none()
    if conf:
        conf.gitlab_url = gitlab_url
        conf.gitlab_token = gitlab_token
        conf.redmine_url = redmine_url
        conf.redmine_token = redmine_token
        conf.kubernetes_api_url = kubernetes_api_url
        conf.kubernetes_token = kubernetes_token
    else:
        conf = Settings(
            gitlab_url=gitlab_url,
            gitlab_token=gitlab_token,
            redmine_url=redmine_url,
            redmine_token=redmine_token,
            kubernetes_api_url=kubernetes_api_url,
            kubernetes_token=kubernetes_token,
        )
        session.add(conf)
    await session.commit()
    return RedirectResponse(url="/settings", status_code=303)