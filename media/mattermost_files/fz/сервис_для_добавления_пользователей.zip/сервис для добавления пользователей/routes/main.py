from fastapi import APIRouter, Request, Depends
from sqlalchemy.ext.asyncio import AsyncSession
from database.session import get_session
from utils.auth import get_current_user

router = APIRouter()

@router.get("/")
async def home_redirect():
    return {"redirect": "/dashboard"}

@router.get("/dashboard")
async def dashboard(request: Request, user=Depends(get_current_user)):
    return {"request": request, "user": user}

@router.get("/about")
async def about_page(request: Request):
    return {"request": request, "author": "a.zakuraev@rtinform.ru"}
