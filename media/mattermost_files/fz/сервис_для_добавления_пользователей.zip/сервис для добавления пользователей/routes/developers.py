from fastapi import APIRouter, Depends, Form, Request
from fastapi.responses import RedirectResponse
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select
from models.models import Developer, Project, DeveloperProject, Settings
from database.session import get_session
from utils.gitlab_integration import add_to_gitlab
from utils.redmine_integration import add_to_redmine
from utils.logs import log_action

router = APIRouter(prefix="/developers", tags=["Developers"])


@router.get("/add")
async def add_developer_page(request: Request, session: AsyncSession = Depends(get_session)):
    query = await session.execute(select(Project))
    projects = query.scalars().all()
    return {"request": request, "projects": projects}


@router.post("/add")
async def add_developer(
    request: Request,
    last_name: str = Form(...),
    first_name: str = Form(...),
    middle_name: str = Form(None),
    email: str = Form(...),
    position: str = Form(...),
    department: str = Form(...),
    projects: list[int] = Form([]),
    session: AsyncSession = Depends(get_session)
):
    dev = Developer(
        last_name=last_name,
        first_name=first_name,
        middle_name=middle_name,
        email=email,
        position=position,
        department=department
    )
    session.add(dev)
    await session.commit()

    for pid in projects:
        dp = DeveloperProject(developer_id=dev.id, project_id=pid, active=True)
        session.add(dp)
    await session.commit()

    username = email.split("@")[0].replace(".", "")

    settings_query = await session.execute(select(Settings))
    cfg = settings_query.scalars().first()

    await add_to_gitlab(cfg, username, email, projects)
    await add_to_redmine(cfg, username, email, projects)
    await log_action(session, None, f"Добавлен разработчик {email}")
    return RedirectResponse(url="/developers/add", status_code=302)
