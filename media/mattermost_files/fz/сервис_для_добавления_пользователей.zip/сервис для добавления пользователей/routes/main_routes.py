from fastapi import APIRouter, Request
from fastapi.responses import HTMLResponse
from core.settings import settings

router = APIRouter()

@router.get("/", response_class=HTMLResponse)
async def home(request: Request):
    return settings.templates.TemplateResponse(
        "index.html",
        {"request": request, "title": "Создание разработчиков и баз данных"}
    )

@router.get("/about", response_class=HTMLResponse)
async def about(request: Request):
    return settings.templates.TemplateResponse(
        "about.html",
        {"request": request, "title": "О программе"}
    )