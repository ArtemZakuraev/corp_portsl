from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession
from sqlalchemy.orm import sessionmaker, declarative_base
from core.settings import settings

DATABASE_URL = (
    f"postgresql+asyncpg://{settings.POSTGRES_USER}:"
    f"{settings.POSTGRES_PASSWORD}@{settings.POSTGRES_HOST}:"
    f"{settings.POSTGRES_PORT}/{settings.POSTGRES_DB}"
)

engine = create_async_engine(DATABASE_URL, echo=True, future=True)

# Асинхронная сессия
async_session = sessionmaker(
    engine, class_=AsyncSession, expire_on_commit=False
)

# Генератор сессий для FastAPI
async def get_session():
    async with async_session() as session:
        yield session

# Базовый класс для моделей
Base = declarative_base()

# Инициализация БД
async def init_db():
    async with engine.begin() as conn:
        from models.models import User, Settings, Developer, Project, DeveloperProject, Log
        await conn.run_sync(Base.metadata.create_all)
