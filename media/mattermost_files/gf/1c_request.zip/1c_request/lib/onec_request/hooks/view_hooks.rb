module OnecRequest
  module Hooks
    class ViewHooks < Redmine::Hook::ViewListener
      render_on :view_layouts_base_content, partial: 'onec_request/hooks/my_time_entries'
    end
  end
end
