require_dependency 'users_controller'

module OnecRequest
  module Patches
    module UsersControllerPatch
      def self.included(base)
        base.class_eval do
          helper OnecRequest::MyHelper

          before_action :set_onec_request_report_for_profile, only: :show
        end
      end

      private

      def set_onec_request_report_for_profile
        return unless @user

        @onec_request_report = OnecRequest::UserReport.find_by(user_id: @user.id)
      end
    end
  end
end

unless UsersController.included_modules.include?(OnecRequest::Patches::UsersControllerPatch)
  UsersController.send(:include, OnecRequest::Patches::UsersControllerPatch)
end
