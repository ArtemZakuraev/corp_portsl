require_dependency 'my_controller'

module OnecRequest
  module Patches
    module MyControllerPatch
      def self.included(base)
        base.class_eval do
          include OnecRequest::MyHelper

          before_action :set_onec_request_report, only: :time_entries
        end
      end

      private

      def set_onec_request_report
        @onec_request_report = OnecRequest::UserReport.find_by(user_id: User.current.id)
      end
    end
  end
end

unless MyController.included_modules.include?(OnecRequest::Patches::MyControllerPatch)
  MyController.send(:include, OnecRequest::Patches::MyControllerPatch)
end
