RedmineApp::Application.routes.draw do
  scope module: 'onec_request' do
    post 'my/onec_request/update', to: 'my_worklogs#update', as: :onec_request_update_my_worklog
  end
end
