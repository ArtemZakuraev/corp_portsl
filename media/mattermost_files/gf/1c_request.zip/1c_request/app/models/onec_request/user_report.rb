module OnecRequest
  class UserReport < ActiveRecord::Base
    self.table_name = 'onec_request_user_reports'

    belongs_to :user

    validates :user_id, presence: true, uniqueness: true
  end
end
